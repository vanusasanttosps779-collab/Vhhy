import * as THREE from 'three';
import realMadridJerseyUrl from '../assets/images/real_madrid_jersey_1794963927007.jpg';

type LegacyRiderShirtStyle = 'real_madrid' | 'grau_160';

export interface GloveShaderUniforms {
  uGloveEnabled: { value: number };
  uGlovePrimary: { value: THREE.Color };
  uGloveAccent: { value: THREE.Color };
  uGloveMap: { value: THREE.Texture | null };
  uCarbonMap: { value: THREE.Texture | null };
  uBareHandMap?: { value: THREE.Texture | null };
  uSkinBaseColor?: { value: THREE.Color };
}

export interface ClothShaderUniforms {
  uClothTime: { value: number };
  uClothWind: { value: number };
  uClothFlutter: { value: number };
  uClothSway: { value: THREE.Vector3 };
}

export interface CamisaShortOutfitResult {
  meshes: THREE.Mesh[];
  materials: THREE.MeshStandardMaterial[];
  setShirtStyle: (style: LegacyRiderShirtStyle) => void;
}

interface JointPositions {
  hips: THREE.Vector3;
  spine: THREE.Vector3;
  spine1: THREE.Vector3;
  spine2: THREE.Vector3;
  neck: THREE.Vector3;
  lShoulder: THREE.Vector3;
  rShoulder: THREE.Vector3;
  lArm: THREE.Vector3;
  rArm: THREE.Vector3;
  lForeArm: THREE.Vector3;
  rForeArm: THREE.Vector3;
  lHand: THREE.Vector3;
  rHand: THREE.Vector3;
  lUpLeg: THREE.Vector3;
  rUpLeg: THREE.Vector3;
  lLeg: THREE.Vector3;
  rLeg: THREE.Vector3;
  lFoot: THREE.Vector3;
  rFoot: THREE.Vector3;
}

interface JointIndices {
  hips: number;
  spine: number;
  spine1: number;
  spine2: number;
  neck: number;
  head: number;
  lShoulder: number;
  rShoulder: number;
  lArm: number;
  rArm: number;
  lForeArm: number;
  rForeArm: number;
  lHand: number;
  rHand: number;
  lUpLeg: number;
  rUpLeg: number;
  lLeg: number;
  rLeg: number;
  lFoot: number;
  rFoot: number;
}

interface CrossSectionSlice {
  center: THREE.Vector3;
  rx: number;
  rz: number;
  v: number;
  weights: [number, number][];
  torsoMask: [number, number];
  frontPush?: number;
  backPush?: number;
  clothFreedom?: number;
  clothIsSleeve?: number;
  clothHemFactor?: number;
  /** Optional per-vertex position tweak (e.g., curved collar scoop, anatomical pecs, or cloth folds) */
  posPerVertex?: (pos: THREE.Vector3, sinTheta: number, cosTheta: number, theta: number) => void;
}

function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = clamp01((x - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

/**
 * Samples the character's exact skin tone from Wolf3D_Skin's diffuse map around the neck UV,
 * falling back cleanly to a warm natural skin tone if texture pixels are unavailable.
 */
export function sampleSkinRgbFromMesh(skinMesh: THREE.Mesh | null): [number, number, number] {
  const fallback: [number, number, number] = [204, 146, 114];
  if (!skinMesh) return fallback;
  const mat = Array.isArray(skinMesh.material) ? skinMesh.material[0] : skinMesh.material;
  const stdMat = mat as THREE.MeshStandardMaterial | undefined;
  const map = stdMat?.map;
  const img = map?.image as
    | HTMLImageElement
    | HTMLCanvasElement
    | ImageBitmap
    | undefined;
  if (!img) return fallback;

  const w = (img as any).naturalWidth || (img as any).width || 0;
  const h = (img as any).naturalHeight || (img as any).height || 0;
  if (w < 8 || h < 8) return fallback;

  try {
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return fallback;
    ctx.drawImage(img as CanvasImageSource, 0, 0, w, h);

    const u = 0.499;
    const v = 0.784;
    const cx = Math.min(w - 3, Math.max(2, Math.round(u * w)));
    const pyRaw = map?.flipY ? (1 - v) * h : v * h;
    const cy = Math.min(h - 3, Math.max(2, Math.round(pyRaw)));

    const data = ctx.getImageData(cx - 2, cy - 2, 5, 5).data;
    let rSum = 0;
    let gSum = 0;
    let bSum = 0;
    let count = 0;
    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] > 200) {
        rSum += data[i];
        gSum += data[i + 1];
        bSum += data[i + 2];
        count++;
      }
    }
    if (count === 0) return fallback;
    const r = Math.round(rSum / count);
    const g = Math.round(gSum / count);
    const b = Math.round(bSum / count);
    const luma = 0.299 * r + 0.587 * g + 0.114 * b;
    if (luma < 35) return fallback;
    return [r, g, b];
  } catch {
    return fallback;
  }
}

export function createSkinTexture(rgb: [number, number, number], maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const [r, g, b] = rgb;
  const base = `rgb(${r}, ${g}, ${b})`;
  const warm = `rgb(${Math.min(255, r + 14)}, ${Math.min(255, g + 8)}, ${Math.max(0, b - 4)})`;
  const shade = `rgb(${Math.max(0, r - 18)}, ${Math.max(0, g - 20)}, ${Math.max(0, b - 18)})`;

  const grad = ctx.createLinearGradient(0, 0, size, 0);
  grad.addColorStop(0.0, shade);
  grad.addColorStop(0.22, base);
  grad.addColorStop(0.5, warm);
  grad.addColorStop(0.78, base);
  grad.addColorStop(1.0, shade);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  const vGrad = ctx.createLinearGradient(0, 0, 0, size);
  vGrad.addColorStop(0.0, 'rgba(0,0,0,0.06)');
  vGrad.addColorStop(0.45, 'rgba(255,220,195,0.05)');
  vGrad.addColorStop(0.52, 'rgba(130,65,45,0.08)');
  vGrad.addColorStop(0.60, 'rgba(255,220,195,0.04)');
  vGrad.addColorStop(1.0, 'rgba(0,0,0,0.04)');
  ctx.fillStyle = vGrad;
  ctx.fillRect(0, 0, size, size);

  let seed = 1337;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  for (let i = 0; i < 3600; i++) {
    const x = rand() * size;
    const y = rand() * size;
    const alpha = 0.015 + rand() * 0.02;
    ctx.fillStyle = rand() > 0.5 ? `rgba(255,240,225,${alpha})` : `rgba(85,42,28,${alpha})`;
    ctx.fillRect(x, y, 2, 2);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  tex.needsUpdate = true;
  return tex;
}

function createShirtTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const baseGrad = ctx.createLinearGradient(0, 0, 0, size);
  baseGrad.addColorStop(0.0, '#f4f6f9');
  baseGrad.addColorStop(0.55, '#ebeff5');
  baseGrad.addColorStop(1.0, '#dfe5ee');
  ctx.fillStyle = baseGrad;
  ctx.fillRect(0, 0, size, size);

  ctx.fillStyle = 'rgba(15, 23, 42, 0.025)';
  for (let y = 0; y < size; y += 3) {
    ctx.fillRect(0, y, size, 1);
  }
  for (let x = 0; x < size; x += 4) {
    ctx.fillRect(x, 0, 1, size);
  }

  const foldGrad = ctx.createLinearGradient(0, size * 0.6, size, size * 0.6);
  foldGrad.addColorStop(0.0, 'rgba(15,23,42,0.06)');
  foldGrad.addColorStop(0.25, 'rgba(255,255,255,0.04)');
  foldGrad.addColorStop(0.5, 'rgba(15,23,42,0.05)');
  foldGrad.addColorStop(0.75, 'rgba(255,255,255,0.04)');
  foldGrad.addColorStop(1.0, 'rgba(15,23,42,0.06)');
  ctx.fillStyle = foldGrad;
  ctx.fillRect(0, 0, size, size);

  const frontX = size * 0.25;
  ctx.fillStyle = '#181b22';
  ctx.fillRect(frontX - 74, size * 0.34, 148, 22);
  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(frontX - 74, size * 0.34 + 22, 148, 6);

  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 14px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('GRAU · 160', frontX, size * 0.34 + 11);

  // Crew-neck collar ribband near v = 0.92..1.0 (canvas top y = 0..38)
  ctx.fillStyle = '#171920';
  ctx.fillRect(0, 0, size, 30);
  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(0, 30, size, 4);

  // Bottom hem double stitch line near v = 0.04 (canvas bottom)
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.22)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, size - 14);
  ctx.lineTo(size, size - 14);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  tex.needsUpdate = true;
  return tex;
}

function createRealMadridShirtTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const w = 1024;
  const h = 512;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  const drawBaseAndBack = () => {
    const baseGrad = ctx.createLinearGradient(0, 0, 0, h);
    baseGrad.addColorStop(0.0, '#fbfcfd');
    baseGrad.addColorStop(0.55, '#f4f6f9');
    baseGrad.addColorStop(1.0, '#eaedf3');
    ctx.fillStyle = baseGrad;
    ctx.fillRect(0, 0, w, h);

    // Subtle breathable athletic jacquard diamond weave across full shirt & sleeves
    ctx.fillStyle = 'rgba(15, 23, 42, 0.022)';
    for (let y = 0; y < h; y += 6) {
      ctx.fillRect(0, y, w, 1);
    }
    for (let x = 0; x < w; x += 8) {
      ctx.fillRect(x, 0, 1, h);
    }

    // Continuous navy + metallic gold V/crew collar band at top (v ~ 0.92..1.0 -> y = 0..34)
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, w, 20);
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 20, w, 4);
    ctx.fillStyle = '#c89b3c';
    ctx.fillRect(0, 24, w, 9);

    // Subtle 3-stripe gold shoulder/sleeve accent along upper side seams (u = 0 / 0.5 / 1.0)
    const drawSideStripes = (cx: number) => {
      ctx.fillStyle = '#c89b3c';
      ctx.fillRect(cx - 11, 34, 5, 230);
      ctx.fillRect(cx - 2, 34, 5, 230);
      ctx.fillRect(cx + 7, 34, 5, 230);
    };
    drawSideStripes(0);
    drawSideStripes(w * 0.5);
    drawSideStripes(w);

    // Sleeve cuff / shirt hem trim
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, h - 14, w, 6);
    ctx.fillStyle = '#c89b3c';
    ctx.fillRect(0, h - 8, w, 4);

    // Back jersey print centered at u = 0.75 (flipped horizontally so u=+X->-X reads L->R from behind)
    const backX = w * 0.75;
    ctx.save();
    ctx.translate(backX, 0);
    ctx.scale(-1, 1);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#0f172a';
    ctx.font = '800 28px sans-serif';
    ctx.fillText('REAL MADRID', 0, 108);
    ctx.font = '900 132px sans-serif';
    ctx.lineWidth = 5;
    ctx.strokeStyle = '#c89b3c';
    ctx.strokeText('10', 0, 224);
    ctx.fillText('10', 0, 224);
    ctx.restore();
  };

  drawBaseAndBack();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  tex.needsUpdate = true;

  // Composite the AI-generated Real Madrid front jersey artwork accurately onto the front chest UV (u = 0.08..0.42, centered at 0.25)
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    const iw = img.naturalWidth || img.width;
    const ih = img.naturalHeight || img.height;
    if (iw > 16 && ih > 16) {
      drawBaseAndBack();
      const frontX = w * 0.25;
      const panelW = w * 0.34;
      const panelH = h * 0.84;
      const panelY = 34;

      // Flip horizontally around frontX so character's left chest (u < 0.25) & right chest (u > 0.25)
      // match screen left/right without mirroring crest or sponsor text
      ctx.save();
      ctx.translate(frontX, 0);
      ctx.scale(-1, 1);

      // Soft lateral feather mask so jersey panel blends invisibly into white side panels
      ctx.drawImage(
        img,
        iw * 0.16,
        ih * 0.24,
        iw * 0.68,
        ih * 0.74,
        -panelW * 0.5,
        panelY,
        panelW,
        panelH
      );

      // Feather left & right edges smoothly into #f6f7fa base
      const leftEdge = ctx.createLinearGradient(-panelW * 0.5, 0, -panelW * 0.36, 0);
      leftEdge.addColorStop(0.0, 'rgba(246, 247, 250, 1.0)');
      leftEdge.addColorStop(1.0, 'rgba(246, 247, 250, 0.0)');
      ctx.fillStyle = leftEdge;
      ctx.fillRect(-panelW * 0.52, panelY, panelW * 0.18, panelH);

      const rightEdge = ctx.createLinearGradient(panelW * 0.36, 0, panelW * 0.5, 0);
      rightEdge.addColorStop(0.0, 'rgba(246, 247, 250, 0.0)');
      rightEdge.addColorStop(1.0, 'rgba(246, 247, 250, 1.0)');
      ctx.fillStyle = rightEdge;
      ctx.fillRect(panelW * 0.34, panelY, panelW * 0.18, panelH);

      const botEdge = ctx.createLinearGradient(0, panelY + panelH * 0.84, 0, panelY + panelH);
      botEdge.addColorStop(0.0, 'rgba(238, 241, 246, 0.0)');
      botEdge.addColorStop(1.0, 'rgba(238, 241, 246, 1.0)');
      ctx.fillStyle = botEdge;
      ctx.fillRect(-panelW * 0.5, panelY + panelH * 0.84, panelW, panelH * 0.16);
      ctx.restore();

      tex.needsUpdate = true;
    }
  };
  img.src = realMadridJerseyUrl;

  return tex;
}

function createShortsTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const baseGrad = ctx.createLinearGradient(0, 0, 0, size);
  baseGrad.addColorStop(0.0, '#181c26');
  baseGrad.addColorStop(0.5, '#1e2330');
  baseGrad.addColorStop(1.0, '#141720');
  ctx.fillStyle = baseGrad;
  ctx.fillRect(0, 0, size, size);

  ctx.fillStyle = 'rgba(255, 255, 255, 0.025)';
  for (let y = 0; y < size; y += 3) {
    ctx.fillRect(0, y, size, 1);
  }

  ctx.fillStyle = '#101219';
  ctx.fillRect(0, 0, size, 72);
  ctx.strokeStyle = 'rgba(255,255,255,0.16)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 34);
  ctx.lineTo(size, 34);
  ctx.moveTo(0, 72);
  ctx.lineTo(size, 72);
  ctx.stroke();

  ctx.fillStyle = '#f1f5f9';
  ctx.fillRect(size * 0.25 - 10, 32, 4, 46);
  ctx.fillRect(size * 0.25 + 6, 32, 4, 46);

  const drawStripeBand = (cx: number, yStart: number, yEnd: number) => {
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(cx - 9, yStart, 8, yEnd - yStart);
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(cx + 1, yStart, 5, yEnd - yStart);
  };
  // Pelvis outer hip bands (v ~ 0.54..0.85 -> y = 72..234)
  drawStripeBand(10, 72, 234);
  drawStripeBand(size - 10, 72, 234);
  drawStripeBand(size * 0.5, 72, 234);

  // Extended bermuda leg stripes (v ~ 0.04..0.54 -> y = 234..size-18)
  drawStripeBand(10, 234, size - 18);
  drawStripeBand(size - 10, 234, size - 18);

  // Clean bottom bermuda hem accent
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, size - 20, size, 5);
  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(0, size - 15, size, 2);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  tex.needsUpdate = true;
  return tex;
}

interface LoftBuilder {
  positions: number[];
  uvs: number[];
  skinIndices: number[];
  skinWeights: number[];
  torsoMask: number[];
  clothData: number[];
  indices: number[];
}

function createLoftBuilder(): LoftBuilder {
  return {
    positions: [],
    uvs: [],
    skinIndices: [],
    skinWeights: [],
    torsoMask: [],
    clothData: [],
    indices: [],
  };
}

function normalizeWeights(pairs: [number, number][]): {
  idx: [number, number, number, number];
  wt: [number, number, number, number];
} {
  const idx: [number, number, number, number] = [0, 0, 0, 0];
  const wt: [number, number, number, number] = [0, 0, 0, 0];
  let sum = 0;
  const count = Math.min(4, pairs.length);
  for (let i = 0; i < count; i++) {
    idx[i] = pairs[i][0];
    wt[i] = Math.max(0, pairs[i][1]);
    sum += wt[i];
  }
  if (sum > 1e-6) {
    for (let i = 0; i < count; i++) wt[i] /= sum;
  } else {
    wt[0] = 1;
  }
  return { idx, wt };
}

/**
 * Extracts ordered closed boundary loops (welded by quantized position so UV seams don't split loops)
 * preserving the original directed half-edge orientation of the source geometry.
 */
function extractDirectedBoundaryLoops(
  geo: THREE.BufferGeometry,
  triPredicate?: (ia: number, ib: number, ic: number) => boolean
): number[][] {
  const posAttr = geo.attributes.position as THREE.BufferAttribute | undefined;
  const indexAttr = geo.index;
  if (!posAttr || !indexAttr) return [];

  const vertKeys: string[] = new Array(posAttr.count);
  for (let i = 0; i < posAttr.count; i++) {
    const qx = Math.round(posAttr.getX(i) * 2000);
    const qy = Math.round(posAttr.getY(i) * 2000);
    const qz = Math.round(posAttr.getZ(i) * 2000);
    vertKeys[i] = `${qx},${qy},${qz}`;
  }

  interface DirectedEdgeRec {
    count: number;
    ku: string;
    kv: string;
    u: number;
    v: number;
  }
  const edgeMap = new Map<string, DirectedEdgeRec>();

  for (let t = 0; t < indexAttr.count; t += 3) {
    const a = indexAttr.getX(t);
    const b = indexAttr.getX(t + 1);
    const c = indexAttr.getX(t + 2);
    if (triPredicate && !triPredicate(a, b, c)) continue;

    const triEdges: [number, number][] = [
      [a, b],
      [b, c],
      [c, a],
    ];
    for (let e = 0; e < 3; e++) {
      const u = triEdges[e][0];
      const v = triEdges[e][1];
      const ku = vertKeys[u];
      const kv = vertKeys[v];
      if (ku === kv) continue;
      const undir = ku < kv ? `${ku}|${kv}` : `${kv}|${ku}`;
      let rec = edgeMap.get(undir);
      if (!rec) {
        rec = { count: 0, ku, kv, u, v };
        edgeMap.set(undir, rec);
      }
      rec.count++;
      rec.ku = ku;
      rec.kv = kv;
      rec.u = u;
      rec.v = v;
    }
  }

  const adj = new Map<string, DirectedEdgeRec[]>();
  for (const rec of edgeMap.values()) {
    if (rec.count === 1) {
      let arr = adj.get(rec.ku);
      if (!arr) {
        arr = [];
        adj.set(rec.ku, arr);
      }
      arr.push(rec);
    }
  }

  const visited = new Set<string>();
  const loops: number[][] = [];
  for (const edges of adj.values()) {
    for (const firstEdge of edges) {
      const firstKey = `${firstEdge.ku}->${firstEdge.kv}`;
      if (visited.has(firstKey)) continue;
      const loop: number[] = [];
      let nextEdge: DirectedEdgeRec | undefined = firstEdge;
      let endK = firstEdge.ku;
      while (nextEdge) {
        const ek = `${nextEdge.ku}->${nextEdge.kv}`;
        if (visited.has(ek)) break;
        visited.add(ek);
        loop.push(nextEdge.u);
        endK = nextEdge.kv;
        const cands = adj.get(endK) || [];
        nextEdge = cands.find((e) => !visited.has(`${e.ku}->${e.kv}`));
      }
      if (loop.length >= 6 && endK === firstEdge.ku) {
        loops.push(loop);
      }
    }
  }
  return loops;
}

/**
 * Adds a smooth tubular loft along a list of cross-sections aligned to a local axis frame.
 */
function addTubeLoft(
  b: LoftBuilder,
  slices: CrossSectionSlice[],
  radialSegs: number,
  options?: {
    axisForward?: THREE.Vector3;
    axisRight?: THREE.Vector3;
    startHemInset?: number;
    endHemInset?: number;
    uOffset?: number;
    torsoMaskPerVertex?: (pos: THREE.Vector3, baseMask: [number, number]) => [number, number];
    weightsPerVertex?: (pos: THREE.Vector3, baseWeights: [number, number][]) => [number, number][];
  }
): void {
  if (slices.length < 2) return;
  const ringVerts = radialSegs + 1;
  const uOff = options?.uOffset ?? 0;

  const allSlices: CrossSectionSlice[] = [];
  if (options?.startHemInset && options.startHemInset > 0) {
    const first = slices[0];
    const second = slices[1];
    const dir = new THREE.Vector3().subVectors(second.center, first.center).normalize();
    allSlices.push({
      center: first.center.clone().addScaledVector(dir, 0.012),
      rx: Math.max(0.01, first.rx - options.startHemInset),
      rz: Math.max(0.01, first.rz - options.startHemInset),
      v: first.v,
      weights: first.weights,
      torsoMask: first.torsoMask,
      clothFreedom: first.clothFreedom,
      clothIsSleeve: first.clothIsSleeve,
      clothHemFactor: first.clothHemFactor,
      posPerVertex: first.posPerVertex,
    });
  }
  for (const s of slices) allSlices.push(s);
  if (options?.endHemInset && options.endHemInset > 0) {
    const last = slices[slices.length - 1];
    const prev = slices[slices.length - 2];
    const dir = new THREE.Vector3().subVectors(prev.center, last.center).normalize();
    allSlices.push({
      center: last.center.clone().addScaledVector(dir, 0.012),
      rx: Math.max(0.01, last.rx - options.endHemInset),
      rz: Math.max(0.01, last.rz - options.endHemInset),
      v: last.v,
      weights: last.weights,
      torsoMask: last.torsoMask,
      clothFreedom: last.clothFreedom,
      clothIsSleeve: last.clothIsSleeve,
      clothHemFactor: last.clothHemFactor,
      posPerVertex: last.posPerVertex,
    });
  }

  const baseVertexIndex = b.positions.length / 3;
  const tmp = new THREE.Vector3();
  const rightAxis = new THREE.Vector3(1, 0, 0);
  const fwdAxis = new THREE.Vector3(0, 0, 1);
  const tangent = new THREE.Vector3();
  const refZ = new THREE.Vector3(0, 0, 1);

  for (let sIdx = 0; sIdx < allSlices.length; sIdx++) {
    const sl = allSlices[sIdx];
    const prev = allSlices[Math.max(0, sIdx - 1)];
    const next = allSlices[Math.min(allSlices.length - 1, sIdx + 1)];
    tangent.subVectors(next.center, prev.center);

    if (options?.axisRight && options?.axisForward) {
      rightAxis.copy(options.axisRight);
      fwdAxis.copy(options.axisForward);
    } else if (tangent.lengthSq() > 1e-6) {
      tangent.normalize();
      rightAxis.crossVectors(tangent, refZ);
      if (rightAxis.lengthSq() < 0.05) {
        rightAxis.set(1, 0, 0);
      } else {
        rightAxis.normalize();
      }
      fwdAxis.crossVectors(rightAxis, tangent).normalize();
      if (fwdAxis.z < 0 && Math.abs(tangent.y) > 0.5) {
        fwdAxis.negate();
        rightAxis.negate();
      }
    }

    for (let r = 0; r <= radialSegs; r++) {
      const frac = r / radialSegs;
      const theta = frac * Math.PI * 2;
      const cosT = Math.cos(theta);
      const sinT = Math.sin(theta);

      const localR_x = sl.rx * cosT;
      let localR_z = sl.rz * sinT;
      if (sl.frontPush && sinT > 0) {
        localR_z += sl.frontPush * sinT * sinT;
      }
      if (sl.backPush && sinT < 0) {
        localR_z -= sl.backPush * sinT * sinT;
      }

      tmp
        .copy(sl.center)
        .addScaledVector(rightAxis, localR_x)
        .addScaledVector(fwdAxis, localR_z);

      if (sl.posPerVertex) {
        sl.posPerVertex(tmp, sinT, cosT, theta);
      }

      b.positions.push(tmp.x, tmp.y, tmp.z);
      b.uvs.push(frac + uOff, sl.v);

      const pairs = options?.weightsPerVertex
        ? options.weightsPerVertex(tmp, sl.weights)
        : sl.weights;
      const { idx, wt } = normalizeWeights(pairs);
      b.skinIndices.push(idx[0], idx[1], idx[2], idx[3]);
      b.skinWeights.push(wt[0], wt[1], wt[2], wt[3]);

      const m = options?.torsoMaskPerVertex
        ? options.torsoMaskPerVertex(tmp, sl.torsoMask)
        : sl.torsoMask;
      b.torsoMask.push(m[0], m[1]);

      b.clothData.push(
        sl.clothFreedom ?? 0,
        theta,
        sl.clothIsSleeve ?? 0,
        sl.clothHemFactor ?? 0
      );
    }
  }

  for (let sIdx = 0; sIdx < allSlices.length - 1; sIdx++) {
    const row0 = baseVertexIndex + sIdx * ringVerts;
    const row1 = baseVertexIndex + (sIdx + 1) * ringVerts;
    for (let r = 0; r < radialSegs; r++) {
      const a = row0 + r;
      const bV = row0 + r + 1;
      const c = row1 + r;
      const d = row1 + r + 1;
      b.indices.push(a, c, bV);
      b.indices.push(bV, c, d);
    }
  }
}

function finalizeLoftGeometry(b: LoftBuilder): THREE.BufferGeometry {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(b.positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(b.uvs, 2));
  geo.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(b.skinIndices, 4));
  geo.setAttribute('skinWeight', new THREE.Float32BufferAttribute(b.skinWeights, 4));
  geo.setAttribute('aTorsoMask', new THREE.Float32BufferAttribute(b.torsoMask, 2));
  geo.setAttribute('aClothData', new THREE.Float32BufferAttribute(b.clothData, 4));
  geo.setIndex(b.indices);
  geo.computeVertexNormals();
  geo.computeBoundingSphere();
  return geo;
}

/**
 * Stitches chest/clavicle skin directly downward from Wolf3D_Skin's exact 24-vertex bottom neck rim,
 * preserving identical boundary positions and bone weights so the neck cannot tear or gap in any pose.
 */
function stitchWolf3DNeckBridge(
  b: LoftBuilder,
  skinMesh: THREE.Mesh,
  object5: THREE.SkinnedMesh,
  ji: JointIndices
): boolean {
  const sGeo = skinMesh.geometry as THREE.BufferGeometry;
  const loops = extractDirectedBoundaryLoops(sGeo);
  if (loops.length === 0) return false;

  const posAttr = sGeo.attributes.position as THREE.BufferAttribute;
  const skinIdxAttr = sGeo.attributes.skinIndex as THREE.BufferAttribute | undefined;
  const skinWtAttr = sGeo.attributes.skinWeight as THREE.BufferAttribute | undefined;
  if (!posAttr || !skinIdxAttr || !skinWtAttr) return false;

  // Pick bottom neck loop (~y = 1.538)
  let neckLoop = loops[0];
  let bestAvgY = Infinity;
  for (const lp of loops) {
    let sy = 0;
    for (const vi of lp) sy += posAttr.getY(vi);
    const avgY = sy / lp.length;
    if (avgY < bestAvgY) {
      bestAvgY = avgY;
      neckLoop = lp;
    }
  }
  const N = neckLoop.length;
  if (N < 8) return false;

  // Map bone indices from skinMesh.skeleton -> object5.skeleton by bone name
  const skinSkinned = skinMesh as THREE.SkinnedMesh;
  const boneMap = new Map<number, number>();
  if (skinSkinned.skeleton && skinSkinned.skeleton !== object5.skeleton) {
    const objBoneByName = new Map<string, number>();
    object5.skeleton.bones.forEach((bone, idx) => {
      if (bone.name) objBoneByName.set(bone.name, idx);
    });
    skinSkinned.skeleton.bones.forEach((bone, idx) => {
      const mapped = objBoneByName.get(bone.name);
      boneMap.set(idx, mapped !== undefined ? mapped : idx);
    });
  }

  // Transform skinMesh local coordinates -> object5 local coordinates
  const invObjBind = new THREE.Matrix4().copy(object5.bindMatrix).invert();
  const srcBind = skinSkinned.bindMatrix ? skinSkinned.bindMatrix : new THREE.Matrix4();
  const toObj5 = new THREE.Matrix4().multiplyMatrices(invObjBind, srcBind);

  const rimPositions: THREE.Vector3[] = [];
  const rimWeights: [number, number][][] = [];
  const center = new THREE.Vector3();

  for (let i = 0; i < N; i++) {
    const vi = neckLoop[i];
    const p = new THREE.Vector3(posAttr.getX(vi), posAttr.getY(vi), posAttr.getZ(vi)).applyMatrix4(
      toObj5
    );
    rimPositions.push(p);
    center.add(p);

    const pairs: [number, number][] = [];
    for (let k = 0; k < 4; k++) {
      const srcBone = skinIdxAttr.getComponent(vi, k);
      const wt = skinWtAttr.getComponent(vi, k);
      if (wt > 1e-4) {
        pairs.push([boneMap.get(srcBone) ?? srcBone, wt]);
      }
    }
    rimWeights.push(pairs);
  }
  center.divideScalar(N);

  const rings: {
    pos: THREE.Vector3[];
    w: [number, number][][];
    v: number;
  }[] = [
    { pos: rimPositions, w: rimWeights, v: 0.96 },
    { pos: [], w: [], v: 0.56 },
    { pos: [], w: [], v: 0.14 },
  ];

  // Build two downward neck->chest bridge rings that taper CLEANLY INWARD inside the shirt collar
  // (Wolf3D_Skin neck rim center is at cx=0, cy=1.5457, cz=-0.0236)
  for (let i = 0; i < N; i++) {
    const p0 = rimPositions[i];
    const dx = p0.x - center.x;
    const dz = p0.z - center.z;
    const ang = Math.atan2(dz, dx);
    const cosA = Math.cos(ang);
    const sinA = Math.sin(ang);

    const clavTarget = new THREE.Vector3(
      center.x + 0.070 * cosA,
      1.485,
      -0.024 + 0.046 * sinA
    );
    const p1 = new THREE.Vector3().lerpVectors(p0, clavTarget, 0.78);
    rings[1].pos.push(p1);

    // Smoothly blend rim weights into upper-chest (Spine2) so neck bridge stays aligned beneath shirt collar
    const w1: [number, number][] = [];
    for (const [bi, bw] of rimWeights[i]) {
      w1.push([bi, bw * 0.48]);
    }
    w1.push([ji.spine2, 0.46]);
    w1.push([ji.neck, 0.06]);
    rings[1].w.push(w1);

    const chestTarget = new THREE.Vector3(
      center.x + 0.065 * cosA,
      1.415,
      -0.024 + 0.042 * sinA
    );
    rings[2].pos.push(chestTarget);
    rings[2].w.push([
      [ji.spine2, 0.94],
      [ji.neck, 0.06],
    ]);
  }

  const baseVertIdx = b.positions.length / 3;
  for (let r = 0; r < rings.length; r++) {
    const rg = rings[r];
    for (let i = 0; i < N; i++) {
      const p = rg.pos[i];
      const u = Math.atan2(p.z - center.z, p.x - center.x) / (Math.PI * 2) + 0.5;
      b.positions.push(p.x, p.y, p.z);
      b.uvs.push(u, rg.v);

      const { idx, wt } = normalizeWeights(rg.w[i]);
      b.skinIndices.push(idx[0], idx[1], idx[2], idx[3]);
      b.skinWeights.push(wt[0], wt[1], wt[2], wt[3]);
      b.torsoMask.push(1, 1);
      b.clothData.push(0, 0, 0, 0);
    }
  }

  // Since source boundary edge (u -> v) belongs to Wolf3D_Skin above,
  // extending downward uses reversed edge orientation (v, u, uBelow), (v, uBelow, vBelow).
  for (let r = 0; r < rings.length - 1; r++) {
    const rowAbove = baseVertIdx + r * N;
    const rowBelow = baseVertIdx + (r + 1) * N;
    for (let i = 0; i < N; i++) {
      const nextI = (i + 1) % N;
      const u = rowAbove + i;
      const v = rowAbove + nextI;
      const uBelow = rowBelow + i;
      const vBelow = rowBelow + nextI;
      b.indices.push(v, u, uBelow);
      b.indices.push(v, uBelow, vBelow);
    }
  }
  return true;
}

/**
 * Extracts only the hands (from wrist distally, hw >= 0.62) out of Wolf3D_Outfit_Top (`object5`),
 * preserving 5-finger skeletal skinning, clean wrist glove mask, and returning both 16-vertex wrist loops.
 */
function buildHandsOnlyMesh(
  object5: THREE.SkinnedMesh,
  handBoneIndices: Set<number>,
  gloveUniforms: GloveShaderUniforms | undefined,
  skinRgb: [number, number, number]
): {
  mesh: THREE.SkinnedMesh;
  material: THREE.MeshStandardMaterial;
  leftWristLoop: number[];
  rightWristLoop: number[];
} {
  const srcGeo = object5.geometry as THREE.BufferGeometry;
  const posAttr = srcGeo.attributes.position as THREE.BufferAttribute;
  const skinIdxAttr = srcGeo.attributes.skinIndex as THREE.BufferAttribute;
  const skinWtAttr = srcGeo.attributes.skinWeight as THREE.BufferAttribute;
  const indexAttr = srcGeo.index;

  const vertHandWeight = new Float32Array(posAttr.count);
  const isHandVert = new Uint8Array(posAttr.count);
  for (let i = 0; i < posAttr.count; i++) {
    let hw = 0;
    for (let k = 0; k < 4; k++) {
      if (handBoneIndices.has(skinIdxAttr.getComponent(i, k))) {
        hw += skinWtAttr.getComponent(i, k);
      }
    }
    vertHandWeight[i] = hw;
    // Threshold 0.62 yields exact closed 16-vertex boundary loops on both Left & Right wrists
    if (hw >= 0.62) {
      isHandVert[i] = 1;
    }
  }

  const triIndices: number[] = [];
  if (indexAttr) {
    for (let i = 0; i < indexAttr.count; i += 3) {
      const ia = indexAttr.getX(i);
      const ib = indexAttr.getX(i + 1);
      const ic = indexAttr.getX(i + 2);
      if (isHandVert[ia] && isHandVert[ib] && isHandVert[ic]) {
        triIndices.push(ia, ib, ic);
      }
    }
  }

  const remap = new Int32Array(posAttr.count);
  remap.fill(-1);
  const uniqueVerts: number[] = [];
  const newIndices = new Uint16Array(triIndices.length);
  for (let i = 0; i < triIndices.length; i++) {
    const oldV = triIndices[i];
    let mapped = remap[oldV];
    if (mapped === -1) {
      mapped = uniqueVerts.length;
      remap[oldV] = mapped;
      uniqueVerts.push(oldV);
    }
    newIndices[i] = mapped;
  }

  const outGeo = new THREE.BufferGeometry();
  const vCount = uniqueVerts.length;
  for (const [attrName, attr] of Object.entries(srcGeo.attributes)) {
    const itemSize = attr.itemSize;
    if (attrName === 'aTorsoMask') {
      outGeo.setAttribute(attrName, new THREE.Float32BufferAttribute(new Float32Array(vCount * 2), 2));
      continue;
    }
    const isIntAttr = attrName === 'skinIndex';
    const dstArr = isIntAttr
      ? new Uint16Array(vCount * itemSize)
      : new Float32Array(vCount * itemSize);
    for (let v = 0; v < vCount; v++) {
      const oldIdx = uniqueVerts[v];
      for (let k = 0; k < itemSize; k++) {
        dstArr[v * itemSize + k] = attr.getComponent(oldIdx, k);
      }
    }
    outGeo.setAttribute(attrName, new THREE.BufferAttribute(dstArr, itemSize));
  }
  outGeo.setIndex(new THREE.BufferAttribute(newIndices, 1));

  // Recompute clean glove coverage & bare-hand anatomical coordinates on handsGeo
  const outPos = outGeo.attributes.position as THREE.BufferAttribute;
  const outNorm = outGeo.attributes.normal as THREE.BufferAttribute | undefined;
  const gData = new Float32Array(vCount * 4);
  const bareData = new Float32Array(vCount * 4);
  for (let v = 0; v < vCount; v++) {
    const oldIdx = uniqueVerts[v];
    const hw = vertHandWeight[oldIdx];
    const px = outPos.getX(v);
    const py = outPos.getY(v);
    const pz = outPos.getZ(v);
    const nx = outNorm ? outNorm.getX(v) : Math.sign(px);
    const ax = Math.abs(px);

    const gMask = smoothstep(0.60, 0.72, hw);
    const gU = (ax - 0.42) * 5.0;
    const gV = (pz - 0.02) * 8.0;
    let gZone = 0.0;
    if (hw < 0.73) {
      gZone = 0.35; // Wrist cuff
    } else if (ax > 0.46 && ax < 0.51 && py < 1.06) {
      gZone = 0.85; // Carbon knuckle bridge
    }
    gData[v * 4] = gMask;
    gData[v * 4 + 1] = gU;
    gData[v * 4 + 2] = gV;
    gData[v * 4 + 3] = gZone;

    // Bind-pose bare hand coordinates:
    // x: alongHand (0 = wrist y=1.065 -> 1 = fingertips y=0.892)
    // y: isDorsal (1 = back of hand/knuckles, 0 = palm/inside grip)
    // z: sideU, w: thumb/lateral spread
    const alongHand = clamp01((1.065 - py) / 0.172);
    const signX = px >= 0 ? 1 : -1;
    const isDorsal = smoothstep(-0.22, 0.34, signX * nx);
    const sideU = (pz - 0.02) * 4.5 + 0.5;
    bareData[v * 4] = alongHand;
    bareData[v * 4 + 1] = isDorsal;
    bareData[v * 4 + 2] = sideU;
    bareData[v * 4 + 3] = 1.0;
  }
  outGeo.setAttribute('aGloveData', new THREE.Float32BufferAttribute(gData, 4));
  outGeo.setAttribute('aBareHandData', new THREE.Float32BufferAttribute(bareData, 4));
  outGeo.computeBoundingSphere();

  const loops = extractDirectedBoundaryLoops(outGeo);
  let leftWristLoop: number[] = [];
  let rightWristLoop: number[] = [];
  for (const lp of loops) {
    let sx = 0;
    for (const vi of lp) sx += outPos.getX(vi);
    const avgX = sx / lp.length;
    if (avgX > 0 && lp.length > leftWristLoop.length) leftWristLoop = lp;
    if (avgX < 0 && lp.length > rightWristLoop.length) rightWristLoop = lp;
  }

  // Dedicated material so bare hands ("Sem Luva") replace baked GLB glove completely with true skin hands
  const baseMat = (
    Array.isArray(object5.material) ? object5.material[0] : object5.material
  ) as THREE.MeshStandardMaterial;
  const handsMat = baseMat.clone() as THREE.MeshStandardMaterial;
  handsMat.envMapIntensity = 0.85;

  const skinLinear = new THREE.Color(
    skinRgb[0] / 255,
    skinRgb[1] / 255,
    skinRgb[2] / 255
  ).convertSRGBToLinear();
  const bareSkinTex = gloveUniforms?.uBareHandMap?.value ?? createSkinTexture(skinRgb, 4);

  if (gloveUniforms) {
    handsMat.customProgramCacheKey = () => 'rider_cs_hands_v3';
    handsMat.onBeforeCompile = (shader) => {
      shader.uniforms.uGloveEnabled = gloveUniforms.uGloveEnabled;
      shader.uniforms.uGlovePrimary = gloveUniforms.uGlovePrimary;
      shader.uniforms.uGloveAccent = gloveUniforms.uGloveAccent;
      shader.uniforms.uGloveMap = gloveUniforms.uGloveMap;
      shader.uniforms.uCarbonMap = gloveUniforms.uCarbonMap;
      shader.uniforms.uBareHandMap = gloveUniforms.uBareHandMap ?? { value: bareSkinTex };
      shader.uniforms.uSkinBaseColor = gloveUniforms.uSkinBaseColor ?? { value: skinLinear };

      shader.vertexShader = shader.vertexShader
        .replace(
          '#include <common>',
          '#include <common>\nattribute vec4 aGloveData;\nattribute vec4 aBareHandData;\nvarying vec4 vGloveData;\nvarying vec4 vBareHandData;'
        )
        .replace(
          '#include <begin_vertex>',
          '#include <begin_vertex>\nvGloveData = aGloveData;\nvBareHandData = aBareHandData;'
        );

      shader.fragmentShader = shader.fragmentShader
        .replace(
          '#include <common>',
          `#include <common>
uniform float uGloveEnabled;
uniform vec3 uGlovePrimary;
uniform vec3 uGloveAccent;
uniform vec3 uSkinBaseColor;
uniform sampler2D uGloveMap;
uniform sampler2D uCarbonMap;
uniform sampler2D uBareHandMap;
varying vec4 vGloveData;
varying vec4 vBareHandData;`
        )
        .replace(
          '#include <map_fragment>',
          `#include <map_fragment>
if (uGloveEnabled > 0.5) {
  float gMask = clamp(vGloveData.x * 1.15 + 0.12, 0.0, 1.0);
  vec2 gUv = vec2(vGloveData.y * 1.45, vGloveData.z * 0.55 + 0.5);
  vec3 rawG = texture2D(uGloveMap, gUv).rgb;
  vec3 aiTex = rawG * rawG;
  vec3 rawC = texture2D(uCarbonMap, gUv * 2.5).rgb;
  vec3 carbTex = rawC * rawC;

  float isCuff = smoothstep(0.15, 0.45, vGloveData.w) * (1.0 - smoothstep(0.55, 0.75, vGloveData.w));
  float isKnuckle = smoothstep(0.65, 0.92, vGloveData.w);

  vec3 leatherColor = aiTex * uGlovePrimary * 1.68;
  vec3 cuffColor = aiTex * uGloveAccent * 1.50;
  vec3 knuckleColor = mix(carbTex * 0.75, uGloveAccent * 0.45, 0.22);

  vec3 gloveCol = mix(leatherColor, cuffColor, isCuff);
  gloveCol = mix(gloveCol, knuckleColor, isKnuckle);
  diffuseColor.rgb = mix(diffuseColor.rgb, gloveCol, gMask);
} else {
  // True bare human hand ("Sem Luva"): replace baked GLB glove completely with matching skin
  float along = vBareHandData.x;
  float dorsal = vBareHandData.y;
  vec2 bUv = vec2(fract(vBareHandData.z * 0.75 + 0.25), clamp(0.15 + along * 0.75, 0.02, 0.98));
  vec3 skinTexCol = texture2D(uBareHandMap, bUv).rgb;
  vec3 palmShade = mix(skinTexCol * vec3(1.09, 1.01, 0.98), skinTexCol, dorsal);
  float knuckleBand = exp(-pow((along - 0.44) / 0.085, 2.0)) * dorsal;
  palmShade = mix(palmShade, skinTexCol * vec3(1.03, 0.87, 0.82), knuckleBand * 0.48);
  float jointCrease = smoothstep(0.55, 0.98, sin((along - 0.42) * 32.0)) * smoothstep(0.42, 0.65, along);
  palmShade *= (1.0 - jointCrease * 0.065);
  float nailMask = smoothstep(0.84, 0.95, along) * smoothstep(0.55, 0.88, dorsal);
  vec3 nailCol = skinTexCol * vec3(1.16, 1.10, 1.07) + vec3(0.035, 0.026, 0.025);
  diffuseColor.rgb = mix(palmShade, nailCol, nailMask * 0.58);
}`
        )
        .replace(
          '#include <normal_fragment_maps>',
          `vec3 bareGeoNormal = normal;
#include <normal_fragment_maps>
if (uGloveEnabled <= 0.5) {
  normal = normalize(mix(normal, bareGeoNormal, 0.94));
}`
        )
        .replace(
          '#include <roughnessmap_fragment>',
          `#include <roughnessmap_fragment>
if (uGloveEnabled > 0.5) {
  float gMaskR = clamp(vGloveData.x * 1.15 + 0.12, 0.0, 1.0);
  roughnessFactor = mix(roughnessFactor, 0.44, gMaskR);
} else {
  roughnessFactor = 0.64;
}`
        )
        .replace(
          '#include <metalnessmap_fragment>',
          `#include <metalnessmap_fragment>
if (uGloveEnabled <= 0.5) {
  metalnessFactor = 0.02;
}`
        );
    };
  }

  const handsMesh = new THREE.SkinnedMesh(outGeo, handsMat);
  handsMesh.name = 'Rider_CamisaShort_Hands';
  handsMesh.castShadow = false;
  handsMesh.receiveShadow = false;
  handsMesh.frustumCulled = false;
  handsMesh.bind(object5.skeleton, object5.bindMatrix);
  return { mesh: handsMesh, material: handsMat, leftWristLoop, rightWristLoop };
}

/**
 * Builds one bare arm (inside shoulder socket -> bicep -> elbow -> forearm) stitched vertex-for-vertex
 * onto the hand mesh's exact 16-vertex wrist boundary loop (preserving exact wrist vertex positions and skin weights).
 */
function buildArmSkinStitchedToWrist(
  b: LoftBuilder,
  shoulderPos: THREE.Vector3,
  armPos: THREE.Vector3,
  forePos: THREE.Vector3,
  handPos: THREE.Vector3,
  iSpine2: number,
  iShoulder: number,
  iArm: number,
  iFore: number,
  iHand: number,
  handsGeo: THREE.BufferGeometry | null,
  wristLoop: number[]
): void {
  const armSamples: CrossSectionSlice[] = [
    // Tuck upper arm cleanly down into lowered shoulder socket inside sleeve
    {
      center: new THREE.Vector3().lerpVectors(shoulderPos, armPos, 0.50).add(new THREE.Vector3(0, -0.028, 0)),
      rx: 0.047,
      rz: 0.049,
      v: 0.08,
      weights: [
        [iSpine2, 0.18],
        [iShoulder, 0.44],
        [iArm, 0.38],
      ],
      torsoMask: [0, 0],
    },
    {
      center: armPos.clone().add(new THREE.Vector3(0, -0.022, 0)),
      rx: 0.048,
      rz: 0.049,
      v: 0.18,
      weights: [
        [iShoulder, 0.22],
        [iArm, 0.78],
      ],
      torsoMask: [0, 0],
    },
    {
      center: new THREE.Vector3().lerpVectors(armPos, forePos, 0.26).add(new THREE.Vector3(0, -0.008, 0)),
      rx: 0.048,
      rz: 0.048,
      v: 0.30,
      weights: [
        [iArm, 0.92],
        [iFore, 0.08],
      ],
      torsoMask: [0, 0],
      frontPush: 0.004,
    },
    {
      center: new THREE.Vector3().lerpVectors(armPos, forePos, 0.56),
      rx: 0.050,
      rz: 0.048,
      v: 0.42,
      weights: [
        [iArm, 0.85],
        [iFore, 0.15],
      ],
      torsoMask: [0, 0],
      frontPush: 0.004,
    },
    {
      center: new THREE.Vector3().lerpVectors(armPos, forePos, 0.84),
      rx: 0.045,
      rz: 0.043,
      v: 0.51,
      weights: [
        [iArm, 0.65],
        [iFore, 0.35],
      ],
      torsoMask: [0, 0],
    },
    {
      center: forePos.clone(),
      rx: 0.044,
      rz: 0.042,
      v: 0.57,
      weights: [
        [iArm, 0.32],
        [iFore, 0.68],
      ],
      torsoMask: [0, 0],
    },
    {
      center: new THREE.Vector3().lerpVectors(forePos, handPos, 0.25),
      rx: 0.046,
      rz: 0.043,
      v: 0.67,
      weights: [
        [iFore, 0.92],
        [iHand, 0.08],
      ],
      torsoMask: [0, 0],
      frontPush: 0.004,
    },
    {
      center: new THREE.Vector3().lerpVectors(forePos, handPos, 0.52),
      rx: 0.039,
      rz: 0.036,
      v: 0.78,
      weights: [
        [iFore, 0.86],
        [iHand, 0.14],
      ],
      torsoMask: [0, 0],
    },
    {
      center: new THREE.Vector3().lerpVectors(forePos, handPos, 0.74),
      rx: 0.034,
      rz: 0.030,
      v: 0.88,
      weights: [
        [iFore, 0.68],
        [iHand, 0.32],
      ],
      torsoMask: [0, 0],
    },
  ];

  // Fallback to pure tubular loft if no wrist loop was available
  if (!handsGeo || wristLoop.length < 6) {
    armSamples.push({
      center: handPos.clone(),
      rx: 0.028,
      rz: 0.024,
      v: 0.98,
      weights: [
        [iFore, 0.30],
        [iHand, 0.70],
      ],
      torsoMask: [0, 0],
    });
    addTubeLoft(b, armSamples, 18);
    return;
  }

  const hPos = handsGeo.attributes.position as THREE.BufferAttribute;
  const hIdx = handsGeo.attributes.skinIndex as THREE.BufferAttribute;
  const hWt = handsGeo.attributes.skinWeight as THREE.BufferAttribute;

  const M = wristLoop.length;
  const wristVerts: THREE.Vector3[] = [];
  const wristWeights: [number, number][][] = [];
  const wristCenter = new THREE.Vector3();
  for (let i = 0; i < M; i++) {
    const vi = wristLoop[i];
    const p = new THREE.Vector3(hPos.getX(vi), hPos.getY(vi), hPos.getZ(vi));
    wristVerts.push(p);
    wristCenter.add(p);

    const pairs: [number, number][] = [];
    for (let k = 0; k < 4; k++) {
      const wt = hWt.getComponent(vi, k);
      if (wt > 1e-4) pairs.push([hIdx.getComponent(vi, k), wt]);
    }
    wristWeights.push(pairs);
  }
  wristCenter.divideScalar(M);

  // Frame at the wrist ring matching tangent = forePos -> wristCenter
  const wristTan = new THREE.Vector3().subVectors(wristCenter, forePos).normalize();
  const refZ = new THREE.Vector3(0, 0, 1);
  const wRight = new THREE.Vector3().crossVectors(wristTan, refZ);
  if (wRight.lengthSq() < 0.05) wRight.set(1, 0, 0);
  else wRight.normalize();
  const wFwd = new THREE.Vector3().crossVectors(wRight, wristTan).normalize();

  // Record exact polar angles around the wrist boundary loop so every proximal ring aligns with zero twist
  const loopThetas: number[] = [];
  for (let i = 0; i < M; i++) {
    const rel = new THREE.Vector3().subVectors(wristVerts[i], wristCenter);
    loopThetas.push(Math.atan2(rel.dot(wFwd), rel.dot(wRight)));
  }

  // Smooth intermediate bridge slice at ~90% forearm (60% toward exact wrist contour)
  const bridgeCenter = new THREE.Vector3().lerpVectors(forePos, wristCenter, 0.87);
  const bridgeRing: THREE.Vector3[] = [];
  const bridgeWeights: [number, number][][] = [];
  for (let i = 0; i < M; i++) {
    const theta = loopThetas[i];
    const cosT = Math.cos(theta);
    const sinT = Math.sin(theta);
    const circPt = bridgeCenter
      .clone()
      .addScaledVector(wRight, 0.031 * cosT)
      .addScaledVector(wFwd, 0.027 * sinT);
    const wristOffset = new THREE.Vector3().subVectors(wristVerts[i], wristCenter);
    const shapedPt = bridgeCenter.clone().addScaledVector(wristOffset, 0.96);
    bridgeRing.push(new THREE.Vector3().lerpVectors(circPt, shapedPt, 0.55));

    // Blend forearm weights with exact wrist-vertex multi-bone weights (ForeArm + Hand + Thumb)
    const wBlend: [number, number][] = [];
    for (const [bi, bw] of wristWeights[i]) {
      wBlend.push([bi, bw * 0.58]);
    }
    wBlend.push([iFore, 0.42]);
    bridgeWeights.push(wBlend);
  }

  // Generate all proximal arm rings at the exact angular sequence loopThetas[0..M-1]
  const baseVertIdx = b.positions.length / 3;
  const totalRings = armSamples.length + 2; // armSamples + bridgeRing + exact wristVerts
  const rightAxis = new THREE.Vector3();
  const fwdAxis = new THREE.Vector3();
  const tangent = new THREE.Vector3();
  const tmp = new THREE.Vector3();

  for (let sIdx = 0; sIdx < armSamples.length; sIdx++) {
    const sl = armSamples[sIdx];
    const prev = armSamples[Math.max(0, sIdx - 1)];
    const next = sIdx < armSamples.length - 1 ? armSamples[sIdx + 1] : { center: bridgeCenter };
    tangent.subVectors(next.center, prev.center).normalize();
    rightAxis.crossVectors(tangent, refZ);
    if (rightAxis.lengthSq() < 0.05) rightAxis.set(1, 0, 0);
    else rightAxis.normalize();
    fwdAxis.crossVectors(rightAxis, tangent).normalize();

    const { idx, wt } = normalizeWeights(sl.weights);
    for (let i = 0; i < M; i++) {
      const theta = loopThetas[i];
      const cosT = Math.cos(theta);
      const sinT = Math.sin(theta);
      const localRx = sl.rx * cosT;
      let localRz = sl.rz * sinT;
      if (sl.frontPush && sinT > 0) localRz += sl.frontPush * sinT * sinT;
      if (sl.backPush && sinT < 0) localRz -= sl.backPush * sinT * sinT;

      tmp
        .copy(sl.center)
        .addScaledVector(rightAxis, localRx)
        .addScaledVector(fwdAxis, localRz);
      b.positions.push(tmp.x, tmp.y, tmp.z);
      b.uvs.push(i / M, sl.v);
      b.skinIndices.push(idx[0], idx[1], idx[2], idx[3]);
      b.skinWeights.push(wt[0], wt[1], wt[2], wt[3]);
      b.torsoMask.push(0, 0);
      b.clothData.push(0, 0, 0, 0);
    }
  }

  // Emit bridge ring
  for (let i = 0; i < M; i++) {
    const p = bridgeRing[i];
    const { idx, wt } = normalizeWeights(bridgeWeights[i]);
    b.positions.push(p.x, p.y, p.z);
    b.uvs.push(i / M, 0.94);
    b.skinIndices.push(idx[0], idx[1], idx[2], idx[3]);
    b.skinWeights.push(wt[0], wt[1], wt[2], wt[3]);
    b.torsoMask.push(0, 0);
    b.clothData.push(0, 0, 0, 0);
  }

  // Emit exact wrist seam ring (identical positions + weights as handsGeo boundary loop!)
  for (let i = 0; i < M; i++) {
    const p = wristVerts[i];
    const { idx, wt } = normalizeWeights(wristWeights[i]);
    b.positions.push(p.x, p.y, p.z);
    b.uvs.push(i / M, 0.99);
    b.skinIndices.push(idx[0], idx[1], idx[2], idx[3]);
    b.skinWeights.push(wt[0], wt[1], wt[2], wt[3]);
    b.torsoMask.push(0, 0);
    b.clothData.push(0, 0, 0, 0);
  }

  // Connect consecutive rings with exact boundary-coherent outward winding (vDistal, uDistal, uProx)
  for (let r = 0; r < totalRings - 1; r++) {
    const rowProx = baseVertIdx + r * M;
    const rowDist = baseVertIdx + (r + 1) * M;
    for (let i = 0; i < M; i++) {
      const nextI = (i + 1) % M;
      const uProx = rowProx + i;
      const vProx = rowProx + nextI;
      const uDist = rowDist + i;
      const vDist = rowDist + nextI;
      b.indices.push(vDist, uDist, uProx);
      b.indices.push(vDist, uProx, vProx);
    }
  }
}

function attachTorsoHideShader(
  mat: THREE.MeshStandardMaterial,
  hideTorsoUniform: { value: number },
  cacheKey: string
): void {
  mat.customProgramCacheKey = () => cacheKey;
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uHideTorso = hideTorsoUniform;
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        '#include <common>\nattribute vec2 aTorsoMask;\nvarying vec2 vTorsoMask;'
      )
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvTorsoMask = aTorsoMask;');
    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        '#include <common>\nuniform float uHideTorso;\nvarying vec2 vTorsoMask;'
      )
      .replace(
        '#include <map_fragment>',
        `#include <map_fragment>
if ((uHideTorso > 0.5 && uHideTorso < 1.5 && vTorsoMask.x > 0.5) || (uHideTorso >= 1.5 && vTorsoMask.y > 0.5)) discard;`
      );
  };
}

function attachClothPhysicsShader(
  mat: THREE.MeshStandardMaterial,
  hideTorsoUniform: { value: number },
  clothUniforms: ClothShaderUniforms | undefined,
  cacheKey: string
): void {
  if (!clothUniforms) {
    attachTorsoHideShader(mat, hideTorsoUniform, cacheKey);
    return;
  }
  mat.customProgramCacheKey = () => cacheKey;
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uHideTorso = hideTorsoUniform;
    shader.uniforms.uClothTime = clothUniforms.uClothTime;
    shader.uniforms.uClothWind = clothUniforms.uClothWind;
    shader.uniforms.uClothFlutter = clothUniforms.uClothFlutter;
    shader.uniforms.uClothSway = clothUniforms.uClothSway;
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
attribute vec2 aTorsoMask;
attribute vec4 aClothData;
varying vec2 vTorsoMask;
uniform float uClothTime;
uniform float uClothWind;
uniform float uClothFlutter;
uniform vec3 uClothSway;`
      )
      .replace(
        '#include <beginnormal_vertex>',
        `#include <beginnormal_vertex>
if (aClothData.x > 0.001) {
  float nAng = aClothData.y;
  float nWave = cos(uClothTime * (6.0 + uClothWind * 18.0) + position.y * 18.0 - nAng * 2.5);
  float nAmp = aClothData.x * (0.05 + 0.16 * uClothFlutter);
  objectNormal = normalize(objectNormal + vec3(sin(nAng) * nWave, 0.3 * nWave, cos(nAng) * nWave) * nAmp);
}`
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
vTorsoMask = aTorsoMask;
float clothFree = aClothData.x;
if (clothFree > 0.001) {
  float cAng = aClothData.y;
  float isSleeve = aClothData.z;
  float hemF = aClothData.w;

  float sinA = sin(cAng);
  float cosA = cos(cAng);

  // Aerodynamic wake bias: front is compressed against chest, sides and back billow freely
  float rearWake = clamp(-sinA * 0.72 + 0.50, 0.06, 1.45);

  // Multi-frequency natural cloth ripples traveling down and across the jersey
  float waveSpeed = 6.0 + uClothWind * 18.0;
  float w1 = sin(uClothTime * waveSpeed + transformed.y * 18.0 - cAng * 2.5);
  float w2 = cos(uClothTime * (waveSpeed * 1.55) + transformed.y * 26.0 + cAng * 3.8);
  float w3 = sin(uClothTime * (waveSpeed * 2.1) + transformed.y * 36.0 - transformed.x * 24.0);

  // Flutter amplitude scales smoothly with speed/flutter uniform
  float flutter = (w1 * 0.52 + w2 * 0.32 + w3 * 0.16) * (0.0028 + 0.015 * uClothFlutter) * rearWake;

  // Wind billow: pushes the back and flanks outward and backwards
  float billow = (0.0035 + 0.014 * uClothWind) * (0.55 + 0.45 * w1) * rearWake;

  // Normal displacement (only pushes outward away from body, NEVER inward!)
  vec3 normalPush = objectNormal * (max(0.0, billow + flutter * 0.6) * clothFree);

  // Inertial + Wind slipstream translation
  vec3 windDrag = vec3(0.0);
  // Headwind pushes backwards (-Z) along the flanks and tail
  windDrag.z -= (0.004 + 0.016 * uClothWind) * rearWake * clothFree * (0.6 + 0.6 * hemF);
  // Hem vertical flapping
  windDrag.y += flutter * 0.55 * clothFree * hemF;
  // Dynamic sway from bike lean, acceleration, wheelie pitch, and stride
  windDrag.x += uClothSway.x * clothFree * (0.75 + 0.45 * hemF);
  windDrag.y += uClothSway.y * clothFree * 0.6;
  windDrag.z += uClothSway.z * clothFree * (0.70 + 0.50 * hemF);

  // Special sleeve slipstream behavior
  if (isSleeve > 0.5) {
    float sleeveFlutter = sin(uClothTime * (waveSpeed * 1.2) + transformed.y * 16.0) * (0.003 + 0.012 * uClothFlutter);
    windDrag.x += sign(transformed.x) * (sleeveFlutter * 0.7 + uClothWind * 0.004) * clothFree;
    windDrag.z -= (0.003 + 0.010 * uClothWind) * clothFree;
  }

  transformed += normalPush + windDrag;
}`
      );
    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        '#include <common>\nuniform float uHideTorso;\nvarying vec2 vTorsoMask;'
      )
      .replace(
        '#include <map_fragment>',
        `#include <map_fragment>
if ((uHideTorso > 0.5 && uHideTorso < 1.5 && vTorsoMask.x > 0.5) || (uHideTorso >= 1.5 && vTorsoMask.y > 0.5)) discard;`
      );
  };
}

function resolveJointIndex(skeleton: THREE.Skeleton, prefix: string): number {
  const idx = skeleton.bones.findIndex((b) => (b.name || '').startsWith(prefix));
  return Math.max(0, idx);
}

function getBindWorldPos(
  skeleton: THREE.Skeleton,
  jointIdx: number,
  out: THREE.Vector3
): THREE.Vector3 {
  const bone = skeleton.bones[jointIdx];
  if (!bone) return out.set(0, 0, 0);
  const inv = skeleton.boneInverses[jointIdx];
  if (inv) {
    const m = new THREE.Matrix4().copy(inv).invert();
    return out.setFromMatrixPosition(m);
  }
  bone.updateMatrixWorld(true);
  return bone.getWorldPosition(out);
}

function buildLimbSection(
  start: THREE.Vector3,
  end: THREE.Vector3,
  samples: {
    t: number;
    rx: number;
    rz: number;
    v: number;
    wA: number;
    wB: number;
    wC?: number;
    frontPush?: number;
    backPush?: number;
    lateralOffset?: number;
  }[],
  idxA: number,
  idxB: number,
  idxC = 0
): CrossSectionSlice[] {
  const out: CrossSectionSlice[] = [];
  for (const s of samples) {
    const c = new THREE.Vector3().lerpVectors(start, end, s.t);
    if (s.lateralOffset) c.x += s.lateralOffset;
    const weights: [number, number][] = [
      [idxA, s.wA],
      [idxB, s.wB],
    ];
    if (s.wC && s.wC > 0.001) {
      weights.push([idxC, s.wC]);
    }
    out.push({
      center: c,
      rx: s.rx,
      rz: s.rz,
      v: s.v,
      weights,
      torsoMask: [0, 0],
      frontPush: s.frontPush,
      backPush: s.backPush,
    });
  }
  return out;
}

export function buildCamisaShortOutfit(params: {
  object5: THREE.SkinnedMesh;
  skinMesh: THREE.Mesh | null;
  handBoneIndices: Set<number>;
  hideTorsoUniform: { value: number };
  gloveUniforms?: GloveShaderUniforms;
  clothUniforms?: ClothShaderUniforms;
  maxAnisotropy: number;
}): CamisaShortOutfitResult {
  const {
    object5,
    skinMesh,
    handBoneIndices,
    hideTorsoUniform,
    gloveUniforms,
    clothUniforms,
    maxAnisotropy,
  } = params;
  const skeleton = object5.skeleton;

  const ji: JointIndices = {
    hips: resolveJointIndex(skeleton, 'Hips'),
    spine: resolveJointIndex(skeleton, 'Spine_'),
    spine1: resolveJointIndex(skeleton, 'Spine1_'),
    spine2: resolveJointIndex(skeleton, 'Spine2_'),
    neck: resolveJointIndex(skeleton, 'Neck_'),
    head: resolveJointIndex(skeleton, 'Head_'),
    lShoulder: resolveJointIndex(skeleton, 'LeftShoulder_'),
    rShoulder: resolveJointIndex(skeleton, 'RightShoulder_'),
    lArm: resolveJointIndex(skeleton, 'LeftArm_'),
    rArm: resolveJointIndex(skeleton, 'RightArm_'),
    lForeArm: resolveJointIndex(skeleton, 'LeftForeArm_'),
    rForeArm: resolveJointIndex(skeleton, 'RightForeArm_'),
    lHand: resolveJointIndex(skeleton, 'LeftHand_'),
    rHand: resolveJointIndex(skeleton, 'RightHand_'),
    lUpLeg: resolveJointIndex(skeleton, 'LeftUpLeg_'),
    rUpLeg: resolveJointIndex(skeleton, 'RightUpLeg_'),
    lLeg: resolveJointIndex(skeleton, 'LeftLeg_'),
    rLeg: resolveJointIndex(skeleton, 'RightLeg_'),
    lFoot: resolveJointIndex(skeleton, 'LeftFoot_'),
    rFoot: resolveJointIndex(skeleton, 'RightFoot_'),
  };

  const invBindObj = new THREE.Matrix4().copy(object5.bindMatrix).invert();
  const jpAt = (idx: number) => {
    const v = getBindWorldPos(skeleton, idx, new THREE.Vector3());
    return v.applyMatrix4(invBindObj);
  };
  const jp: JointPositions = {
    hips: jpAt(ji.hips),
    spine: jpAt(ji.spine),
    spine1: jpAt(ji.spine1),
    spine2: jpAt(ji.spine2),
    neck: jpAt(ji.neck),
    lShoulder: jpAt(ji.lShoulder),
    rShoulder: jpAt(ji.rShoulder),
    lArm: jpAt(ji.lArm),
    rArm: jpAt(ji.rArm),
    lForeArm: jpAt(ji.lForeArm),
    rForeArm: jpAt(ji.rForeArm),
    lHand: jpAt(ji.lHand),
    rHand: jpAt(ji.rHand),
    lUpLeg: jpAt(ji.lUpLeg),
    rUpLeg: jpAt(ji.rUpLeg),
    lLeg: jpAt(ji.lLeg),
    rLeg: jpAt(ji.rLeg),
    lFoot: jpAt(ji.lFoot),
    rFoot: jpAt(ji.rFoot),
  };

  const skinRgb = sampleSkinRgbFromMesh(skinMesh);
  const skinTex = createSkinTexture(skinRgb, maxAnisotropy);
  const grauShirtTex = createShirtTexture(maxAnisotropy);
  const realMadridShirtTex = createRealMadridShirtTexture(maxAnisotropy);
  const shortsTex = createShortsTexture(maxAnisotropy);

  const skinMat = new THREE.MeshStandardMaterial({
    map: skinTex,
    roughness: 0.64,
    metalness: 0.02,
    envMapIntensity: 0.85,
  });
  attachTorsoHideShader(skinMat, hideTorsoUniform, 'rider_cs_skin_v1');

  const shirtMat = new THREE.MeshStandardMaterial({
    map: realMadridShirtTex,
    roughness: 0.84,
    metalness: 0.02,
    envMapIntensity: 0.84,
    side: THREE.DoubleSide,
  });
  attachClothPhysicsShader(shirtMat, hideTorsoUniform, clothUniforms, 'rider_cs_shirt_cloth_v3');

  const shortsMat = new THREE.MeshStandardMaterial({
    map: shortsTex,
    roughness: 0.72,
    metalness: 0.04,
    envMapIntensity: 0.84,
    side: THREE.DoubleSide,
  });
  attachClothPhysicsShader(shortsMat, hideTorsoUniform, clothUniforms, 'rider_cs_shorts_cloth_v3');

  // =========================================================
  // 1. HANDS-ONLY MESH FIRST (gives exact 16-vertex wrist loops)
  // =========================================================
  const handsBuilt = buildHandsOnlyMesh(object5, handBoneIndices, gloveUniforms, skinRgb);
  const handsGeo = handsBuilt.mesh.geometry as THREE.BufferGeometry;

  // =========================================================
  // 2. SKIN MESH (Welded Neck Bridge + Welded Arms + Thighs/Calves/Ankles)
  // =========================================================
  const skinLoft = createLoftBuilder();

  // Exact vertex-welded neck -> clavicle bridge from Wolf3D_Skin
  const stitchedNeck = skinMesh ? stitchWolf3DNeckBridge(skinLoft, skinMesh, object5, ji) : false;
  if (!stitchedNeck) {
    addTubeLoft(
      skinLoft,
      [
        {
          center: new THREE.Vector3(0, 1.43, -0.024),
          rx: 0.118,
          rz: 0.076,
          v: 0.15,
          weights: [
            [ji.spine2, 0.85],
            [ji.neck, 0.15],
          ],
          torsoMask: [1, 1],
        },
        {
          center: new THREE.Vector3(0, 1.525, -0.015),
          rx: 0.088,
          rz: 0.064,
          v: 0.85,
          weights: [
            [ji.spine2, 0.72],
            [ji.neck, 0.28],
          ],
          torsoMask: [1, 1],
        },
      ],
      24
    );
  }

  // Bare Arms stitched directly onto both 16-vertex hand wrist boundary loops
  buildArmSkinStitchedToWrist(
    skinLoft,
    jp.lShoulder,
    jp.lArm,
    jp.lForeArm,
    jp.lHand,
    ji.spine2,
    ji.lShoulder,
    ji.lArm,
    ji.lForeArm,
    ji.lHand,
    handsGeo,
    handsBuilt.leftWristLoop
  );
  buildArmSkinStitchedToWrist(
    skinLoft,
    jp.rShoulder,
    jp.rArm,
    jp.rForeArm,
    jp.rHand,
    ji.spine2,
    ji.rShoulder,
    ji.rArm,
    ji.rForeArm,
    ji.rHand,
    handsGeo,
    handsBuilt.rightWristLoop
  );

  // Bare Legs: start high inside shorts (t = 0.16, y ~ 0.95) -> knee -> calf -> exact sneaker opening
  const buildLegSkin = (
    upPos: THREE.Vector3,
    legPos: THREE.Vector3,
    footPos: THREE.Vector3,
    iUp: number,
    iLeg: number,
    iFoot: number,
    isLeft: boolean
  ) => {
    const thighSamples = buildLimbSection(
      upPos,
      legPos,
      [
        { t: 0.16, rx: 0.082, rz: 0.086, v: 0.04, wA: 0.72, wB: 0.0, wC: 0.28 },
        { t: 0.34, rx: 0.077, rz: 0.080, v: 0.14, wA: 0.94, wB: 0.02, wC: 0.04 },
        { t: 0.54, rx: 0.069, rz: 0.071, v: 0.28, wA: 0.96, wB: 0.04 },
        { t: 0.76, rx: 0.061, rz: 0.063, v: 0.42, wA: 0.85, wB: 0.15 },
        { t: 0.92, rx: 0.056, rz: 0.058, v: 0.49, wA: 0.58, wB: 0.42, frontPush: 0.006 },
      ],
      iUp,
      iLeg,
      ji.hips
    );

    // Exact Wolf3D_Outfit_Footwear collar center at bind pose: (+/-0.1562, 0.1565, -0.0296)
    const shoeCenterX = isLeft ? 0.155 : -0.155;
    const ankleTop = new THREE.Vector3(shoeCenterX, 0.160, -0.031);
    const ankleInShoe = new THREE.Vector3(shoeCenterX * 0.985, 0.116, -0.035);

    const shinSamples = buildLimbSection(
      legPos,
      footPos,
      [
        { t: 0.02, rx: 0.055, rz: 0.057, v: 0.53, wA: 0.70, wB: 0.0, wC: 0.30, frontPush: 0.005 },
        { t: 0.18, rx: 0.056, rz: 0.059, v: 0.64, wA: 0.96, wB: 0.04, backPush: 0.009 },
        { t: 0.36, rx: 0.054, rz: 0.059, v: 0.74, wA: 0.96, wB: 0.04, backPush: 0.011 },
        { t: 0.60, rx: 0.045, rz: 0.047, v: 0.85, wA: 0.93, wB: 0.07, backPush: 0.004 },
        { t: 0.82, rx: 0.038, rz: 0.041, v: 0.93, wA: 0.76, wB: 0.24 },
      ],
      iLeg,
      iFoot,
      iUp
    );
    shinSamples.push(
      {
        center: ankleTop,
        rx: 0.036,
        rz: 0.042,
        v: 0.97,
        weights: [
          [iLeg, 0.36],
          [iFoot, 0.64],
        ],
        torsoMask: [0, 0],
      },
      {
        center: ankleInShoe,
        rx: 0.032,
        rz: 0.037,
        v: 1.00,
        weights: [
          [iLeg, 0.14],
          [iFoot, 0.86],
        ],
        torsoMask: [0, 0],
      }
    );

    addTubeLoft(skinLoft, [...thighSamples, ...shinSamples], 26);
  };

  buildLegSkin(jp.lUpLeg, jp.lLeg, jp.lFoot, ji.lUpLeg, ji.lLeg, ji.lFoot, true);
  buildLegSkin(jp.rUpLeg, jp.rLeg, jp.rFoot, ji.rUpLeg, ji.rLeg, ji.rFoot, false);

  const skinSkinnedMesh = new THREE.SkinnedMesh(finalizeLoftGeometry(skinLoft), skinMat);
  skinSkinnedMesh.name = 'Rider_CamisaShort_Skin';
  skinSkinnedMesh.castShadow = false;
  skinSkinnedMesh.receiveShadow = false;
  skinSkinnedMesh.frustumCulled = false;
  skinSkinnedMesh.bind(object5.skeleton, object5.bindMatrix);

  // =========================================================
  // 3. SHIRT MESH (Sculpted Loose-Fit Jersey + Pleated Drape + Clean Crew Collar)
  // =========================================================
  const shirtLoft = createLoftBuilder();

  const shapeTorsoVertex = (
    pos: THREE.Vector3,
    sinT: number,
    cosT: number,
    theta: number,
    baseY: number
  ) => {
    // Smooth organic torso cross-section + pectoral/sternum/spine contours + loose cloth folds below chest
    const chestBand = smoothstep(1.18, 1.38, baseY) * (1.0 - smoothstep(1.38, 1.50, baseY));
    if (chestBand > 0.01) {
      // Sculpted pecs & subtle sternum dip in front, soft spine furrow in back
      if (sinT > 0.15) {
        const pecLobe = smoothstep(0.18, 0.58, Math.abs(cosT)) * (1.0 - smoothstep(0.68, 0.96, Math.abs(cosT)));
        const sternumDip = (1.0 - smoothstep(0.0, 0.24, Math.abs(cosT))) * smoothstep(0.55, 0.95, sinT);
        pos.z += chestBand * (0.008 * pecLobe * sinT - 0.005 * sternumDip);
      } else if (sinT < -0.25) {
        const spineDip = (1.0 - smoothstep(0.0, 0.26, Math.abs(cosT))) * smoothstep(-0.30, -0.92, sinT);
        pos.z += chestBand * 0.006 * spineDip;
      }
    }

    // Gentle vertical fabric pleats & air drape from lower chest down to loose hem
    const drapeAmp = smoothstep(1.32, 0.92, baseY);
    if (drapeAmp > 0.01) {
      const pleat =
        0.0040 * Math.sin(theta * 5.0 + 0.45) +
        0.0026 * Math.cos(theta * 3.0 - 0.55) +
        0.0016 * Math.sin(theta * 8.0 + 1.1);
      const radScale = pleat * drapeAmp;
      pos.x += cosT * radScale * 0.85;
      pos.z += sinT * radScale * 1.15;

      // Natural jersey hem silhouette: slightly longer back tail, slight side vent rise
      const hemCurve = smoothstep(1.06, 0.91, baseY);
      pos.y += hemCurve * (-0.012 * Math.max(0, -sinT) + 0.008 * Math.pow(Math.abs(cosT), 2.5));
    }
  };

  const torsoSlices: CrossSectionSlice[] = [
    {
      // Rolled inner bottom hem lip (prevents paper-thin upward view)
      center: new THREE.Vector3(0, 0.922, 0.006),
      rx: 0.160,
      rz: 0.122,
      v: 0.02,
      weights: [
        [ji.hips, 0.85],
        [ji.spine, 0.15],
      ],
      torsoMask: [1, 0],
      clothFreedom: 0.90,
      clothHemFactor: 0.95,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 0.916),
    },
    {
      // Outer loose jersey bottom hem (hangs freely over shorts waistband with 22mm clearance)
      center: new THREE.Vector3(0, 0.910, 0.006),
      rx: 0.176,
      rz: 0.136,
      v: 0.03,
      weights: [
        [ji.hips, 0.84],
        [ji.spine, 0.16],
      ],
      torsoMask: [1, 0],
      clothFreedom: 1.0,
      clothHemFactor: 1.0,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 0.910),
    },
    {
      center: new THREE.Vector3(0, 0.965, 0.010),
      rx: 0.172,
      rz: 0.133,
      v: 0.11,
      weights: [
        [ji.hips, 0.65],
        [ji.spine, 0.35],
      ],
      torsoMask: [1, 0],
      clothFreedom: 0.80,
      clothHemFactor: 0.80,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 0.965),
    },
    {
      center: new THREE.Vector3(0, 1.030, 0.014),
      rx: 0.168,
      rz: 0.128,
      v: 0.22,
      weights: [
        [ji.hips, 0.38],
        [ji.spine, 0.62],
      ],
      torsoMask: [1, 0],
      frontPush: 0.004,
      clothFreedom: 0.60,
      clothHemFactor: 0.58,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 1.030),
    },
    {
      center: new THREE.Vector3(0, 1.100, 0.016),
      rx: 0.165,
      rz: 0.126,
      v: 0.33,
      weights: [
        [ji.hips, 0.10],
        [ji.spine, 0.70],
        [ji.spine1, 0.20],
      ],
      torsoMask: [1, 0],
      frontPush: 0.007,
      clothFreedom: 0.44,
      clothHemFactor: 0.40,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 1.100),
    },
    {
      center: new THREE.Vector3(0, 1.175, 0.012),
      rx: 0.166,
      rz: 0.126,
      v: 0.44,
      weights: [
        [ji.spine, 0.40],
        [ji.spine1, 0.52],
        [ji.spine2, 0.08],
      ],
      torsoMask: [1, 0],
      frontPush: 0.010,
      clothFreedom: 0.30,
      clothHemFactor: 0.25,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 1.175),
    },
    {
      center: new THREE.Vector3(0, 1.250, 0.006),
      rx: 0.172,
      rz: 0.128,
      v: 0.55,
      weights: [
        [ji.spine, 0.14],
        [ji.spine1, 0.66],
        [ji.spine2, 0.20],
      ],
      torsoMask: [1, 0],
      frontPush: 0.014,
      backPush: 0.004,
      clothFreedom: 0.18,
      clothHemFactor: 0.12,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 1.250),
    },
    {
      center: new THREE.Vector3(0, 1.326, -0.003),
      rx: 0.180,
      rz: 0.126,
      v: 0.66,
      weights: [
        [ji.spine1, 0.30],
        [ji.spine2, 0.70],
      ],
      torsoMask: [1, 0],
      frontPush: 0.017,
      backPush: 0.007,
      clothFreedom: 0.10,
      clothHemFactor: 0.05,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 1.326),
    },
    {
      center: new THREE.Vector3(0, 1.396, -0.010),
      rx: 0.186,
      rz: 0.118,
      v: 0.76,
      weights: [
        [ji.spine1, 0.08],
        [ji.spine2, 0.92],
      ],
      torsoMask: [1, 0],
      frontPush: 0.015,
      backPush: 0.008,
      clothFreedom: 0.03,
      posPerVertex: (pos, sinT, cosT, theta) => shapeTorsoVertex(pos, sinT, cosT, theta, 1.396),
    },
    {
      center: new THREE.Vector3(0, 1.455, -0.015),
      rx: 0.174,
      rz: 0.104,
      v: 0.84,
      weights: [[ji.spine2, 1.0]],
      torsoMask: [1, 0],
      clothFreedom: 0.0,
    },
    {
      center: new THREE.Vector3(0, 1.502, -0.018),
      rx: 0.136,
      rz: 0.088,
      v: 0.91,
      weights: [
        [ji.spine2, 0.92],
        [ji.neck, 0.08],
      ],
      torsoMask: [1, 1],
      clothFreedom: 0.0,
      posPerVertex: (pos, sinT) => {
        if (sinT > 0) pos.y -= 0.014 * sinT;
      },
    },
    {
      // Outer crew-neck collar aligned cleanly around Wolf3D_Skin neck rim center (cz = -0.0235)
      center: new THREE.Vector3(0, 1.544, -0.0235),
      rx: 0.108,
      rz: 0.078,
      v: 0.965,
      weights: [
        [ji.spine2, 0.88],
        [ji.neck, 0.12],
      ],
      torsoMask: [1, 1],
      clothFreedom: 0.0,
      posPerVertex: (pos, sinT, cosT) => {
        // Natural athletic crew collar line:
        // Front throat dips to y = 1.520
        // Sides curve up to y = 1.560
        // Back nape curves up to y = 1.568
        pos.y += 0.016 * (1.0 - sinT * sinT) - 0.024 * sinT;
      },
    },
    {
      // Rolled inward collar lip tucking cleanly onto neck bridge
      center: new THREE.Vector3(0, 1.536, -0.0235),
      rx: 0.088,
      rz: 0.060,
      v: 0.99,
      weights: [
        [ji.spine2, 0.88],
        [ji.neck, 0.12],
      ],
      torsoMask: [1, 1],
      clothFreedom: 0.0,
      posPerVertex: (pos, sinT, cosT) => {
        pos.y += 0.014 * (1.0 - sinT * sinT) - 0.022 * sinT;
      },
    },
  ];

  addTubeLoft(shirtLoft, torsoSlices, 44, {
    torsoMaskPerVertex: (pos, baseMask) => {
      const m0 = baseMask[0];
      const m1 =
        baseMask[1] > 0.5 || (pos.y > 1.445 && Math.abs(pos.x) < 0.145) ? 1.0 : 0.0;
      return [m0, m1];
    },
    weightsPerVertex: (pos, baseWeights) => {
      // Only outer shoulder flanks (|x| > 0.105, below collar rim) deform with shoulders so collar stays locked to neck
      if (pos.y <= 1.37 || pos.y >= 1.505) return baseWeights;
      const shAmt =
        smoothstep(0.105, 0.175, Math.abs(pos.x)) * smoothstep(1.37, 1.47, pos.y) * 0.36;
      if (shAmt < 0.02) return baseWeights;
      const sideSh = pos.x >= 0 ? ji.lShoulder : ji.rShoulder;
      const scaled: [number, number][] = baseWeights.map(([idx, w]) => [idx, w * (1 - shAmt)]);
      scaled.push([sideSh, shAmt]);
      return scaled;
    },
  });

  // Loose athletic jersey sleeves with natural open cuff + cloth drape
  const buildSleeve = (
    shoulderPos: THREE.Vector3,
    armPos: THREE.Vector3,
    forePos: THREE.Vector3,
    iShoulder: number,
    iArm: number,
    iFore: number
  ) => {
    const socketStart = new THREE.Vector3().lerpVectors(shoulderPos, armPos, 0.18);
    socketStart.y -= 0.036;
    const deltoidMid = new THREE.Vector3().lerpVectors(shoulderPos, armPos, 0.54);
    deltoidMid.y -= 0.028;
    const armSocket = armPos.clone();
    armSocket.y -= 0.020;
    const cuffOuter = new THREE.Vector3()
      .lerpVectors(armPos, forePos, 0.45)
      .add(new THREE.Vector3(0, -0.005, 0));
    const cuffInner = new THREE.Vector3()
      .lerpVectors(armPos, forePos, 0.41)
      .add(new THREE.Vector3(0, -0.005, 0));

    const sleeveDrape = (amt: number): CrossSectionSlice['posPerVertex'] => (pos, _s, _c, theta) => {
      const ripple = 0.0022 * Math.sin(theta * 4.0 + 0.5) + 0.0014 * Math.cos(theta * 6.0);
      pos.y -= 0.004 * amt;
      pos.x += Math.cos(theta) * ripple * amt;
      pos.z += Math.sin(theta) * ripple * amt;
    };

    const slices: CrossSectionSlice[] = [
      {
        center: socketStart,
        rx: 0.056,
        rz: 0.068,
        v: 0.80,
        weights: [
          [ji.spine2, 0.56],
          [iShoulder, 0.44],
        ],
        torsoMask: [1, 0],
        clothFreedom: 0.02,
        clothIsSleeve: 1,
      },
      {
        center: deltoidMid,
        rx: 0.064,
        rz: 0.072,
        v: 0.70,
        weights: [
          [ji.spine2, 0.18],
          [iShoulder, 0.54],
          [iArm, 0.28],
        ],
        torsoMask: [1, 0],
        clothFreedom: 0.10,
        clothIsSleeve: 1,
      },
      {
        center: armSocket,
        rx: 0.064,
        rz: 0.070,
        v: 0.58,
        weights: [
          [iShoulder, 0.24],
          [iArm, 0.76],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.22,
        clothIsSleeve: 1,
        clothHemFactor: 0.22,
        posPerVertex: sleeveDrape(0.35),
      },
      {
        center: new THREE.Vector3()
          .lerpVectors(armPos, forePos, 0.18)
          .add(new THREE.Vector3(0, -0.010, 0)),
        rx: 0.063,
        rz: 0.068,
        v: 0.46,
        weights: [
          [iArm, 0.94],
          [iFore, 0.06],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.40,
        clothIsSleeve: 1,
        clothHemFactor: 0.48,
        posPerVertex: sleeveDrape(0.65),
      },
      {
        center: new THREE.Vector3()
          .lerpVectors(armPos, forePos, 0.34)
          .add(new THREE.Vector3(0, -0.007, 0)),
        rx: 0.063,
        rz: 0.067,
        v: 0.35,
        weights: [
          [iArm, 0.90],
          [iFore, 0.10],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.54,
        clothIsSleeve: 1,
        clothHemFactor: 0.76,
        posPerVertex: sleeveDrape(0.85),
      },
      {
        center: cuffOuter,
        rx: 0.064,
        rz: 0.068,
        v: 0.26,
        weights: [
          [iArm, 0.87],
          [iFore, 0.13],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.64,
        clothIsSleeve: 1,
        clothHemFactor: 1.0,
        posPerVertex: sleeveDrape(1.0),
      },
      {
        // Rolled inward sleeve hem cuff
        center: cuffInner,
        rx: 0.055,
        rz: 0.059,
        v: 0.25,
        weights: [
          [iArm, 0.87],
          [iFore, 0.13],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.56,
        clothIsSleeve: 1,
        clothHemFactor: 0.88,
        posPerVertex: sleeveDrape(0.8),
      },
    ];
    addTubeLoft(shirtLoft, slices, 30);
  };

  buildSleeve(jp.lShoulder, jp.lArm, jp.lForeArm, ji.lShoulder, ji.lArm, ji.lForeArm);
  buildSleeve(jp.rShoulder, jp.rArm, jp.rForeArm, ji.rShoulder, ji.rArm, ji.rForeArm);

  const shirtSkinnedMesh = new THREE.SkinnedMesh(finalizeLoftGeometry(shirtLoft), shirtMat);
  shirtSkinnedMesh.name = 'Rider_CamisaShort_Shirt';
  shirtSkinnedMesh.castShadow = false;
  shirtSkinnedMesh.receiveShadow = false;
  shirtSkinnedMesh.frustumCulled = false;
  shirtSkinnedMesh.bind(object5.skeleton, object5.bindMatrix);

  // =========================================================
  // 4. SHORTS MESH (Contoured Pelvis/Glutes + Bifurcated Bermuda Legs)
  // =========================================================
  const shortsLoft = createLoftBuilder();

  // Pelvis tube: from snug waistband (y = 0.955) down to crotch saddle (y = 0.875)
  // Completely inside the shirt hem (which hangs at y = 0.910 with rx = 0.176)
  addTubeLoft(
    shortsLoft,
    [
      {
        center: new THREE.Vector3(0, 0.875, 0.004),
        rx: 0.150,
        rz: 0.114,
        v: 0.52,
        weights: [[ji.hips, 1.0]],
        torsoMask: [0, 0],
        backPush: 0.008,
        clothFreedom: 0.12,
        posPerVertex: (pos, _sinT, cosT) => {
          // Crotch midline tuck (seam between legs)
          const crotchPinch = 1.0 - smoothstep(0.0, 0.16, Math.abs(cosT));
          pos.z -= (pos.z - 0.002) * (0.42 * crotchPinch);
          pos.y += 0.008 * crotchPinch;
        },
      },
      {
        center: new THREE.Vector3(0, 0.915, 0.006),
        rx: 0.154,
        rz: 0.118,
        v: 0.68,
        weights: [[ji.hips, 1.0]],
        torsoMask: [0, 0],
        backPush: 0.010,
        clothFreedom: 0.08,
      },
      {
        center: new THREE.Vector3(0, 0.955, 0.008),
        rx: 0.148,
        rz: 0.112,
        v: 0.88,
        weights: [
          [ji.hips, 0.90],
          [ji.spine, 0.10],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.02,
      },
      {
        // Rolled inward waistband lip (prevents raw edge inside shirt)
        center: new THREE.Vector3(0, 0.950, 0.008),
        rx: 0.142,
        rz: 0.106,
        v: 0.96,
        weights: [
          [ji.hips, 0.90],
          [ji.spine, 0.10],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.0,
      },
    ],
    32,
    {
      weightsPerVertex: (pos, baseWeights) => {
        if (pos.y >= 0.92) return baseWeights;
        const legFactor = clamp01((0.92 - pos.y) / 0.05);
        const sideBlend = smoothstep(-0.04, 0.04, pos.x);
        const legTotal = legFactor * 0.70;
        return [
          [ji.hips, 1.0 - legTotal],
          [ji.lUpLeg, legTotal * sideBlend],
          [ji.rUpLeg, legTotal * (1.0 - sideBlend)],
        ];
      },
    }
  );

  const buildShortLeg = (
    upPos: THREE.Vector3,
    legPos: THREE.Vector3,
    iUp: number,
    iLeg: number,
    isLeft: boolean
  ) => {
    // Bermuda shorts legs start directly at crotch level (t = 0.30, y ~ 0.875)
    // and hang freely down along the thigh to just above the knee (t = 0.85, y ~ 0.630)
    const legDrape = (amt: number): CrossSectionSlice['posPerVertex'] => (
      pos,
      _sinT,
      cosT,
      theta
    ) => {
      const pleat =
        0.0030 * Math.sin(theta * 5.0 + (isLeft ? 0.3 : -0.3)) +
        0.0018 * Math.cos(theta * 3.0);
      pos.x += cosT * pleat * amt;
      pos.z += Math.sin(theta) * pleat * amt;
    };

    const slices: CrossSectionSlice[] = [
      {
        center: new THREE.Vector3().lerpVectors(upPos, legPos, 0.30),
        rx: 0.095,
        rz: 0.099,
        v: 0.48,
        weights: [
          [ji.hips, 0.18],
          [iUp, 0.82],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.20,
        clothHemFactor: 0.15,
        posPerVertex: legDrape(0.30),
      },
      {
        center: new THREE.Vector3().lerpVectors(upPos, legPos, 0.48),
        rx: 0.093,
        rz: 0.096,
        v: 0.34,
        weights: [
          [iUp, 0.94],
          [iLeg, 0.06],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.38,
        clothHemFactor: 0.45,
        posPerVertex: legDrape(0.60),
      },
      {
        center: new THREE.Vector3().lerpVectors(upPos, legPos, 0.68),
        rx: 0.091,
        rz: 0.094,
        v: 0.18,
        weights: [
          [iUp, 0.86],
          [iLeg, 0.14],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.54,
        clothHemFactor: 0.75,
        posPerVertex: legDrape(0.85),
      },
      {
        // Outer bermuda leg hem (above knee)
        center: new THREE.Vector3().lerpVectors(upPos, legPos, 0.85),
        rx: 0.090,
        rz: 0.093,
        v: 0.04,
        weights: [
          [iUp, 0.70],
          [iLeg, 0.30],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.68,
        clothHemFactor: 1.0,
        posPerVertex: legDrape(1.0),
      },
      {
        // Rolled inward hem lip
        center: new THREE.Vector3().lerpVectors(upPos, legPos, 0.82),
        rx: 0.082,
        rz: 0.084,
        v: 0.02,
        weights: [
          [iUp, 0.72],
          [iLeg, 0.28],
        ],
        torsoMask: [0, 0],
        clothFreedom: 0.60,
        clothHemFactor: 0.90,
        posPerVertex: legDrape(0.8),
      },
    ];
    addTubeLoft(shortsLoft, slices, 28, {
      uOffset: isLeft ? -0.5 : 0,
    });
  };

  buildShortLeg(jp.lUpLeg, jp.lLeg, ji.lUpLeg, ji.lLeg, true);
  buildShortLeg(jp.rUpLeg, jp.rLeg, ji.rUpLeg, ji.rLeg, false);

  const shortsSkinnedMesh = new THREE.SkinnedMesh(finalizeLoftGeometry(shortsLoft), shortsMat);
  shortsSkinnedMesh.name = 'Rider_CamisaShort_Shorts';
  shortsSkinnedMesh.castShadow = false;
  shortsSkinnedMesh.receiveShadow = false;
  shortsSkinnedMesh.frustumCulled = false;
  shortsSkinnedMesh.bind(object5.skeleton, object5.bindMatrix);

  const setShirtStyle = (style: LegacyRiderShirtStyle) => {
    const targetMap = style === 'real_madrid' ? realMadridShirtTex : grauShirtTex;
    if (shirtMat.map !== targetMap) {
      shirtMat.map = targetMap;
      shirtMat.needsUpdate = true;
    }
  };

  return {
    meshes: [skinSkinnedMesh, shirtSkinnedMesh, shortsSkinnedMesh, handsBuilt.mesh],
    materials: [skinMat, shirtMat, shortsMat, handsBuilt.material],
    setShirtStyle,
  };
}

function createStreetSneakerTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const w = 1024;
  const h = 512;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Upper region (v = 0.28..1.00 -> y = 0..368): crisp pebbled white leather
  const upperGrad = ctx.createLinearGradient(0, 0, 0, 368);
  upperGrad.addColorStop(0.0, '#ffffff');
  upperGrad.addColorStop(0.7, '#f1f4f8');
  upperGrad.addColorStop(1.0, '#e2e7ef');
  ctx.fillStyle = upperGrad;
  ctx.fillRect(0, 0, w, 368);

  // Subtle tumbled leather micro-grain
  let seed = 4242;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  for (let i = 0; i < 4500; i++) {
    ctx.fillStyle = rand() > 0.5 ? 'rgba(255,255,255,0.18)' : 'rgba(15,23,42,0.035)';
    ctx.fillRect(rand() * w, rand() * 368, 2, 2);
  }

  // Midfoot side stripe panels (lateral & medial along u=0.25 and u=0.75)
  const drawSideStripe = (cx: number, slant: number) => {
    ctx.save();
    ctx.translate(cx, 255);
    // Deep navy suede heel overlay
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-155, -145, 92, 195);
    // Crisp metallic gold side 3-stripes
    ctx.fillStyle = '#d4a63a';
    for (let s = -1; s <= 1; s++) {
      ctx.beginPath();
      ctx.moveTo(s * 24 - 8, 52);
      ctx.lineTo(s * 24 + 8, 52);
      ctx.lineTo(s * 24 + 8 + slant, -78);
      ctx.lineTo(s * 24 - 8 + slant, -78);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  };
  drawSideStripe(w * 0.25, 22);
  drawSideStripe(w * 0.75, -22);

  // Padded navy collar liner around top edge (v = 0.80..1.00 -> y = 0..92)
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, w, 76);
  ctx.fillStyle = '#d4a63a';
  ctx.fillRect(0, 76, w, 8);

  // Stitching accents along quarters
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.24)';
  ctx.lineWidth = 2;
  ctx.setLineDash([7, 5]);
  ctx.beginPath();
  ctx.moveTo(0, 170);
  ctx.lineTo(w, 170);
  ctx.moveTo(0, 342);
  ctx.lineTo(w, 342);
  ctx.stroke();
  ctx.setLineDash([]);

  // Crisp sculpted white street midsole (v = 0.08..0.28 -> y = 368..470)
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 368, w, 102);
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 368, w, 5);
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.14)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 412);
  ctx.lineTo(w, 412);
  ctx.stroke();

  // Gum rubber street outsole (v = 0.00..0.08 -> y = 470..512)
  ctx.fillStyle = '#9a6b3b';
  ctx.fillRect(0, 470, w, 42);
  ctx.fillStyle = 'rgba(40, 22, 8, 0.26)';
  for (let x = 0; x < w; x += 24) {
    ctx.fillRect(x, 474, 8, 36);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  tex.needsUpdate = true;
  return tex;
}

/**
 * Builds a newly sculpted 3D low-top street sneaker pair (white pebbled leather, navy heel/collar,
 * gold stripes, sculpted midsole + gum outsole, raised tongue, and 3D laces) skinned cleanly to
 * bike_rider.glb's leg/foot/toe skeleton.
 */
export function buildStreetSneakerMesh(
  object4: THREE.SkinnedMesh,
  maxAnisotropy: number
): { mesh: THREE.SkinnedMesh; material: THREE.MeshStandardMaterial } {
  const skeleton = object4.skeleton;
  const lLeg = resolveJointIndex(skeleton, 'LeftLeg_');
  const lFoot = resolveJointIndex(skeleton, 'LeftFoot_');
  const lToeBase = resolveJointIndex(skeleton, 'LeftToeBase_');
  const lToeEnd = resolveJointIndex(skeleton, 'LeftToe_End_');
  const rLeg = resolveJointIndex(skeleton, 'RightLeg_');
  const rFoot = resolveJointIndex(skeleton, 'RightFoot_');
  const rToeBase = resolveJointIndex(skeleton, 'RightToeBase_');
  const rToeEnd = resolveJointIndex(skeleton, 'RightToe_End_');

  const positions: number[] = [];
  const uvs: number[] = [];
  const skinIndices: number[] = [];
  const skinWeights: number[] = [];
  const indices: number[] = [];

  const pushVert = (
    x: number,
    y: number,
    z: number,
    u: number,
    v: number,
    weights: [number, number][]
  ) => {
    positions.push(x, y, z);
    uvs.push(u, v);
    const { idx, wt } = normalizeWeights(weights);
    skinIndices.push(idx[0], idx[1], idx[2], idx[3]);
    skinWeights.push(wt[0], wt[1], wt[2], wt[3]);
  };

  const buildOneShoe = (isLeft: boolean) => {
    const iLeg = isLeft ? lLeg : rLeg;
    const iFoot = isLeft ? lFoot : rFoot;
    const iToeBase = isLeft ? lToeBase : rToeBase;
    const iToeEnd = isLeft ? lToeEnd : rToeEnd;
    const sideSign = isLeft ? 1 : -1;

    const footWeights = (z: number, y: number): [number, number][] => {
      if (z < -0.05) {
        return y > 0.10 ? [[iFoot, 0.88], [iLeg, 0.12]] : [[iFoot, 0.96], [iLeg, 0.04]];
      }
      if (z < 0.04) {
        return y > 0.105 ? [[iFoot, 0.86], [iLeg, 0.14]] : [[iFoot, 1.0]];
      }
      if (z < 0.13) {
        const t = smoothstep(0.04, 0.13, z);
        return [
          [iFoot, 1 - t],
          [iToeBase, t],
        ];
      }
      const t = smoothstep(0.13, 0.21, z);
      return [
        [iToeBase, 1 - t * 0.68],
        [iToeEnd, t * 0.68],
      ];
    };

    // Profile slices from heel bumper (-0.118) to toe cap (+0.220)
    const profile = [
      { z: -0.118, cx: 0.151 * sideSign, rx: 0.025, botY: 0.002, topY: 0.095 },
      { z: -0.102, cx: 0.151 * sideSign, rx: 0.042, botY: -0.002, topY: 0.128 },
      { z: -0.068, cx: 0.154 * sideSign, rx: 0.047, botY: -0.002, topY: 0.138 },
      { z: -0.031, cx: 0.156 * sideSign, rx: 0.050, botY: -0.002, topY: 0.140 },
      { z: 0.014, cx: 0.159 * sideSign, rx: 0.054, botY: -0.002, topY: 0.128 },
      { z: 0.065, cx: 0.161 * sideSign, rx: 0.056, botY: -0.001, topY: 0.096 },
      { z: 0.118, cx: 0.162 * sideSign, rx: 0.057, botY: 0.000, topY: 0.076 },
      { z: 0.172, cx: 0.161 * sideSign, rx: 0.050, botY: 0.004, topY: 0.064 },
      { z: 0.205, cx: 0.160 * sideSign, rx: 0.034, botY: 0.011, topY: 0.050 },
      { z: 0.220, cx: 0.159 * sideSign, rx: 0.013, botY: 0.020, topY: 0.034 },
    ];

    const segs = 22;
    const ringVerts = segs + 1;
    const baseIdx = positions.length / 3;

    for (let s = 0; s < profile.length; s++) {
      const p = profile[s];
      const u = s / (profile.length - 1);
      const midY = (p.botY + p.topY) * 0.5;
      const halfH = (p.topY - p.botY) * 0.5;

      for (let r = 0; r <= segs; r++) {
        // theta = 0 at top center -> PI/2 right -> PI bottom -> 3PI/2 left -> 2PI top
        const theta = (r / segs) * Math.PI * 2;
        const sinT = Math.sin(theta);
        const cosT = Math.cos(theta);

        let x = p.cx + p.rx * sinT;
        let y = midY + halfH * cosT;

        // Flatten street sneaker outsole & keep crisp vertical sidewall near bottom
        if (cosT < -0.58) {
          y = p.botY;
          x = p.cx + p.rx * Math.sign(sinT) * Math.min(1, Math.abs(sinT) * 1.15);
        } else if (cosT < -0.15) {
          const wallT = (-0.15 - cosT) / 0.43;
          y = THREE.MathUtils.lerp(y, p.botY + 0.028 * (1 - wallT), 0.72);
        }

        const heightNorm = clamp01((y - p.botY) / Math.max(0.02, p.topY - p.botY));
        // Map heightNorm cleanly to texture v: 0.0..0.28 sole+midsole, 0.28..0.85 upper, 0.85..1.0 collar
        const soleRatio = clamp01((y - p.botY) / 0.032);
        const vTex = y - p.botY < 0.032 ? soleRatio * 0.27 : 0.28 + heightNorm * 0.70;
        const uTex = isLeft ? u : 1 - u;

        pushVert(x, y, p.z, uTex, clamp01(vTex), footWeights(p.z, y));
      }
    }

    for (let s = 0; s < profile.length - 1; s++) {
      const row0 = baseIdx + s * ringVerts;
      const row1 = baseIdx + (s + 1) * ringVerts;
      for (let r = 0; r < segs; r++) {
        const a = row0 + r;
        const b = row0 + r + 1;
        const c = row1 + r;
        const d = row1 + r + 1;
        indices.push(a, c, b);
        indices.push(b, c, d);
      }
    }

    // Cap heel & toe ends cleanly
    const capEnd = (ringStart: number, z: number, cx: number, cy: number, flip: boolean) => {
      const centerIdx = positions.length / 3;
      pushVert(cx, cy, z, 0.5, 0.45, footWeights(z, cy));
      for (let r = 0; r < segs; r++) {
        if (flip) indices.push(centerIdx, ringStart + r + 1, ringStart + r);
        else indices.push(centerIdx, ringStart + r, ringStart + r + 1);
      }
    };
    capEnd(baseIdx, profile[0].z - 0.002, profile[0].cx, 0.048, false);
    const lastRing = baseIdx + (profile.length - 1) * ringVerts;
    capEnd(lastRing, profile[profile.length - 1].z + 0.002, profile[profile.length - 1].cx, 0.027, true);

    // Helper for raised padded tongue & 3D crisscrossed shoelace bars
    const addBoxDetail = (
      cx: number,
      cy: number,
      cz: number,
      hx: number,
      hy: number,
      hz: number,
      tiltX: number,
      uTex: number,
      vTex: number
    ) => {
      const startV = positions.length / 3;
      const cosA = Math.cos(tiltX);
      const sinA = Math.sin(tiltX);
      const corners = [
        [-hx, -hy, -hz],
        [hx, -hy, -hz],
        [hx, hy, -hz],
        [-hx, hy, -hz],
        [-hx, -hy, hz],
        [hx, -hy, hz],
        [hx, hy, hz],
        [-hx, hy, hz],
      ];
      for (const [lx, ly, lz] of corners) {
        const ry = ly * cosA - lz * sinA;
        const rz = ly * sinA + lz * cosA;
        pushVert(cx + lx, cy + ry, cz + rz, uTex, vTex, footWeights(cz + rz, cy + ry));
      }
      const boxFaces = [
        [0, 1, 2, 3],
        [5, 4, 7, 6],
        [4, 0, 3, 7],
        [1, 5, 6, 2],
        [3, 2, 6, 7],
        [4, 5, 1, 0],
      ];
      for (const [a, b, c, d] of boxFaces) {
        indices.push(startV + a, startV + b, startV + c);
        indices.push(startV + a, startV + c, startV + d);
      }
    };

    // Padded sneaker tongue rising cleanly forward of the ankle
    addBoxDetail(0.157 * sideSign, 0.132, 0.015, 0.026, 0.018, 0.026, -0.45, 0.5, 0.92);

    // 4 crisp white shoelace bars stepping down the vamp
    for (let i = 0; i < 4; i++) {
      const lz = 0.032 + i * 0.022;
      const ly = 0.122 - i * 0.012;
      addBoxDetail(0.160 * sideSign, ly, lz, 0.027, 0.0045, 0.0055, -0.32, 0.5, 0.55);
    }
  };

  buildOneShoe(true);
  buildOneShoe(false);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(skinIndices, 4));
  geo.setAttribute('skinWeight', new THREE.Float32BufferAttribute(skinWeights, 4));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  geo.computeBoundingBox();
  geo.computeBoundingSphere();

  const tex = createStreetSneakerTexture(maxAnisotropy);
  const material = new THREE.MeshStandardMaterial({
    map: tex,
    roughness: 0.62,
    metalness: 0.04,
    envMapIntensity: 0.92,
  });

  const mesh = new THREE.SkinnedMesh(geo, material);
  mesh.name = 'Rider_StreetSneakers';
  mesh.castShadow = false;
  mesh.receiveShadow = false;
  mesh.frustumCulled = false;
  mesh.bind(skeleton, object4.bindMatrix);

  return { mesh, material };
}
