import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { GraphicsQuality } from './types';

interface BottleQualityProfile {
  outerDoubleSide: boolean;
  showTamperRing: boolean;
  anisotropyCap: number;
  waveScale: number;
  idleUpdateInterval: number;
  envScale: number;
}

const BOTTLE_QUALITY_PROFILES: Record<GraphicsQuality, BottleQualityProfile> = {
  low: {
    outerDoubleSide: false,
    showTamperRing: false,
    anisotropyCap: 1,
    waveScale: 0.0,
    idleUpdateInterval: 0.35,
    envScale: 0.65,
  },
  medium: {
    outerDoubleSide: false,
    showTamperRing: true,
    anisotropyCap: 2,
    waveScale: 0.6,
    idleUpdateInterval: 0.075,
    envScale: 0.85,
  },
  high: {
    outerDoubleSide: true,
    showTamperRing: true,
    anisotropyCap: 4,
    waveScale: 1.0,
    idleUpdateInterval: 0.085,
    envScale: 1.0,
  },
  ultra: {
    outerDoubleSide: true,
    showTamperRing: true,
    anisotropyCap: 8,
    waveScale: 1.15,
    idleUpdateInterval: 0,
    envScale: 1.15,
  },
};

/**
 * 3D Water Bottle ("Cristalina do Monte") loaded from /models/garrafa_agua.glb:
 * - Separates the screw cap (Object_2) into its own pivot so the rider can unscrew, lift, and recap it.
 * - Uses lean MeshStandardMaterial + Fresnel PET highlights (zero heavy transmission/clearcoat passes).
 * - Adapts draw calls, shader wave math, overdraw, and idle updates to the active GraphicsQuality preset.
 */
export class WaterBottleDevice {
  public readonly root = new THREE.Group();
  public readonly bodyGroup = new THREE.Group();
  public readonly capPivot = new THREE.Group();
  public readonly capOffsetGroup = new THREE.Group();

  private waterMesh: THREE.Mesh | null = null;
  private pourStreamMesh: THREE.Mesh | null = null;
  private outerPetMat: THREE.MeshStandardMaterial | null = null;
  private ringNode: THREE.Object3D | null = null;
  private labelTexture: THREE.Texture | null = null;
  private bottleMaterials: { mat: THREE.MeshStandardMaterial; baseEnv: number }[] = [];

  private reflectionsEnabled = true;
  private quality: GraphicsQuality = 'high';
  private profile: BottleQualityProfile = BOTTLE_QUALITY_PROFILES.high;
  private lastIdleUpdateTime = -1;
  private wasIdle = false;

  // Normalized bottle dimensions (meters, base at y=0, total height ~0.215m)
  public readonly bottleHeight = 0.215;
  public readonly capRestY = 0.203;
  public readonly gripCenterY = 0.095;

  // Shader uniforms for realistic gravity-leveled & sloshing water liquid inside the bottle
  private readonly waterUniforms = {
    uLocalUp: { value: new THREE.Vector3(0, 1, 0) },
    uPlaneD: { value: 0.145 },
    uTime: { value: 0 },
    uSlosh: { value: 0.002 },
    uWaveEnabled: { value: 1.0 },
  };

  // Scratch vectors (zero per-frame GC)
  private readonly _invQuat = new THREE.Quaternion();
  private readonly _worldUp = new THREE.Vector3(0, 1, 0);
  private readonly _localUp = new THREE.Vector3(0, 1, 0);
  private readonly _localDown = new THREE.Vector3(0, -1, 0);

  constructor(
    private readonly scene: THREE.Scene,
    private readonly maxAnisotropy = 4
  ) {
    this.root.name = 'WaterBottle_Cristalina';
    this.root.add(this.bodyGroup);
    this.capPivot.position.set(0, this.capRestY, 0);
    this.capPivot.add(this.capOffsetGroup);
    this.root.add(this.capPivot);
    this.scene.add(this.root);
  }

  public async loadModel(): Promise<void> {
    const loader = new GLTFLoader();
    const gltf = await loader.loadAsync('/models/garrafa_agua.glb');

    // Raw GLB dimensions: total height 18.14933 units (cap up to 18.1493, body up to 17.8378)
    // Scale cleanly to a realistic 500ml mineral water bottle (~21.5cm tall)
    const scale = this.bottleHeight / 18.14933;

    const capNode = gltf.scene.getObjectByName('Object_2');
    const ringNode = gltf.scene.getObjectByName('Object_3');
    const bodyNode = gltf.scene.getObjectByName('Object_4');

    const normalizeMeshNode = (node: THREE.Object3D | undefined, targetParent: THREE.Group, yOffset: number) => {
      if (!node) return;
      node.updateMatrixWorld(true);
      const wrap = new THREE.Group();
      wrap.scale.setScalar(scale);
      // Sketchfab_model applies -90 deg X rotation (raw +Z -> +Y)
      wrap.rotation.x = -Math.PI / 2;
      wrap.position.y = -yOffset;
      wrap.add(node);
      targetParent.add(wrap);
    };

    // Keep bottle body & tamper ring in bodyGroup (base sits at y=0)
    normalizeMeshNode(bodyNode, this.bodyGroup, 0);
    normalizeMeshNode(ringNode, this.bodyGroup, 0);
    this.ringNode = ringNode ?? null;

    // Put screw cap in capOffsetGroup centered at y = capRestY
    normalizeMeshNode(capNode, this.capOffsetGroup, this.capRestY);

    // Replace heavy imported MeshPhysicalMaterials (and strip unused 1024x1024 auxiliary textures)
    // with lean MeshStandardMaterials so the bottle renders smoothly on every quality tier.
    const configureMesh = (obj: THREE.Object3D, isOuterPet: boolean) => {
      obj.traverse((child: any) => {
        if (!child.isMesh) return;
        child.castShadow = false;
        child.receiveShadow = false;
        child.geometry?.computeBoundingSphere?.();
        child.frustumCulled = true;

        const oldMat = child.material as THREE.MeshPhysicalMaterial | THREE.MeshStandardMaterial | undefined;
        if (!oldMat) return;

        if (isOuterPet && oldMat.name === 'gua_5_Layer_Stack') {
          const labelMap = oldMat.map ?? null;
          if (labelMap) {
            labelMap.colorSpace = THREE.SRGBColorSpace;
            labelMap.anisotropy = Math.min(this.profile.anisotropyCap, this.maxAnisotropy);
            labelMap.needsUpdate = true;
            this.labelTexture = labelMap;
          }

          // Dispose unused constant 1024x1024 PBR maps from the raw GLB to save VRAM & fragment fetches
          oldMat.roughnessMap?.dispose?.();
          oldMat.metalnessMap?.dispose?.();
          if ('transmissionMap' in oldMat) (oldMat as any).transmissionMap?.dispose?.();
          if ('clearcoatRoughnessMap' in oldMat) (oldMat as any).clearcoatRoughnessMap?.dispose?.();

          const petMat = new THREE.MeshStandardMaterial({
            name: 'cristalina_pet_std',
            color: oldMat.color ? oldMat.color.clone() : new THREE.Color(0xf0f4f8),
            map: labelMap,
            transparent: true,
            depthWrite: false,
            side: this.profile.outerDoubleSide ? THREE.DoubleSide : THREE.FrontSide,
            roughness: 0.10,
            metalness: 0.07,
            envMapIntensity: 1.65,
          });
          oldMat.dispose();

          petMat.customProgramCacheKey = () => 'cristalina_pet_bottle_std_v2';
          petMat.onBeforeCompile = (shader) => {
            shader.fragmentShader = shader.fragmentShader.replace(
              '#include <map_fragment>',
              `#include <map_fragment>
// Fast Fresnel PET rim highlight + subtle clear bottle wall tint while keeping label opaque
float petRim = pow(1.0 - abs(dot(normalize(vNormal), normalize(vViewPosition))), 2.2);
float petWallAlpha = mix(0.20, 0.42, petRim);
diffuseColor.a = clamp(max(diffuseColor.a, petWallAlpha), petWallAlpha, 1.0);
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.88, 0.96, 1.0), petRim * (1.0 - diffuseColor.a) * 0.55);`
            );
          };

          child.material = petMat;
          child.renderOrder = 6;
          this.outerPetMat = petMat;
          this.bottleMaterials.push({ mat: petMat, baseEnv: 1.65 });
        } else {
          const isCap = oldMat.name === 'Plstico_2';
          if ('clearcoatRoughnessMap' in oldMat) (oldMat as any).clearcoatRoughnessMap?.dispose?.();
          oldMat.roughnessMap?.dispose?.();
          oldMat.metalnessMap?.dispose?.();

          const plasticMat = new THREE.MeshStandardMaterial({
            name: oldMat.name || (isCap ? 'cap_std' : 'ring_std'),
            color: oldMat.color ? oldMat.color.clone() : new THREE.Color(0x0a39df),
            roughness: isCap ? 0.24 : 0.60,
            metalness: 0.06,
            envMapIntensity: 1.2,
            side: THREE.FrontSide,
          });
          oldMat.dispose();

          child.material = plasticMat;
          child.renderOrder = 7;
          this.bottleMaterials.push({ mat: plasticMat, baseEnv: 1.2 });
        }
      });
    };

    if (bodyNode) configureMesh(bodyNode, true);
    if (ringNode) configureMesh(ringNode, false);
    if (capNode) configureMesh(capNode, false);

    this.createWaterLiquidVolume();
    this.createPourStream();
    this.applyQualityProfile();
  }

  private createWaterLiquidVolume(): void {
    // Lean inner bottle profile (16 radial segments -> < 280 tris)
    const pts: THREE.Vector2[] = [
      new THREE.Vector2(0.0, 0.008),
      new THREE.Vector2(0.0252, 0.010),
      new THREE.Vector2(0.0272, 0.022),
      new THREE.Vector2(0.0270, 0.062),
      new THREE.Vector2(0.0246, 0.078),
      new THREE.Vector2(0.0270, 0.096),
      new THREE.Vector2(0.0266, 0.142),
      new THREE.Vector2(0.0195, 0.168),
      new THREE.Vector2(0.0110, 0.200),
      new THREE.Vector2(0.0, 0.200),
    ];

    const geo = new THREE.LatheGeometry(pts, 16);
    geo.computeBoundingSphere();

    const mat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(0x52c8ff),
      emissive: new THREE.Color(0x0c4a6e),
      emissiveIntensity: 0.24,
      roughness: 0.06,
      metalness: 0.08,
      envMapIntensity: 1.55,
      transparent: true,
      opacity: 0.86,
      depthWrite: true,
      side: THREE.DoubleSide,
    });

    mat.customProgramCacheKey = () => 'bottle_water_liquid_std_v2';
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.uLocalUp = this.waterUniforms.uLocalUp;
      shader.uniforms.uPlaneD = this.waterUniforms.uPlaneD;
      shader.uniforms.uTime = this.waterUniforms.uTime;
      shader.uniforms.uSlosh = this.waterUniforms.uSlosh;
      shader.uniforms.uWaveEnabled = this.waterUniforms.uWaveEnabled;

      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vWaterPos;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWaterPos = position;');

      shader.fragmentShader = shader.fragmentShader
        .replace(
          '#include <common>',
          `#include <common>
uniform vec3 uLocalUp;
uniform float uPlaneD;
uniform float uTime;
uniform float uSlosh;
uniform float uWaveEnabled;
varying vec3 vWaterPos;`
        )
        .replace(
          '#include <clipping_planes_fragment>',
          `#include <clipping_planes_fragment>
float sloshWave = 0.0;
if (uWaveEnabled > 0.01) {
  sloshWave = (sin(vWaterPos.x * 85.0 + uTime * 7.5) * 0.6 + cos(vWaterPos.z * 92.0 - uTime * 6.2) * 0.4) * uSlosh * uWaveEnabled;
}
float signedHeight = dot(vWaterPos, normalize(uLocalUp)) + sloshWave;
if (signedHeight > uPlaneD) discard;`
        )
        .replace(
          '#include <map_fragment>',
          `#include <map_fragment>
float distToSurface = abs(uPlaneD - signedHeight);
float meniscus = 1.0 - smoothstep(0.0, 0.0055, distToSurface);
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.86, 0.96, 1.0), meniscus * 0.72);
if (!gl_FrontFacing) {
  diffuseColor.rgb = mix(vec3(0.45, 0.84, 1.0), vec3(0.92, 0.98, 1.0), 0.55);
  diffuseColor.a = 0.92;
}`
        );
    };

    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'WaterLiquid_Volume';
    mesh.renderOrder = 4;
    mesh.frustumCulled = true;
    this.bodyGroup.add(mesh);
    this.waterMesh = mesh;
    this.bottleMaterials.push({ mat, baseEnv: 1.55 });
  }

  private createPourStream(): void {
    // Slim tapered stream from bottle spout during pouring into mouth
    const geo = new THREE.CylinderGeometry(0.0022, 0.0052, 0.075, 8, 1, true);
    geo.translate(0, 0.0375, 0);
    geo.computeBoundingSphere();

    const mat = new THREE.MeshStandardMaterial({
      color: 0xa5e8ff,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.35,
      roughness: 0.08,
      metalness: 0.05,
      transparent: true,
      opacity: 0.75,
      depthWrite: false,
      side: THREE.FrontSide,
    });
    const stream = new THREE.Mesh(geo, mat);
    stream.name = 'WaterPour_Stream';
    stream.position.set(0, 0.212, 0);
    stream.visible = false;
    stream.renderOrder = 7;
    stream.frustumCulled = true;
    this.bodyGroup.add(stream);
    this.pourStreamMesh = stream;
  }

  /**
   * Builds a clean, grounded 3-part mounting bracket on the right front corner of the CG 160 ("canto da moto")
   * so the bottle rests securely when not drinking.
   */
  public static createBikeHolderMesh(): THREE.Group {
    const holder = new THREE.Group();
    holder.name = 'CG160_Bottle_Holder';

    const strapMat = new THREE.MeshStandardMaterial({
      color: 0x1a1d24,
      roughness: 0.52,
      metalness: 0.28,
      envMapIntensity: 1.0,
    });
    const alloyMat = new THREE.MeshStandardMaterial({
      color: 0x8b93a1,
      roughness: 0.24,
      metalness: 0.84,
      envMapIntensity: 1.35,
    });

    // 1. Base cup platform + upper ring + spine (merged into 1 dark strap mesh)
    const cupGeo = new THREE.CylinderGeometry(0.0325, 0.0305, 0.018, 12, 1, false);
    cupGeo.translate(0, 0.007, 0);

    const upperRingGeo = new THREE.TorusGeometry(0.0315, 0.0032, 6, 14);
    upperRingGeo.rotateX(Math.PI / 2);
    upperRingGeo.translate(0, 0.118, 0);

    const spineGeo = new THREE.BoxGeometry(0.012, 0.115, 0.016);
    spineGeo.translate(0, 0.064, -0.034);

    const strapMerged = mergeGeometries([cupGeo, upperRingGeo, spineGeo], false);
    cupGeo.dispose();
    upperRingGeo.dispose();
    spineGeo.dispose();
    if (strapMerged) {
      strapMerged.computeBoundingSphere();
      holder.add(new THREE.Mesh(strapMerged, strapMat));
    }

    // 2. Lower retaining ring + clamp (merged into 1 alloy mesh)
    const lowerRingGeo = new THREE.TorusGeometry(0.0315, 0.0032, 6, 14);
    lowerRingGeo.rotateX(Math.PI / 2);
    lowerRingGeo.translate(0, 0.022, 0);

    const clampGeo = new THREE.BoxGeometry(0.018, 0.022, 0.028);
    clampGeo.translate(0, 0.088, -0.046);

    const alloyMerged = mergeGeometries([lowerRingGeo, clampGeo], false);
    lowerRingGeo.dispose();
    clampGeo.dispose();
    if (alloyMerged) {
      alloyMerged.computeBoundingSphere();
      holder.add(new THREE.Mesh(alloyMerged, alloyMat));
    }

    return holder;
  }

  public setGraphicsQuality(quality: GraphicsQuality): void {
    this.quality = quality;
    this.profile = BOTTLE_QUALITY_PROFILES[quality];
    this.applyQualityProfile();
  }

  private applyQualityProfile(): void {
    const p = this.profile;
    if (this.outerPetMat) {
      this.outerPetMat.side = p.outerDoubleSide ? THREE.DoubleSide : THREE.FrontSide;
    }
    if (this.ringNode) {
      this.ringNode.visible = p.showTamperRing;
    }
    if (this.labelTexture) {
      const targetAniso = Math.min(p.anisotropyCap, this.maxAnisotropy);
      if (this.labelTexture.anisotropy !== targetAniso) {
        this.labelTexture.anisotropy = targetAniso;
        this.labelTexture.needsUpdate = true;
      }
    }
    this.waterUniforms.uWaveEnabled.value = p.waveScale;
    this.syncEnvMapIntensities();
    // Force immediate sync on next idle frame after quality change
    this.lastIdleUpdateTime = -1;
  }

  public setReflectionsEnabled(enabled: boolean): void {
    this.reflectionsEnabled = enabled;
    this.syncEnvMapIntensities();
  }

  private syncEnvMapIntensities(): void {
    const scale = (this.reflectionsEnabled ? 1.0 : 0.35) * this.profile.envScale;
    for (const entry of this.bottleMaterials) {
      entry.mat.envMapIntensity = entry.baseEnv * scale;
    }
  }

  /**
   * Updates internal water gravity tilt, liquid level height, slosh intensity, and pouring stream.
   * When stowed idle on low/medium quality, throttles uniform updates to eliminate per-frame overhead.
   */
  public updateLiquid(
    time: number,
    waterLevel: number,
    sloshIntensity: number,
    pourIntensity: number,
    isIdle = false
  ): void {
    if (this.waterMesh) {
      this.waterMesh.visible = waterLevel > 0.015;
    }

    if (isIdle && this.profile.idleUpdateInterval > 0) {
      if (this.wasIdle && this.lastIdleUpdateTime >= 0 && time - this.lastIdleUpdateTime < this.profile.idleUpdateInterval) {
        if (this.pourStreamMesh && this.pourStreamMesh.visible) {
          this.pourStreamMesh.visible = false;
        }
        return;
      }
      this.lastIdleUpdateTime = time;
    } else if (!isIdle) {
      this.lastIdleUpdateTime = -1;
    }
    this.wasIdle = isIdle;

    this.waterUniforms.uTime.value = time;
    this.waterUniforms.uSlosh.value = sloshIntensity;

    // this.root is a direct child of scene, so root.quaternion is already world orientation (no matrixWorld traversal needed)
    this._invQuat.copy(this.root.quaternion).invert();
    this._localUp.copy(this._worldUp).applyQuaternion(this._invQuat).normalize();
    this.waterUniforms.uLocalUp.value.copy(this._localUp);

    const uprightFactor = THREE.MathUtils.clamp(this._localUp.y, -0.8, 1.0);
    const fullRatio = THREE.MathUtils.clamp(waterLevel, 0, 1);

    const centerProj = 0.082 * uprightFactor;
    const halfSpan = THREE.MathUtils.lerp(0.026, 0.068, Math.abs(uprightFactor));
    this.waterUniforms.uPlaneD.value =
      centerProj + THREE.MathUtils.lerp(-halfSpan, halfSpan, fullRatio);

    if (this.pourStreamMesh) {
      const showPour = pourIntensity > 0.08 && waterLevel > 0.02;
      this.pourStreamMesh.visible = showPour;
      if (showPour) {
        this._localDown.copy(this._localUp).negate();
        this.pourStreamMesh.quaternion.setFromUnitVectors(this._worldUp, this._localDown);
        const pulse = 0.85 + Math.sin(time * 28) * 0.15;
        this.pourStreamMesh.scale.set(
          pulse * pourIntensity,
          THREE.MathUtils.clamp(pourIntensity, 0.25, 1.0),
          pulse * pourIntensity
        );
        (this.pourStreamMesh.material as THREE.MeshStandardMaterial).opacity =
          0.72 * pourIntensity;
      }
    }
  }

  public dispose(): void {
    this.root.traverse((obj: any) => {
      if (obj.isMesh) {
        obj.geometry?.dispose?.();
        const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
        for (const m of mats) {
          m?.map?.dispose?.();
          m?.dispose?.();
        }
      }
    });
    this.scene.remove(this.root);
  }
}
