import * as THREE from 'three';
import riderBodyStreetUrl from '../assets/images/rider_body_street_1794968619696.jpg';
import riderHeadUrl from '../assets/images/rider_head_v2.png';
import type { GloveShaderUniforms } from './RiderOutfitBuilder';
import type { RiderShoeStyle } from './types';

export interface CustomRiderBoneEntry {
  bone: THREE.Bone;
  qOff: THREE.Quaternion;
  qOffInv: THREE.Quaternion;
  restLocal: THREE.Quaternion;
}

export interface CustomFingerEntry {
  bone: THREE.Bone;
  rest: THREE.Quaternion;
  straight: THREE.Quaternion;
  qOff: THREE.Quaternion;
  qOffInv: THREE.Quaternion;
  weight: number;
  isProximal: boolean;
  slot: 'thumb' | 'index' | 'middle' | 'ring' | 'pinky';
}

export interface CustomHairSegment {
  bone: THREE.Bone;
  restLocal: THREE.Quaternion;
  pitchAxisLocal: THREE.Vector3;
  rollAxisLocal: THREE.Vector3;
  segWeight: number;
}

export interface CustomHairChain {
  segments: CustomHairSegment[];
  pitch: number;
  pitchVel: number;
  roll: number;
  rollVel: number;
  phaseOffset: number;
  stiffness: number;
  damping: number;
  isFront: boolean;
}

export interface CustomRiderOutfitUniforms {
  uShoeMode: { value: number }; // 0: street red/black/white, 1: monochrome classic
}

/**
 * Exact RPM (bike_rider.glb) bind-pose world quaternions used to calibrate
 * travis_scott.glb's bone local axes into BikeRig's expected coordinate frame.
 */
const RPM_REST_WORLD_QUATS: Record<string, [number, number, number, number]> = {
  Hips: [0.01623, -0.000026, 0, 0.999868],
  Spine_: [-0.052493, 0, 0, 0.998621],
  Spine1_: [-0.084595, 0, 0, 0.996415],
  Spine2_: [-0.037468, 0, 0, 0.999298],
  Neck_: [0.166238, 0, 0, 0.986086],
  Head_: [0.003612, 0, 0, 0.999993],
  LeftShoulder_: [0.486206, 0.469851, -0.532682, 0.509013],
  LeftArm_: [-0.663744, -0.207894, 0.699769, -0.162932],
  LeftForeArm_: [0.70043, 0.094652, -0.619767, 0.34107],
  LeftHand_: [0.737045, 0.091989, -0.602104, 0.29287],
  RightShoulder_: [0.486202, -0.469854, 0.53268, 0.509016],
  RightArm_: [0.663743, -0.2079, 0.699768, 0.162937],
  RightForeArm_: [0.700428, -0.094657, 0.619766, 0.341074],
  RightHand_: [0.737042, -0.091992, 0.602106, 0.292873],
  LeftUpLeg_: [-0.001985, -0.006607, 0.999435, -0.03291],
  LeftLeg_: [-0.000285, -0.048229, 0.998384, -0.030056],
  LeftFoot_: [-0.032214, 0.464571, 0.884553, -0.026502],
  RightUpLeg_: [0.001987, -0.006607, 0.999435, 0.03291],
  RightLeg_: [0.000286, -0.048229, 0.998384, 0.030056],
  RightFoot_: [0.032213, 0.46457, 0.884554, 0.026499],
  LeftHandThumb1: [0.740435, -0.327609, -0.439653, 0.38876],
  LeftHandThumb2: [0.782667, -0.181956, -0.559489, 0.203214],
  LeftHandThumb3: [0.783104, -0.125368, -0.592143, 0.142821],
  LeftHandIndex1: [0.733256, -0.030829, -0.622775, 0.271177],
  LeftHandIndex2: [0.75103, -0.110181, -0.614116, 0.216047],
  LeftHandIndex3: [0.719994, -0.161707, -0.662283, 0.129774],
  LeftHandMiddle1: [0.706879, 0.037433, -0.649008, 0.278766],
  LeftHandMiddle2: [0.731283, -0.078872, -0.642694, 0.214358],
  LeftHandMiddle3: [0.747509, -0.179829, -0.63863, 0.032293],
  LeftHandRing1: [0.713537, 0.079552, -0.6623, 0.214233],
  LeftHandRing2: [0.733013, -0.081464, -0.666464, 0.109006],
  LeftHandRing3: [0.732685, -0.109451, -0.666798, 0.081084],
  LeftHandPinky1: [-0.694511, -0.124178, 0.697182, -0.127168],
  LeftHandPinky2: [-0.548218, 0.032593, 0.8289, -0.106389],
  LeftHandPinky3: [-0.546762, 0.141987, 0.823764, -0.047989],
  RightHandThumb1: [0.740437, 0.327603, 0.43965, 0.388763],
  RightHandThumb2: [0.782673, 0.181944, 0.55948, 0.203226],
  RightHandThumb3: [0.783103, 0.125362, 0.592145, 0.142824],
  RightHandIndex1: [0.733255, 0.030824, 0.622774, 0.271182],
  RightHandIndex2: [0.751029, 0.110179, 0.614115, 0.216052],
  RightHandIndex3: [0.719999, 0.161698, 0.662278, 0.129786],
  RightHandMiddle1: [0.706876, -0.037437, 0.649008, 0.278771],
  RightHandMiddle2: [0.731283, 0.078866, 0.642693, 0.214363],
  RightHandMiddle3: [0.747508, 0.179825, 0.638632, 0.032293],
  RightHandRing1: [0.713535, -0.079558, 0.662299, 0.214239],
  RightHandRing2: [0.733015, 0.081455, 0.666461, 0.109013],
  RightHandRing3: [0.732683, 0.109447, 0.6668, 0.081089],
  RightHandPinky1: [0.694509, -0.124182, 0.697182, 0.127172],
  RightHandPinky2: [0.548218, 0.032588, 0.8289, 0.106395],
  RightHandPinky3: [0.546764, 0.141983, 0.823764, 0.047996],
};

export const TRAVIS_BONE_PREFIX_TO_NAME: Record<string, string> = {
  Hips: 'root_hips_05',
  Spine_: 'spine_01_06',
  Spine1_: 'spine_middle_08',
  Spine2_: 'spine_upper_09',
  Neck_: 'head_neck_lower_079',
  Head_: 'head_neck_upper_081',
  LeftShoulder_: 'arm_left_shoulder_2_011',
  LeftArm_: 'arm_left_shoulder_1_012',
  LeftForeArm_: 'arm_left_elbow_013',
  LeftHand_: 'arm_left_wrist_014',
  RightShoulder_: 'arm_right_shoulder_2_045',
  RightArm_: 'arm_right_shoulder_1_046',
  RightForeArm_: 'arm_right_elbow_047',
  RightHand_: 'arm_right_wrist_048',
  LeftUpLeg_: 'leg_left_thigh_0169',
  LeftLeg_: 'leg_left_knee_0170',
  LeftFoot_: 'leg_left_ankle_0175',
  RightUpLeg_: 'leg_right_thigh_0185',
  RightLeg_: 'leg_right_knee_0186',
  RightFoot_: 'leg_right_ankle_0191',
};

const FINGER_SLOT_MAP: {
  rpm: string;
  tsIdx: string;
  slot: 'thumb' | 'index' | 'middle' | 'ring' | 'pinky';
}[] = [
  { rpm: 'Thumb', tsIdx: '1', slot: 'thumb' },
  { rpm: 'Index', tsIdx: '2', slot: 'index' },
  { rpm: 'Middle', tsIdx: '3', slot: 'middle' },
  { rpm: 'Ring', tsIdx: '4', slot: 'ring' },
  { rpm: 'Pinky', tsIdx: '5', slot: 'pinky' },
];

const FINGER_SEG_MAP: {
  rpmSeg: '1' | '2' | '3';
  tsSeg: 'a' | 'b' | 'c';
  weight: number;
  isProximal: boolean;
  isMiddle: boolean;
}[] = [
  { rpmSeg: '1', tsSeg: 'a', weight: 0.72, isProximal: true, isMiddle: false },
  { rpmSeg: '2', tsSeg: 'b', weight: 1.05, isProximal: false, isMiddle: true },
  { rpmSeg: '3', tsSeg: 'c', weight: 0.85, isProximal: false, isMiddle: false },
];

export function isCustomTravisSkeleton(riderScene: THREE.Object3D): boolean {
  let found = false;
  riderScene.traverse((obj: any) => {
    if (obj.isBone && (obj.name === 'root_hips_05' || obj.name === 'root hips_05')) {
      found = true;
    }
  });
  return found;
}

function loadGltfSrgbTexture(url: string, maxAnisotropy: number): THREE.Texture {
  const loader = new THREE.TextureLoader();
  const tex = loader.load(url, (t) => {
    t.needsUpdate = true;
  });
  tex.flipY = false;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  return tex;
}

/**
 * Loads rider_head_v2.png, clears the misplaced upside-down face smudges on u <= 0.78
 * (preserving clean skin tone and ear islands), upgrades the eyebrows, and paints a clean
 * fallback eyeball island at the exact Travis Scott eyeball UV center.
 */
function loadEnhancedHeadTexture(url: string, maxAnisotropy: number): THREE.Texture {
  const loader = new THREE.TextureLoader();
  const tex = loader.load(url, (loaded) => {
    const img = loaded.image as CanvasImageSource & { width?: number; height?: number };
    if (!img || typeof document === 'undefined') {
      loaded.needsUpdate = true;
      return;
    }
    const size = 1024;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      loaded.needsUpdate = true;
      return;
    }

    ctx.drawImage(img, 0, 0, size, size);

    // 1. Sample clean warm skin tone from lower cheek/neck area (avoiding misplaced central blotches)
    // and smoothly repaint the misplaced face/neck smudge area (u=0.42..0.74, v=0.05..0.90)
    // + stray duplicate mouth miniatures (u=0.72..0.815, v=0.72..1.00) while preserving ear islands.
    let baseR = 136;
    let baseG = 86;
    let baseB = 56;
    try {
      const sample = ctx.getImageData(250, 620, 32, 32).data;
      let sr = 0;
      let sg = 0;
      let sb = 0;
      const n = sample.length / 4;
      for (let i = 0; i < sample.length; i += 4) {
        sr += sample[i];
        sg += sample[i + 1];
        sb += sample[i + 2];
      }
      baseR = Math.round(sr / n);
      baseG = Math.round(sg / n);
      baseB = Math.round(sb / n);
    } catch {
      // Ignore cross-origin pixel read fallback
    }

    const skinGrad = ctx.createRadialGradient(583, 620, 40, 583, 600, 360);
    skinGrad.addColorStop(0, `rgb(${Math.min(255, baseR + 6)}, ${Math.min(255, baseG + 4)}, ${Math.min(255, baseB + 3)})`);
    skinGrad.addColorStop(0.7, `rgb(${baseR}, ${baseG}, ${baseB})`);
    skinGrad.addColorStop(1, `rgba(${baseR}, ${baseG}, ${baseB}, 0.0)`);
    ctx.fillStyle = skinGrad;
    ctx.fillRect(390, 40, 355, 880);

    // Clear tiny duplicate miniature faces/mouths near bottom-right of main face island
    ctx.fillStyle = `rgb(${baseR}, ${baseG}, ${baseB})`;
    ctx.fillRect(730, 745, 92, 279);
    ctx.fillRect(465, 110, 220, 420);

    // 2. Repaint crisp feathered eyebrow hair strokes over top-right strips (x: 825..1015, y: 4..315)
    ctx.fillStyle = `rgb(${Math.max(40, baseR - 6)}, ${Math.max(25, baseG - 5)}, ${Math.max(15, baseB - 4)})`;
    ctx.fillRect(825, 0, 199, 322);
    let seed = 918273;
    const rand = () => {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };
    const stripCenters = [854, 892, 932, 972, 1002];
    for (const scx of stripCenters) {
      const bGrad = ctx.createLinearGradient(scx - 16, 0, scx + 16, 0);
      bGrad.addColorStop(0, 'rgba(22, 14, 10, 0.0)');
      bGrad.addColorStop(0.5, 'rgba(20, 12, 8, 0.48)');
      bGrad.addColorStop(1, 'rgba(22, 14, 10, 0.0)');
      ctx.fillStyle = bGrad;
      ctx.fillRect(scx - 16, 10, 32, 295);

      for (let h = 0; h < 260; h++) {
        const hy = 10 + rand() * 292;
        const hx = scx + (rand() - 0.5) * 20;
        const len = 10 + rand() * 14;
        const tilt = (rand() - 0.35) * 0.28;
        ctx.strokeStyle = rand() > 0.3 ? 'rgba(15, 10, 7, 0.88)' : 'rgba(34, 21, 14, 0.74)';
        ctx.lineWidth = 1.0 + rand() * 1.3;
        ctx.beginPath();
        ctx.moveTo(hx - Math.sin(tilt) * len * 0.5, hy - len * 0.5);
        ctx.lineTo(hx + Math.sin(tilt) * len * 0.5, hy + len * 0.5);
        ctx.stroke();
      }
    }

    // 3. Clean warm sclera + centered iris fallback at eyeball UV island (exact shading rendered in 3D eye shader)
    const ex = 911;
    const ey = 424;
    const scleraR = 96;
    const scGrad = ctx.createRadialGradient(ex - 4, ey - 4, 10, ex, ey, scleraR);
    scGrad.addColorStop(0, '#eee7e1');
    scGrad.addColorStop(0.65, '#e2d9d2');
    scGrad.addColorStop(1, '#c8b4a8');
    ctx.fillStyle = scGrad;
    ctx.fillRect(838, 336, 132, 224);

    const irisR = 32;
    const irisGrad = ctx.createRadialGradient(ex, ey, 6, ex, ey, irisR);
    irisGrad.addColorStop(0, '#2a160b');
    irisGrad.addColorStop(0.55, '#58321b');
    irisGrad.addColorStop(0.88, '#26140b');
    irisGrad.addColorStop(1, '#120a06');
    ctx.fillStyle = irisGrad;
    ctx.beginPath();
    ctx.arc(ex, ey, irisR, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#070504';
    ctx.beginPath();
    ctx.arc(ex, ey, 12.5, 0, Math.PI * 2);
    ctx.fill();

    (loaded as unknown as { image: HTMLCanvasElement }).image = canvas;
    loaded.needsUpdate = true;
  });
  tex.flipY = false;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  return tex;
}

/**
 * Generates high-detail seamless braided/twisted dreadlock albedo & bump textures
 * with crisp helical loc ridges, crevice AO, and warm espresso-black fiber streaks.
 */
function createDetailedDreadlockMaps(maxAnisotropy: number): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const size = 512;
  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const bImg = bCtx.createImageData(size, size);
  const ad = aImg.data;
  const bd = bImg.data;

  let seed = 773311;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  // Precompute fine vertical hair-fiber noise streaks
  const fiberCols = new Float32Array(size);
  for (let x = 0; x < size; x++) {
    fiberCols[x] = (rand() - 0.5) * 0.4 + Math.sin(x * 0.65) * 0.25;
  }

  for (let y = 0; y < size; y++) {
    const v = y / size;
    for (let x = 0; x < size; x++) {
      const u = x / size;
      // Seamless 2-strand twisted loc weave (period-matched across u & v)
      const twistA = Math.sin((u * 3.0 + v * 2.0) * Math.PI * 2.0);
      const twistB = Math.sin((u * 3.0 - v * 2.0 + 0.5) * Math.PI * 2.0);
      const ridge = 0.52 * twistA + 0.34 * twistB + 0.14 * Math.sin((u * 6.0 + v * 4.0) * Math.PI * 2.0);
      const ridge01 = clamp01(ridge * 0.5 + 0.5);
      const crevice = Math.pow(ridge01, 1.35);

      const strand = Math.sin((u * 48.0 + v * 12.0 + twistA * 0.6) * Math.PI * 2.0) * 0.5 + 0.5;
      const micro = fiberCols[(x + Math.round(v * 90)) % size] * 14 + (rand() - 0.5) * 8;

      const idx = (y * size + x) * 4;
      // Rich dark espresso-black dreadlocks (never flat plastic black)
      const lum = 13 + crevice * 30 + strand * 11 + micro * 0.5;
      ad[idx] = Math.min(255, Math.max(4, Math.round(lum * 1.15)));
      ad[idx + 1] = Math.min(255, Math.max(3, Math.round(lum * 0.86)));
      ad[idx + 2] = Math.min(255, Math.max(2, Math.round(lum * 0.68)));
      ad[idx + 3] = 255;

      const bumpVal = Math.min(255, Math.max(0, Math.round(45 + crevice * 165 + strand * 35)));
      bd[idx] = bumpVal;
      bd[idx + 1] = bumpVal;
      bd[idx + 2] = bumpVal;
      bd[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  bCtx.putImageData(bImg, 0, 0);

  const map = new THREE.CanvasTexture(albedoCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.anisotropy = Math.min(4, maxAnisotropy);
  map.needsUpdate = true;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.anisotropy = Math.min(4, maxAnisotropy);
  bumpMap.needsUpdate = true;

  return { map, bumpMap };
}

/**
 * Seats travis_scott.glb's Hair scalp cap flush against the Head skull (eliminating any
 * floating gap), enriches the original 13 braids, and grows 58 full-volume tapered
 * braided dreadlocks directly out of the skull — every lock rooted into the scalp and
 * skinned seamlessly to the nearest `dyn_braid_*` physics bone chain.
 */
function augmentExistingHairWithMoreStrands(
  geo: THREE.BufferGeometry,
  bones: THREE.Bone[],
  boneInverses: THREE.Matrix4[],
  headGeo: THREE.BufferGeometry | null
): void {
  const posAttr = geo.attributes.position as THREE.BufferAttribute | undefined;
  const normAttr = geo.attributes.normal as THREE.BufferAttribute | undefined;
  const uvAttr = geo.attributes.uv as THREE.BufferAttribute | undefined;
  const skinIdxAttr = geo.attributes.skinIndex as THREE.BufferAttribute | undefined;
  const skinWtAttr = geo.attributes.skinWeight as THREE.BufferAttribute | undefined;
  const indexAttr = geo.index;
  if (!posAttr || !normAttr || !uvAttr || !skinIdxAttr || !skinWtAttr || !indexAttr) return;

  // 1. Build skull surface & full-head collision points from Head geometry (u <= 0.78)
  const skullPts: { x: number; y: number; z: number; nx: number; ny: number; nz: number }[] = [];
  const headAllPts: { x: number; y: number; z: number }[] = [];
  if (headGeo) {
    const hPos = headGeo.attributes.position as THREE.BufferAttribute | undefined;
    const hNorm = headGeo.attributes.normal as THREE.BufferAttribute | undefined;
    const hUv = headGeo.attributes.uv as THREE.BufferAttribute | undefined;
    if (hPos && hUv) {
      for (let i = 0; i < hPos.count; i++) {
        if (hUv.getX(i) > 0.78) continue;
        const hx = hPos.getX(i);
        const hy = hPos.getY(i);
        const hz = hPos.getZ(i);
        if (hy > 1.66) {
          headAllPts.push({ x: hx, y: hy, z: hz });
        }
        // Cranium cap zone (crown, top forehead, sides above ears, back skull)
        const isFaceFront = hz > 0.05 && hy < 1.792 && Math.abs(hx) < 0.072;
        if (hy > 1.70 && !isFaceFront) {
          skullPts.push({
            x: hx,
            y: hy,
            z: hz,
            nx: hNorm ? hNorm.getX(i) : 0,
            ny: hNorm ? hNorm.getY(i) : 1,
            nz: hNorm ? hNorm.getZ(i) : 0,
          });
        }
      }
    }
  }

  // Fallback spherical skull helper when headGeo isn't available
  const headCenter = new THREE.Vector3(0, 1.772, -0.020);
  const sampleSkullByDir = (dx: number, dy: number, dz: number): THREE.Vector3 => {
    if (skullPts.length > 0) {
      let bestDot = -2;
      let bestIdx = 0;
      for (let i = 0; i < skullPts.length; i++) {
        const sp = skullPts[i];
        const rx = sp.x - headCenter.x;
        const ry = sp.y - headCenter.y;
        const rz = sp.z - headCenter.z;
        const invL = 1 / (Math.hypot(rx, ry, rz) || 1);
        const d = (rx * dx + ry * dy + rz * dz) * invL;
        if (d > bestDot) {
          bestDot = d;
          bestIdx = i;
        }
      }
      const sp = skullPts[bestIdx];
      return new THREE.Vector3(sp.x, sp.y, sp.z);
    }
    return new THREE.Vector3(
      headCenter.x + dx * 0.080,
      headCenter.y + dy * 0.088,
      headCenter.z + dz * 0.092
    );
  };

  // 2. Gather `head_neck_upper_081` index + all 13 `dyn_braid_*` bone chains with bind positions
  let headBoneIdx = 0;
  const tmpMat = new THREE.Matrix4();
  const tmpBonePos = new THREE.Vector3();
  const boneBindPos: THREE.Vector3[] = [];
  for (let b = 0; b < bones.length; b++) {
    const bn = bones[b]?.name || '';
    if (bn.includes('head_neck_upper') || bn.includes('head neck upper')) {
      headBoneIdx = b;
    }
    if (boneInverses[b]) {
      tmpMat.copy(boneInverses[b]).invert();
      tmpBonePos.setFromMatrixPosition(tmpMat);
      boneBindPos.push(tmpBonePos.clone());
    } else {
      boneBindPos.push(new THREE.Vector3(0, 1.77, -0.02));
    }
  }

  const boneToIdx = new Map<THREE.Bone, number>();
  bones.forEach((b, i) => boneToIdx.set(b, i));

  interface ChainSkinRef {
    segIndices: number[];
    rootPos: THREE.Vector3;
    isFront: boolean;
  }
  const chainRefs: ChainSkinRef[] = [];
  const headBoneObj = bones[headBoneIdx];
  if (headBoneObj) {
    for (const child of headBoneObj.children) {
      if (!(child as THREE.Bone).isBone || !child.name.includes('dyn_braid_')) continue;
      const segIndices: number[] = [];
      let cur: THREE.Bone | undefined = child as THREE.Bone;
      while (cur && !cur.name.includes('_end_') && segIndices.length < 4) {
        const idx = boneToIdx.get(cur);
        if (idx !== undefined) segIndices.push(idx);
        cur = cur.children.find(
          (c): c is THREE.Bone =>
            (c as THREE.Bone).isBone && c.name.includes('dyn_braid_') && !c.name.includes('_end_')
        );
      }
      if (segIndices.length > 0) {
        chainRefs.push({
          segIndices,
          rootPos: boneBindPos[segIndices[0]].clone(),
          isFront: child.name.includes('_fr_'),
        });
      }
    }
  }

  // 3. Seat original Hair scalp cap FLUSH onto Head skull (~2.2mm) & anchor/lengthen original 13 braids
  const origCount = posAttr.count;
  for (let i = 0; i < origCount; i++) {
    let braidWeight = 0;
    for (let k = 0; k < 4; k++) {
      const wt = skinWtAttr.getComponent(i, k);
      const bName = bones[skinIdxAttr.getComponent(i, k)]?.name || '';
      if (bName.includes('dyn_braid')) braidWeight += wt;
    }

    let px = posAttr.getX(i);
    let py = posAttr.getY(i);
    let pz = posAttr.getZ(i);

    if (skullPts.length > 0 && braidWeight <= 0.45) {
      // Snap scalp cap & braid roots flush to Head skull surface (fixes floating 1.6cm gap)
      let bestD2 = 99;
      let bestSp = skullPts[0];
      for (let s = 0; s < skullPts.length; s++) {
        const sp = skullPts[s];
        const dx = px - sp.x;
        const dy = py - sp.y;
        const dz = pz - sp.z;
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 < bestD2) {
          bestD2 = d2;
          bestSp = sp;
        }
      }
      const ox = bestSp.x - headCenter.x;
      const oy = bestSp.y - headCenter.y;
      const oz = bestSp.z - headCenter.z;
      const olen = Math.hypot(ox, oy, oz) || 1;
      const targetX = bestSp.x + (ox / olen) * 0.0022;
      const targetY = bestSp.y + (oy / olen) * 0.0022;
      const targetZ = bestSp.z + (oz / olen) * 0.0022;
      const snapMix = (1.0 - smoothstep(0.05, 0.45, braidWeight)) * 0.92;
      px += (targetX - px) * snapMix;
      py += (targetY - py) * snapMix;
      pz += (targetZ - pz) * snapMix;
    }

    if (braidWeight > 0.15) {
      // Slightly thicken & lengthen original 13 braids cleanly along hang direction
      const nx = normAttr.getX(i);
      const ny = normAttr.getY(i);
      const nz = normAttr.getZ(i);
      const drop = smoothstep(1.79, 1.63, py) * 0.028;
      const thick = smoothstep(1.80, 1.70, py) * 0.0018;
      px += nx * thick;
      py -= drop - ny * thick;
      pz += nz * thick;
    }

    posAttr.setXYZ(i, px, py, pz);
  }

  // 4. Generate 76 dense, full-volume tapered braided dreadlocks rooted directly inside the fitted skull
  interface LockSpec {
    azDeg: number; // 0 = front (+Z), +-90 = sides (+-X), 180 = back (-Z)
    elDeg: number; // angle above headCenter horizontal plane
    length: number;
    radius: number;
    flareOut: number; // initial arch lift away from crown before gravity drape
    sweepBack: number; // sweep back factor (keeps front locks sweeping past temples cleanly)
    lateralCurve: number; // smooth lateral temple sweep (no sharp kink)
    crownLift: number; // top arch height above scalp
    waveAmp: number;
    waveFreq: number;
    phase: number;
  }

  const locks: LockSpec[] = [];
  let pSeed = 314159;
  const srand = () => {
    pSeed = (pSeed * 16807) % 2147483647;
    return (pSeed - 1) / 2147483646;
  };

  // Row 0: Dense top-crown apex locks (12 locks giving full 3cm+ crown height & cohesive dread mass)
  for (let i = 0; i < 12; i++) {
    const az = -165 + (i / 12) * 330 + (srand() - 0.5) * 10;
    const isFrontHalf = Math.abs(az) < 75;
    locks.push({
      azDeg: az,
      elDeg: 74 + (srand() - 0.5) * 10,
      length: 0.195 + srand() * 0.038,
      radius: 0.0076 + srand() * 0.0014,
      flareOut: 0.026,
      sweepBack: isFrontHalf ? 0.62 : 0.24,
      lateralCurve: isFrontHalf ? (az >= 0 ? 1 : -1) * 0.026 : 0,
      crownLift: 0.032 + srand() * 0.008,
      waveAmp: 0.0055,
      waveFreq: 8.6,
      phase: srand() * Math.PI * 2,
    });
  }

  // Row 1: Front hairline / temple framing locks (12 locks arching cleanly over temples, zero eye overlap)
  for (const az of [-74, -62, -50, -38, -26, -15, 15, 26, 38, 50, 62, 74]) {
    const nearCenter = Math.abs(az) < 34;
    const sideSign = az >= 0 ? 1 : -1;
    locks.push({
      azDeg: az + (srand() - 0.5) * 3,
      elDeg: nearCenter ? 54 + (srand() - 0.5) * 4 : 40 + (srand() - 0.5) * 5,
      length: nearCenter ? 0.165 + srand() * 0.028 : 0.178 + srand() * 0.032,
      radius: 0.0072 + srand() * 0.0014,
      flareOut: nearCenter ? 0.024 : 0.020,
      sweepBack: nearCenter ? 0.58 : 0.34,
      lateralCurve: nearCenter ? sideSign * 0.038 : sideSign * 0.018,
      crownLift: nearCenter ? 0.024 : 0.014,
      waveAmp: 0.0048,
      waveFreq: 9.4,
      phase: srand() * Math.PI * 2,
    });
  }

  // Row 2: Dense upper crown ring (18 locks — rich rounded silhouette from every angle)
  for (let i = 0; i < 18; i++) {
    const az = -172 + (i / 18) * 344 + (srand() - 0.5) * 7;
    const isFront = Math.abs(az) < 55;
    locks.push({
      azDeg: az,
      elDeg: 54 + (srand() - 0.5) * 9,
      length: 0.195 + srand() * 0.035,
      radius: 0.0074 + srand() * 0.0015,
      flareOut: 0.024,
      sweepBack: isFront ? 0.52 : 0.18,
      lateralCurve: isFront ? (az >= 0 ? 1 : -1) * 0.022 : 0,
      crownLift: 0.020,
      waveAmp: 0.0052,
      waveFreq: 8.8,
      phase: srand() * Math.PI * 2,
    });
  }

  // Row 3: Mid-parietal sides & upper back (18 locks filling all temple/ear/occiput gaps)
  for (let i = 0; i < 18; i++) {
    const side = i < 9 ? -1 : 1;
    const tSide = (i % 9) / 8;
    const az = side * (64 + tSide * 114) + (srand() - 0.5) * 5;
    locks.push({
      azDeg: az,
      elDeg: 24 + (srand() - 0.5) * 9,
      length: 0.175 + srand() * 0.038,
      radius: 0.0072 + srand() * 0.0014,
      flareOut: 0.018,
      sweepBack: 0.14,
      lateralCurve: 0,
      crownLift: 0.008,
      waveAmp: 0.0048,
      waveFreq: 9.2,
      phase: srand() * Math.PI * 2,
    });
  }

  // Row 4: Lower back & nape locks (16 locks filling 100% of back skull down to collar)
  for (let i = 0; i < 16; i++) {
    const tBack = i / 15;
    const az = (i % 2 === 0 ? 1 : -1) * (102 + tBack * 78) + (srand() - 0.5) * 5;
    locks.push({
      azDeg: az,
      elDeg: 3 + (srand() - 0.5) * 11,
      length: 0.145 + srand() * 0.035,
      radius: 0.0068 + srand() * 0.0014,
      flareOut: 0.014,
      sweepBack: 0.10,
      lateralCurve: 0,
      crownLift: 0.004,
      waveAmp: 0.0042,
      waveFreq: 10.0,
      phase: srand() * Math.PI * 2,
    });
  }

  const radialSegs = 7;
  const lengthSegs = 9;
  const vertsPerLock = (lengthSegs + 1) * radialSegs + 1; // +1 rounded tip vertex
  const extraVertCount = locks.length * vertsPerLock;
  const totalVerts = origCount + extraVertCount;

  const newPos = new Float32Array(totalVerts * 3);
  const newNorm = new Float32Array(totalVerts * 3);
  const newUv = new Float32Array(totalVerts * 2);
  const newSkinIdx = new Uint16Array(totalVerts * 4);
  const newSkinWt = new Float32Array(totalVerts * 4);

  for (let i = 0; i < origCount; i++) {
    newPos[i * 3] = posAttr.getX(i);
    newPos[i * 3 + 1] = posAttr.getY(i);
    newPos[i * 3 + 2] = posAttr.getZ(i);
    newNorm[i * 3] = normAttr.getX(i);
    newNorm[i * 3 + 1] = normAttr.getY(i);
    newNorm[i * 3 + 2] = normAttr.getZ(i);
    newUv[i * 2] = uvAttr.getX(i);
    newUv[i * 2 + 1] = uvAttr.getY(i);
    for (let k = 0; k < 4; k++) {
      newSkinIdx[i * 4 + k] = skinIdxAttr.getComponent(i, k);
      newSkinWt[i * 4 + k] = skinWtAttr.getComponent(i, k);
    }
  }

  const newIndices: number[] = Array.from(indexAttr.array);
  const spinePts: THREE.Vector3[] = Array.from({ length: lengthSegs + 1 }, () => new THREE.Vector3());
  const tangent = new THREE.Vector3();
  const sideAxis = new THREE.Vector3();
  const binormAxis = new THREE.Vector3();
  const worldUp = new THREE.Vector3(0, 1, 0);
  const fallbackSide = new THREE.Vector3(1, 0, 0);

  let writeV = origCount;
  for (const lk of locks) {
    const azRad = THREE.MathUtils.degToRad(lk.azDeg);
    const elRad = THREE.MathUtils.degToRad(lk.elDeg);
    const cosEl = Math.cos(elRad);
    const dx = Math.sin(azRad) * cosEl;
    const dy = Math.sin(elRad);
    const dz = Math.cos(azRad) * cosEl;

    const skullPt = sampleSkullByDir(dx, dy, dz);
    // Embed root 2.5mm inside skull so every dreadlock grows directly out of the head with 0 gap
    const rootPt = skullPt.clone().addScaledVector(new THREE.Vector3(dx, dy, dz).normalize(), -0.0025);

    // Find closest dyn_braid_* chain to bind shaft & tip for real hair physics
    let bestChain: ChainSkinRef | null = null;
    let bestChainD2 = 99;
    const preferFront = dz > 0.28;
    for (const cr of chainRefs) {
      if (preferFront && !cr.isFront) continue;
      const d2 = cr.rootPos.distanceToSquared(rootPt);
      if (d2 < bestChainD2) {
        bestChainD2 = d2;
        bestChain = cr;
      }
    }
    if (!bestChain && chainRefs.length > 0) {
      for (const cr of chainRefs) {
        const d2 = cr.rootPos.distanceToSquared(rootPt);
        if (d2 < bestChainD2) {
          bestChainD2 = d2;
          bestChain = cr;
        }
      }
    }

    const outHLen = Math.hypot(dx, dz) || 1;
    const outX = dx / outHLen;
    const outZ = dz / outHLen;
    const sideSign = dx >= 0 ? 1 : -1;

    // Build smooth natural S-drape spine from rooted socket down past shoulders/neck
    for (let k = 0; k <= lengthSegs; k++) {
      const t = k / lengthSegs;
      const arch = Math.sin(Math.min(1, t * 2.2) * Math.PI * 0.5) * lk.flareOut;
      const radialSpread = t * (0.025 + lk.flareOut * 0.72);
      const dropY = lk.length * Math.pow(t, 1.24);
      const liftY = Math.sin(Math.min(1, t * 2.2) * Math.PI) * lk.crownLift;
      const wave = Math.sin(t * lk.waveFreq + lk.phase) * lk.waveAmp * smoothstep(0.15, 0.9, t);
      const templeCurve = lk.lateralCurve * Math.sin(Math.min(1, t * 1.45) * Math.PI * 0.5);

      let sx = rootPt.x + outX * (arch + radialSpread) + templeCurve - outZ * wave;
      let sy = rootPt.y + liftY - dropY;
      let sz = rootPt.z + outZ * (arch + radialSpread) - lk.sweepBack * t * 0.052 + outX * wave;

      // Smoothly guide front locks outside forehead/eye width without sharp kinks
      if (sz > 0.022 && sy < 1.795 && Math.abs(sx) < 0.068) {
        const blend = smoothstep(1.80, 1.755, sy);
        sx = THREE.MathUtils.lerp(sx, sideSign * 0.068, blend);
      }
      if (headAllPts.length > 0 && t > 0.14) {
        // Gentle clearance push away from nearest Head mesh point so locks drape outside skin/ears
        let nearD2 = 99;
        let nearHp = headAllPts[0];
        for (let h = 0; h < headAllPts.length; h++) {
          const hp = headAllPts[h];
          const d2 = (sx - hp.x) ** 2 + (sy - hp.y) ** 2 + (sz - hp.z) ** 2;
          if (d2 < nearD2) {
            nearD2 = d2;
            nearHp = hp;
          }
        }
        const minClear = lk.radius + 0.0045;
        if (nearD2 < minClear * minClear) {
          const d = Math.sqrt(nearD2) || 1e-4;
          const pushX = (sx - nearHp.x) / d;
          const pushZ = (sz - nearHp.z) / d;
          const pushH = Math.hypot(pushX, pushZ) || 1;
          sx = nearHp.x + (pushX / pushH) * minClear;
          sz = nearHp.z + (pushZ / pushH) * minClear;
        }
      }

      spinePts[k].set(sx, sy, sz);
    }

    const baseLockVert = writeV;
    for (let k = 0; k <= lengthSegs; k++) {
      const t = k / lengthSegs;
      if (k === 0) {
        tangent.subVectors(spinePts[1], spinePts[0]).normalize();
      } else if (k === lengthSegs) {
        tangent.subVectors(spinePts[k], spinePts[k - 1]).normalize();
      } else {
        tangent.subVectors(spinePts[k + 1], spinePts[k - 1]).normalize();
      }

      sideAxis.crossVectors(tangent, Math.abs(tangent.y) < 0.92 ? worldUp : fallbackSide).normalize();
      binormAxis.crossVectors(tangent, sideAxis).normalize();

      // Organic dreadlock taper (rounded root socket -> full rope body -> tapered dread tip)
      const ringR =
        lk.radius *
        (0.78 + 0.28 * Math.sin(Math.min(1, t * 1.45) * Math.PI * 0.5)) *
        (1.0 - 0.52 * Math.pow(t, 2.8));

      // Compute bone skin weights for this ring
      let idx0 = headBoneIdx;
      let idx1 = headBoneIdx;
      let w0 = 1.0;
      let w1 = 0.0;
      if (bestChain && bestChain.segIndices.length > 0) {
        if (t <= 0.18) {
          w1 = smoothstep(0.0, 0.18, t) * 0.65;
          w0 = 1.0 - w1;
          idx0 = headBoneIdx;
          idx1 = bestChain.segIndices[0];
        } else {
          const segT = clamp01((t - 0.18) / 0.82) * Math.max(0, bestChain.segIndices.length - 1);
          const s0 = Math.min(bestChain.segIndices.length - 1, Math.floor(segT));
          const s1 = Math.min(bestChain.segIndices.length - 1, s0 + 1);
          w1 = segT - s0;
          w0 = 1.0 - w1;
          idx0 = bestChain.segIndices[s0];
          idx1 = bestChain.segIndices[s1];
        }
      }

      for (let s = 0; s < radialSegs; s++) {
        const ang = (s / radialSegs) * Math.PI * 2;
        const ca = Math.cos(ang);
        const sa = Math.sin(ang);
        const nx = sideAxis.x * ca + binormAxis.x * sa;
        const ny = sideAxis.y * ca + binormAxis.y * sa;
        const nz = sideAxis.z * ca + binormAxis.z * sa;

        const vx = spinePts[k].x + nx * ringR;
        const vy = spinePts[k].y + ny * ringR;
        const vz = spinePts[k].z + nz * ringR;

        newPos[writeV * 3] = vx;
        newPos[writeV * 3 + 1] = vy;
        newPos[writeV * 3 + 2] = vz;
        newNorm[writeV * 3] = nx;
        newNorm[writeV * 3 + 1] = ny;
        newNorm[writeV * 3 + 2] = nz;
        newUv[writeV * 2] = s / radialSegs;
        newUv[writeV * 2 + 1] = t * 4.2;

        newSkinIdx[writeV * 4] = idx0;
        newSkinIdx[writeV * 4 + 1] = idx1;
        newSkinWt[writeV * 4] = w0;
        newSkinWt[writeV * 4 + 1] = w1;
        writeV++;
      }
    }

    // Closed tip cap vertex
    const tipCenter = spinePts[lengthSegs];
    tangent.subVectors(spinePts[lengthSegs], spinePts[lengthSegs - 1]).normalize();
    const tipVertIdx = writeV;
    newPos[writeV * 3] = tipCenter.x + tangent.x * 0.004;
    newPos[writeV * 3 + 1] = tipCenter.y + tangent.y * 0.004;
    newPos[writeV * 3 + 2] = tipCenter.z + tangent.z * 0.004;
    newNorm[writeV * 3] = tangent.x;
    newNorm[writeV * 3 + 1] = tangent.y;
    newNorm[writeV * 3 + 2] = tangent.z;
    newUv[writeV * 2] = 0.5;
    newUv[writeV * 2 + 1] = 4.4;
    const tipBone =
      bestChain && bestChain.segIndices.length > 0
        ? bestChain.segIndices[bestChain.segIndices.length - 1]
        : headBoneIdx;
    newSkinIdx[writeV * 4] = tipBone;
    newSkinWt[writeV * 4] = 1.0;
    writeV++;

    // Build triangle strips along dreadlock rings
    for (let k = 0; k < lengthSegs; k++) {
      const r0 = baseLockVert + k * radialSegs;
      const r1 = baseLockVert + (k + 1) * radialSegs;
      for (let s = 0; s < radialSegs; s++) {
        const sNext = (s + 1) % radialSegs;
        newIndices.push(r0 + s, r0 + sNext, r1 + s);
        newIndices.push(r0 + sNext, r1 + sNext, r1 + s);
      }
    }
    const lastRing = baseLockVert + lengthSegs * radialSegs;
    for (let s = 0; s < radialSegs; s++) {
      const sNext = (s + 1) % radialSegs;
      newIndices.push(lastRing + s, lastRing + sNext, tipVertIdx);
    }
  }

  geo.setAttribute('position', new THREE.Float32BufferAttribute(newPos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(newNorm, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(newUv, 2));
  geo.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(newSkinIdx, 4));
  geo.setAttribute('skinWeight', new THREE.Float32BufferAttribute(newSkinWt, 4));
  geo.setIndex(newIndices);
  geo.computeVertexNormals();
  geo.computeBoundingSphere();
}

/**
 * Slims travis_scott.glb's Body mesh radially around limb bones and narrows/flattens
 * the torso depth & waist width ("deixar ele um pouco mais seco") while keeping every
 * skeleton joint center exact so handlebars, footpegs, seat, and IK remain untouched.
 */
function slimCustomRiderBodyGeometry(
  geo: THREE.BufferGeometry,
  bones: THREE.Bone[]
): void {
  const posAttr = geo.attributes.position as THREE.BufferAttribute | undefined;
  const skinIdxAttr = geo.attributes.skinIndex as THREE.BufferAttribute | undefined;
  const skinWtAttr = geo.attributes.skinWeight as THREE.BufferAttribute | undefined;
  if (!posAttr || !skinIdxAttr || !skinWtAttr) return;

  const shoulderL = new THREE.Vector3(0.1984, 1.5003, -0.0541);
  const elbowL = new THREE.Vector3(0.4205, 1.3028, -0.0646);
  const wristL = new THREE.Vector3(0.5800, 1.1459, 0.0456);
  const shoulderR = new THREE.Vector3(-0.1984, 1.5003, -0.0541);
  const elbowR = new THREE.Vector3(-0.4205, 1.3028, -0.0646);
  const wristR = new THREE.Vector3(-0.5799, 1.1460, 0.0457);

  const thighL = new THREE.Vector3(0.0865, 1.0105, -0.0090);
  const kneeL = new THREE.Vector3(0.1362, 0.5776, -0.0112);
  const ankleL = new THREE.Vector3(0.1703, 0.1054, -0.0493);
  const thighR = new THREE.Vector3(-0.0865, 1.0105, -0.0090);
  const kneeR = new THREE.Vector3(-0.1362, 0.5776, -0.0112);
  const ankleR = new THREE.Vector3(-0.1703, 0.1054, -0.0493);

  const p = new THREE.Vector3();
  const ab = new THREE.Vector3();
  const ap = new THREE.Vector3();
  const proj = new THREE.Vector3();

  const shrinkToSegment = (a: THREE.Vector3, b: THREE.Vector3, radialScale: number) => {
    ab.subVectors(b, a);
    const lenSq = ab.lengthSq();
    if (lenSq < 1e-6) return 0;
    ap.subVectors(p, a);
    const t = clamp01(ap.dot(ab) / lenSq);
    proj.copy(a).addScaledVector(ab, t);
    p.sub(proj).multiplyScalar(radialScale).add(proj);
    return t;
  };

  for (let i = 0; i < posAttr.count; i++) {
    let maxW = -1;
    let domName = '';
    for (let k = 0; k < 4; k++) {
      const wt = skinWtAttr.getComponent(i, k);
      if (wt > maxW) {
        maxW = wt;
        domName = bones[skinIdxAttr.getComponent(i, k)]?.name || '';
      }
    }

    p.fromBufferAttribute(posAttr, i);

    const isHand =
      domName.includes('wrist') || domName.includes('finger') || domName.includes('metacarpal');
    const isFoot = p.y <= 0.145 || domName.includes('ankle') || domName.includes('toe');
    if (isHand || isFoot) continue;

    const isLeft = p.x >= 0;
    const isUpperArm =
      domName.includes('shoulder_1') ||
      domName.includes('shoulder 1') ||
      domName.includes('upperarm') ||
      domName.includes('bicep') ||
      domName.includes('tricep');
    const isForearm = domName.includes('elbow') || domName.includes('lowerarm');
    const isThigh = domName.includes('thigh') || domName.includes('legdangle');
    const isCalf = (domName.includes('knee') || domName.includes('calf')) && p.y > 0.145;
    const isNeck = domName.includes('neck') && !domName.includes('necklace');

    if (isUpperArm) {
      shrinkToSegment(isLeft ? shoulderL : shoulderR, isLeft ? elbowL : elbowR, 0.80);
    } else if (isForearm) {
      // Taper cleanly back to 1.0 near wrist cuff so wrist & glove meet flush
      const segA = isLeft ? elbowL : elbowR;
      const segB = isLeft ? wristL : wristR;
      ab.subVectors(segB, segA);
      const t = clamp01(ap.subVectors(p, segA).dot(ab) / Math.max(1e-6, ab.lengthSq()));
      const scale = 0.80 + smoothstep(0.72, 0.98, t) * 0.20;
      proj.copy(segA).addScaledVector(ab, t);
      p.sub(proj).multiplyScalar(scale).add(proj);
    } else if (isThigh) {
      shrinkToSegment(isLeft ? thighL : thighR, isLeft ? kneeL : kneeR, 0.79);
    } else if (isCalf) {
      // Taper back to 1.0 near sneaker ankle collar (y 0.145..0.23)
      const ankleBlend = smoothstep(0.145, 0.23, p.y);
      const scale = 1.0 - ankleBlend * 0.20;
      shrinkToSegment(isLeft ? kneeL : kneeR, isLeft ? ankleL : ankleR, scale);
    } else if (isNeck) {
      p.x *= 0.91;
      p.z = -0.052 + (p.z + 0.052) * 0.91;
    } else {
      // Torso / chest / waist / hips / shoulders / necklace chains: visibly leaner ("bem mais seco")
      const shoulderPinBlend = smoothstep(0.145, 0.215, Math.abs(p.x));
      const xScale = 0.82 + shoulderPinBlend * 0.12;
      p.x *= xScale;
      p.z = -0.025 + (p.z + 0.025) * 0.79;
    }

    posAttr.setXYZ(i, p.x, p.y, p.z);
  }

  posAttr.needsUpdate = true;
  geo.computeVertexNormals();
}

function createSkinPoreDetailTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const imgData = ctx.createImageData(size, size);
  const d = imgData.data;

  let seed = 424242;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const fine = (rand() - 0.5) * 26;
      const pore = rand() > 0.915 ? -22 : 0;
      const warm = Math.sin(x * 0.14 + y * 0.09) * 5 + Math.cos(x * 0.08 - y * 0.12) * 5;
      d[idx] = Math.min(255, Math.max(0, Math.round(238 + fine + pore + warm)));
      d[idx + 1] = Math.min(255, Math.max(0, Math.round(232 + fine * 0.9 + pore + warm * 0.6)));
      d[idx + 2] = Math.min(255, Math.max(0, Math.round(226 + fine * 0.8 + pore)));
      d[idx + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  tex.needsUpdate = true;
  return tex;
}

function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = clamp01((x - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

/**
 * Generates a high-resolution 1024x1024 seamless black-and-grey street-tattoo atlas.
 * Horizontal U wraps 0..1 continuously around limbs (using LinearFilter + generateMipmaps = false
 * to avoid atan2 seam artifacts).
 * Vertical V bands:
 *   0.04..0.38: Upper arm / bicep sleeve (roses, angel wing, geometric diamond)
 *   0.40..0.84: Full forearm sleeve (Roman clock, compass, "FÉ" banner, rose/thorns, wrist cuff)
 *   0.85..0.92: Dorsal back-of-hand motif (compact rose + rays, stops strictly before knuckles)
 *   0.93..0.99: Neck side tattoo (ornate script/wing filigree)
 */
function createRiderTattooTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const w = 1024;
  const h = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, w, h);

  const inkDark = 'rgba(14, 18, 22, 0.92)';
  const inkMid = 'rgba(20, 25, 32, 0.65)';
  const inkSoft = 'rgba(24, 30, 38, 0.34)';

  const drawRose = (cx: number, cy: number, radius: number, alpha = 1.0) => {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.globalAlpha = alpha;

    // Soft stipple halo
    const grad = ctx.createRadialGradient(0, 0, radius * 0.15, 0, 0, radius * 1.35);
    grad.addColorStop(0, 'rgba(16, 20, 26, 0.55)');
    grad.addColorStop(0.65, 'rgba(16, 20, 26, 0.22)');
    grad.addColorStop(1, 'rgba(16, 20, 26, 0.0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, radius * 1.35, 0, Math.PI * 2);
    ctx.fill();

    // Leaves around rose
    ctx.fillStyle = inkMid;
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 2.2;
    for (let i = 0; i < 4; i++) {
      const ang = i * (Math.PI * 0.5) + 0.45;
      ctx.save();
      ctx.rotate(ang);
      ctx.beginPath();
      ctx.moveTo(radius * 0.65, 0);
      ctx.quadraticCurveTo(radius * 1.15, -radius * 0.32, radius * 1.38, 0);
      ctx.quadraticCurveTo(radius * 1.15, radius * 0.32, radius * 0.65, 0);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    // Layered petals
    const layers = [
      { petals: 6, r: radius * 0.92, w: radius * 0.52 },
      { petals: 5, r: radius * 0.62, w: radius * 0.40 },
      { petals: 4, r: radius * 0.34, w: radius * 0.25 },
    ];
    for (let l = 0; l < layers.length; l++) {
      const lay = layers[l];
      for (let p = 0; p < lay.petals; p++) {
        const a = (p / lay.petals) * Math.PI * 2 + l * 0.42;
        const px = Math.cos(a) * lay.r * 0.48;
        const py = Math.sin(a) * lay.r * 0.48;
        ctx.save();
        ctx.translate(px, py);
        ctx.rotate(a);
        const pg = ctx.createRadialGradient(-lay.w * 0.15, 0, 1, 0, 0, lay.w);
        pg.addColorStop(0, 'rgba(18, 22, 28, 0.22)');
        pg.addColorStop(0.75, 'rgba(14, 18, 24, 0.72)');
        pg.addColorStop(1, 'rgba(10, 14, 18, 0.95)');
        ctx.fillStyle = pg;
        ctx.strokeStyle = inkDark;
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.ellipse(0, 0, lay.w * 0.62, lay.w * 0.88, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }
    }

    // Inner swirl
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    for (let t = 0; t < Math.PI * 4.5; t += 0.25) {
      const rr = (t / (Math.PI * 4.5)) * radius * 0.24;
      const sx = Math.cos(t) * rr;
      const sy = Math.sin(t) * rr;
      if (t === 0) ctx.moveTo(sx, sy);
      else ctx.lineTo(sx, sy);
    }
    ctx.stroke();
    ctx.restore();
  };

  const drawCompassStar = (cx: number, cy: number, radius: number) => {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 2.2;

    // Outer dashed circle
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.84, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.72, 0, Math.PI * 2);
    ctx.strokeStyle = inkMid;
    ctx.stroke();

    // 8-point compass points
    for (let i = 0; i < 8; i++) {
      const ang = (i * Math.PI) / 4;
      const len = i % 2 === 0 ? radius : radius * 0.64;
      const half = i % 2 === 0 ? radius * 0.17 : radius * 0.11;
      ctx.save();
      ctx.rotate(ang);
      ctx.fillStyle = inkDark;
      ctx.beginPath();
      ctx.moveTo(0, -len);
      ctx.lineTo(half, 0);
      ctx.lineTo(0, 0);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = inkSoft;
      ctx.beginPath();
      ctx.moveTo(0, -len);
      ctx.lineTo(-half, 0);
      ctx.lineTo(0, 0);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = inkDark;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(0, -len);
      ctx.lineTo(half, 0);
      ctx.lineTo(0, 0);
      ctx.lineTo(-half, 0);
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
  };

  const drawRomanClock = (cx: number, cy: number, radius: number) => {
    ctx.save();
    ctx.translate(cx, cy);
    const bg = ctx.createRadialGradient(0, 0, radius * 0.2, 0, 0, radius * 1.15);
    bg.addColorStop(0, 'rgba(18, 22, 28, 0.14)');
    bg.addColorStop(0.75, 'rgba(14, 18, 24, 0.56)');
    bg.addColorStop(1, 'rgba(14, 18, 24, 0.0)');
    ctx.fillStyle = bg;
    ctx.beginPath();
    ctx.arc(0, 0, radius * 1.15, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.72, 0, Math.PI * 2);
    ctx.stroke();

    const numerals = ['XII', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];
    ctx.fillStyle = inkDark;
    ctx.font = `bold ${Math.round(radius * 0.22)}px serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const rx = Math.cos(a) * radius * 0.85;
      const ry = Math.sin(a) * radius * 0.85;
      ctx.save();
      ctx.translate(rx, ry);
      ctx.rotate(a + Math.PI / 2);
      ctx.fillText(numerals[i], 0, 0);
      ctx.restore();
    }

    // Ornate clock hands (10:10)
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 4.2;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-radius * 0.34, -radius * 0.32);
    ctx.moveTo(0, 0);
    ctx.lineTo(radius * 0.44, -radius * 0.42);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  // Helper to tile horizontally cleanly across U=0/1 wrap
  const wrapDraw = (fn: (ox: number) => void) => {
    fn(-w);
    fn(0);
    fn(w);
  };

  // --- BAND 1: UPPER ARM / BICEP SLEEVE (y = 50..385) ---
  wrapDraw((ox) => {
    // Soft smoke/stipple backdrop
    const gSmoke = ctx.createLinearGradient(0, 60, 0, 380);
    gSmoke.addColorStop(0, 'rgba(18, 22, 26, 0.0)');
    gSmoke.addColorStop(0.25, 'rgba(18, 22, 26, 0.28)');
    gSmoke.addColorStop(0.75, 'rgba(18, 22, 26, 0.32)');
    gSmoke.addColorStop(1, 'rgba(18, 22, 26, 0.0)');
    ctx.fillStyle = gSmoke;
    ctx.fillRect(ox, 60, w, 320);

    // Crowned Rose centered on lateral bicep (u = 0.5)
    drawRose(ox + 512, 225, 76, 0.95);
    // 3-point crown above rose
    ctx.save();
    ctx.translate(ox + 512, 128);
    ctx.strokeStyle = inkDark;
    ctx.fillStyle = inkMid;
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(-46, 20);
    ctx.lineTo(-56, -24);
    ctx.lineTo(-22, 2);
    ctx.lineTo(0, -34);
    ctx.lineTo(22, 2);
    ctx.lineTo(56, -24);
    ctx.lineTo(46, 20);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    // Winged geometric diamond on inner/front bicep (u = 0.18 & u = 0.82)
    drawCompassStar(ox + 190, 215, 72);
    drawRose(ox + 835, 225, 68, 0.9);

    // Sweeping barbed filigree / thorns connecting bicep pieces
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(ox, 295);
    ctx.bezierCurveTo(ox + 260, 240, ox + 420, 355, ox + 660, 285);
    ctx.bezierCurveTo(ox + 820, 240, ox + 930, 320, ox + 1024, 295);
    ctx.stroke();
  });

  // --- BAND 2: FULL FOREARM SLEEVE (y = 415..855) ---
  wrapDraw((ox) => {
    // Rich shaded smoke base linking the entire sleeve cleanly
    for (let i = 0; i < 6; i++) {
      const sx = ox + 85 + i * 170;
      const sy = 590 + (i % 2 === 0 ? -45 : 55);
      const sg = ctx.createRadialGradient(sx, sy, 12, sx, sy, 145);
      sg.addColorStop(0, 'rgba(14, 18, 24, 0.36)');
      sg.addColorStop(0.6, 'rgba(14, 18, 24, 0.16)');
      sg.addColorStop(1, 'rgba(14, 18, 24, 0.0)');
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.arc(sx, sy, 145, 0, Math.PI * 2);
      ctx.fill();
    }

    // Hero dorsal forearm centerpiece (u = 0.5 -> ox + 512): Clock + Rose + "FÉ" banner
    drawRomanClock(ox + 512, 540, 88);
    drawRose(ox + 412, 685, 62, 0.96);
    drawCompassStar(ox + 635, 680, 62);

    // "FÉ" ornamental ribbon banner across mid-dorsal forearm (u = 0.5)
    ctx.save();
    ctx.translate(ox + 528, 760);
    ctx.fillStyle = 'rgba(20, 24, 30, 0.18)';
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.roundRect(-84, -26, 168, 52, 12);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = inkDark;
    ctx.font = 'italic bold 42px Georgia, serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('FÉ', 0, 2);
    ctx.restore();

    // Inner & outer side forearm art (u = 0.14 & u = 0.86)
    drawRose(ox + 165, 535, 66, 0.92);
    drawCompassStar(ox + 180, 705, 58);
    drawRomanClock(ox + 855, 610, 72);

    // Coiled thorn / vine wave running smoothly around sleeve
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(ox, 455);
    ctx.bezierCurveTo(ox + 260, 420, ox + 460, 495, ox + 740, 445);
    ctx.bezierCurveTo(ox + 890, 420, ox + 960, 470, ox + 1024, 455);
    ctx.stroke();

    // Crisp geometric diamond cuff band right near the wrist (y = 805..842)
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 3.4;
    ctx.beginPath();
    ctx.moveTo(ox, 804);
    ctx.lineTo(ox + w, 804);
    ctx.moveTo(ox, 842);
    ctx.lineTo(ox + w, 842);
    ctx.stroke();
    const step = 32;
    for (let x = 0; x < w; x += step) {
      ctx.fillStyle = (x / step) % 2 === 0 ? inkDark : inkMid;
      ctx.beginPath();
      ctx.moveTo(ox + x + step * 0.5, 806);
      ctx.lineTo(ox + x + step - 2, 823);
      ctx.lineTo(ox + x + step * 0.5, 840);
      ctx.lineTo(ox + x + 2, 823);
      ctx.closePath();
      ctx.fill();
    }
  });

  // --- BAND 3: DORSAL BACK-OF-HAND MOTIF (y = 868..934) ---
  wrapDraw((ox) => {
    // Centered at u = 0.5 (dorsal back of hand)
    drawRose(ox + 512, 902, 28, 0.95);
    // Ornamental sun/compass rays flanking the hand rose
    ctx.strokeStyle = inkDark;
    ctx.lineWidth = 2.4;
    for (let i = -3; i <= 3; i++) {
      if (i === 0) continue;
      const x1 = ox + 512 + i * 16;
      ctx.beginPath();
      ctx.moveTo(ox + 512 + i * 7, 902);
      ctx.lineTo(x1, 902 + (Math.abs(i) % 2 === 0 ? -16 : 16));
      ctx.stroke();
    }
  });

  // --- BAND 4: NECK SIDE TATTOO (y = 944..1012) ---
  wrapDraw((ox) => {
    // Wings / script on left & right sides of neck (u = 0.25 and u = 0.75)
    for (const nxCenter of [ox + 256, ox + 768]) {
      ctx.save();
      ctx.translate(nxCenter, 978);
      ctx.strokeStyle = inkDark;
      ctx.fillStyle = inkMid;
      ctx.lineWidth = 2.4;
      for (let f = -2; f <= 2; f++) {
        ctx.beginPath();
        ctx.ellipse(f * 13, Math.abs(f) * 2.5, 6.5, 22 - Math.abs(f) * 3, f * 0.16, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
    }
  });

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  // Disable mipmaps to guarantee zero seam line across atan2(y, x) UV wrap boundary!
  tex.generateMipmaps = false;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.anisotropy = Math.min(4, maxAnisotropy);
  tex.needsUpdate = true;
  return tex;
}

/**
 * Wires travis_scott.glb skeleton, AI-generated & UV-aligned PBR textures,
 * axis-offset calibration (`qOff`), 1st-person torso/head masking, tactical gloves,
 * and Workshop outfit/shirt/shoe customization into BikeRig.
 */
export function wireCustomTravisRider(params: {
  riderScene: THREE.Group;
  bones: Map<string, THREE.Bone>;
  restQuats: Map<string, THREE.Quaternion>;
  restPositions: Map<string, THREE.Vector3>;
  boneOffsets: Map<THREE.Bone, CustomRiderBoneEntry>;
  leftFingerBones: CustomFingerEntry[];
  rightFingerBones: CustomFingerEntry[];
  firstPersonHeadMeshes: THREE.Object3D[];
  helmetHiddenHairMeshes?: THREE.Object3D[];
  hairChains?: CustomHairChain[];
  hideTorsoUniform: { value: number };
  gloveUniforms: GloveShaderUniforms;
  outfitUniforms: CustomRiderOutfitUniforms;
  maxAnisotropy: number;
}): {
  headBone: THREE.Bone | null;
  neckBone: THREE.Bone | null;
  spine2Bone: THREE.Bone | null;
  hipsBone: THREE.Bone | null;
} {
  const {
    riderScene,
    bones,
    restQuats,
    restPositions,
    boneOffsets,
    leftFingerBones,
    rightFingerBones,
    firstPersonHeadMeshes,
    helmetHiddenHairMeshes,
    hairChains,
    hideTorsoUniform,
    gloveUniforms,
    outfitUniforms,
    maxAnisotropy,
  } = params;

  riderScene.updateMatrixWorld(true);

  const nameToBone = new Map<string, THREE.Bone>();
  riderScene.traverse((obj: any) => {
    if (obj.isBone && obj.name) {
      nameToBone.set(obj.name, obj as THREE.Bone);
    }
  });

  const tmpWorldQ = new THREE.Quaternion();
  const tmpRpmQ = new THREE.Quaternion();

  // 1. Register main skeleton bones & compute qOff = Q_rpm_rest^-1 * Q_ts_rest
  for (const [rpmPrefix, tsName] of Object.entries(TRAVIS_BONE_PREFIX_TO_NAME)) {
    const bone = nameToBone.get(tsName) ?? nameToBone.get(tsName.replace(/_/g, ' '));
    if (!bone) continue;

    bones.set(rpmPrefix, bone);
    restQuats.set(rpmPrefix, bone.quaternion.clone());
    restPositions.set(rpmPrefix, bone.position.clone());

    const rpmArr = RPM_REST_WORLD_QUATS[rpmPrefix];
    const qOff = new THREE.Quaternion();
    if (rpmArr) {
      bone.getWorldQuaternion(tmpWorldQ);
      tmpRpmQ.set(rpmArr[0], rpmArr[1], rpmArr[2], rpmArr[3]).normalize();
      qOff.copy(tmpRpmQ).invert().multiply(tmpWorldQ).normalize();
    }
    boneOffsets.set(bone, {
      bone,
      qOff: qOff.clone(),
      qOffInv: qOff.clone().invert(),
      restLocal: bone.quaternion.clone(),
    });
  }

  // 2. Register all 5 fingers (Left & Right, 3 phalanges each) & compute exact straight reference pose.
  // We unbend each chain sequentially (a -> b -> c) via shortest-arc alignment of the bone's +Y axis
  // onto the flat RPM hand axis (`qRpmHand`) or clean abducted thumb plane (`qThumbWorldRef`), so
  // crooked rest-pose offsets in travis_scott.glb never skew emotes or cause finger twisting.
  const unitY = new THREE.Vector3(0, 1, 0);
  const boneCurY = new THREE.Vector3();
  const targetFingerY = new THREE.Vector3();
  const arcQ = new THREE.Quaternion();
  const qParentW = new THREE.Quaternion();
  const qStraightW = new THREE.Quaternion();
  const qRpmHand = new THREE.Quaternion();
  const qThumbWorldRef = new THREE.Quaternion();
  const mThumbBasis = new THREE.Matrix4();
  const thumbX = new THREE.Vector3();
  const thumbY = new THREE.Vector3();
  const thumbZ = new THREE.Vector3();
  const thumbCurlTo = new THREE.Vector3();

  for (const side of ['Left', 'Right'] as const) {
    const tsSide = side.toLowerCase();
    const targetList = side === 'Left' ? leftFingerBones : rightFingerBones;
    const handArr = RPM_REST_WORLD_QUATS[`${side}Hand_`];
    qRpmHand.set(handArr[0], handArr[1], handArr[2], handArr[3]).normalize();

    const sign = side === 'Left' ? 1 : -1;
    // Construct clean abducted thumb basis in RPM hand space so thumb +Y flares naturally outward
    // and +X curl axis flexes cleanly across the palm (+Z).
    thumbY.set(-0.54 * sign, 0.78, 0.31).normalize();
    thumbCurlTo.set(0.62 * sign, -0.10, 0.78).normalize();
    thumbX.crossVectors(thumbY, thumbCurlTo).normalize();
    thumbZ.crossVectors(thumbX, thumbY).normalize();
    mThumbBasis.makeBasis(thumbX, thumbY, thumbZ);
    qThumbWorldRef.setFromRotationMatrix(mThumbBasis).premultiply(qRpmHand).normalize();

    for (const fSlot of FINGER_SLOT_MAP) {
      const refQ = fSlot.slot === 'thumb' ? qThumbWorldRef : qRpmHand;
      targetFingerY.copy(unitY).applyQuaternion(refQ).normalize();

      const chainRestQuats: { bone: THREE.Bone; rest: THREE.Quaternion }[] = [];

      for (const seg of FINGER_SEG_MAP) {
        const prefixSanitized = `arm_${tsSide}_finger_${fSlot.tsIdx}${seg.tsSeg}_`;
        const prefixRaw = `arm ${tsSide} finger ${fSlot.tsIdx}${seg.tsSeg}_`;
        let bone: THREE.Bone | undefined;
        for (const [bName, bObj] of nameToBone) {
          if (
            (bName.startsWith(prefixSanitized) || bName.startsWith(prefixRaw)) &&
            !bName.includes('_end_')
          ) {
            bone = bObj;
            break;
          }
        }
        if (!bone || !bone.parent) continue;

        const restLocal = bone.quaternion.clone();
        chainRestQuats.push({ bone, rest: restLocal });

        // Update world matrices sequentially so straightening proximal 'a' updates 'b' and 'c'
        riderScene.updateMatrixWorld(true);
        bone.getWorldQuaternion(tmpWorldQ);
        bone.parent.getWorldQuaternion(qParentW);

        boneCurY.copy(unitY).applyQuaternion(tmpWorldQ).normalize();
        arcQ.setFromUnitVectors(boneCurY, targetFingerY);
        qStraightW.copy(arcQ).multiply(tmpWorldQ).normalize();

        const straightLocal = qParentW.clone().invert().multiply(qStraightW).normalize();
        bone.quaternion.copy(straightLocal);

        const qOff = refQ.clone().invert().multiply(qStraightW).normalize();
        const qOffInv = qOff.clone().invert();

        targetList.push({
          bone,
          rest: restLocal,
          straight: straightLocal,
          qOff,
          qOffInv,
          weight: seg.weight,
          isProximal: seg.isProximal,
          slot: fSlot.slot,
        });
      }

      // Restore original rest quaternions on the finger chain after calibration
      for (const saved of chainRestQuats) {
        saved.bone.quaternion.copy(saved.rest);
      }
    }
  }
  riderScene.updateMatrixWorld(true);

  // 3. Calibrate skin tone & load AI PBR textures (with GLTF flipY = false!)
  const skinRgb: [number, number, number] = [138, 92, 64];
  const skinLinearColor = new THREE.Color(
    skinRgb[0] / 255,
    skinRgb[1] / 255,
    skinRgb[2] / 255
  ).convertSRGBToLinear();
  if (gloveUniforms.uSkinBaseColor) {
    gloveUniforms.uSkinBaseColor.value.copy(skinLinearColor);
  }

  const bodyTex = loadGltfSrgbTexture(riderBodyStreetUrl, maxAnisotropy);
  const headTex = loadEnhancedHeadTexture(riderHeadUrl, maxAnisotropy);
  const dreadMaps = createDetailedDreadlockMaps(maxAnisotropy);
  const skinDetailTex = createSkinPoreDetailTexture(maxAnisotropy);
  const tattooTex = createRiderTattooTexture(maxAnisotropy);

  if (gloveUniforms.uBareHandMap) {
    gloveUniforms.uBareHandMap.value = skinDetailTex;
  }

  const sharedHairMat = new THREE.MeshStandardMaterial({
    map: dreadMaps.map,
    bumpMap: dreadMaps.bumpMap,
    bumpScale: 0.011,
    color: 0xffffff,
    roughness: 0.64,
    metalness: 0.03,
    envMapIntensity: 0.85,
  });

  // Pre-locate Head geometry so Hair scalp & new dreadlocks fit flush onto Head's skull
  let headGeoRef: THREE.BufferGeometry | null = null;
  riderScene.traverse((obj: any) => {
    if (!obj.isMesh || headGeoRef) return;
    const idName = `${obj.name || ''} ${obj.material?.name || ''}`;
    if (idName.includes('Head')) {
      headGeoRef = obj.geometry as THREE.BufferGeometry;
    }
  });

  // 4. Configure meshes, materials, per-vertex masks & custom PBR shaders
  const posVec = new THREE.Vector3();
  const handBoneIndices = new Set<number>();
  const torsoBoneIndices = new Set<number>();
  const neckHeadBoneIndices = new Set<number>();
  const limbBoneIndices = new Set<number>();

  riderScene.traverse((obj: any) => {
    if (!obj.isMesh) return;
    obj.castShadow = false;
    obj.receiveShadow = false;
    obj.frustumCulled = false;

    const meshName = obj.name || '';
    const matName = Array.isArray(obj.material)
      ? obj.material[0]?.name || ''
      : obj.material?.name || '';
    const idName = `${meshName} ${matName}`;

    const isHeadMesh = idName.includes('Head');
    const isHairMesh = idName.includes('Hair');
    const isBodyMesh = idName.includes('Body');

    if (isHairMesh) {
      firstPersonHeadMeshes.push(obj);
      if (helmetHiddenHairMeshes) helmetHiddenHairMeshes.push(obj);

      if (obj.isSkinnedMesh && obj.skeleton) {
        augmentExistingHairWithMoreStrands(
          obj.geometry as THREE.BufferGeometry,
          obj.skeleton.bones,
          obj.skeleton.boneInverses,
          headGeoRef
        );
      }

      obj.material = sharedHairMat;
      return;
    }

    if (isHeadMesh) {
      firstPersonHeadMeshes.push(obj);
      const hGeo = obj.geometry as THREE.BufferGeometry;
      const hPos = hGeo.attributes.position as THREE.BufferAttribute | undefined;
      const hUv = hGeo.attributes.uv as THREE.BufferAttribute | undefined;

      // Subtle lower-jaw & cheek slimming ("rostinho mais seco") without touching eyes or upper cranium
      if (hPos && hUv) {
        for (let i = 0; i < hPos.count; i++) {
          const u = hUv.getX(i);
          if (u > 0.78) continue; // preserve eyeballs, eyebrows, mouth interior exact fit
          const px = hPos.getX(i);
          const py = hPos.getY(i);
          if (py < 1.742 && py > 1.615) {
            const jawFactor = Math.sin(clamp01((py - 1.615) / 0.127) * Math.PI);
            hPos.setX(i, px * (1.0 - 0.075 * jawFactor));
          }
        }
        hPos.needsUpdate = true;
        hGeo.computeVertexNormals();
      }

      const hNorm = hGeo.attributes.normal as THREE.BufferAttribute | undefined;
      if (hPos) {
        const hCount = hPos.count;
        const hBindPos = new Float32Array(hCount * 3);
        const hTatCoord = new Float32Array(hCount * 4);
        const hTatMask = new Float32Array(hCount);
        const hNeckLow = new THREE.Vector3(0, 1.5896, -0.0482);
        const hNeckAxis = new THREE.Vector3(0, 0.1069, 0.0294).normalize();
        const hNeckUp = new THREE.Vector3(0, 0, -1).addScaledVector(hNeckAxis, hNeckAxis.z).normalize();
        const hNeckSide = new THREE.Vector3().crossVectors(hNeckAxis, hNeckUp).normalize();
        const hRel = new THREE.Vector3();

        for (let i = 0; i < hCount; i++) {
          const px = hPos.getX(i);
          const py = hPos.getY(i);
          const pz = hPos.getZ(i);
          hBindPos[i * 3] = px;
          hBindPos[i * 3 + 1] = py;
          hBindPos[i * 3 + 2] = pz;

          const nx = hNorm ? hNorm.getX(i) : 0;
          if (py > 1.54 && py < 1.685) {
            hRel.set(px, py, pz).sub(hNeckLow);
            const t = clamp01((py - 1.555) / 0.115);
            const sideMask = smoothstep(0.28, 0.62, Math.abs(nx)) * smoothstep(0.02, 0.04, Math.abs(px));
            const m = smoothstep(0.08, 0.28, t) * (1.0 - smoothstep(0.74, 0.94, t)) * sideMask;
            if (m > 0.01) {
              hTatCoord[i * 4] = hRel.dot(hNeckUp);
              hTatCoord[i * 4 + 1] = hRel.dot(hNeckSide);
              hTatCoord[i * 4 + 2] = 0.928 + t * 0.062;
              hTatCoord[i * 4 + 3] = 0.0;
              hTatMask[i] = m;
            }
          }
        }
        hGeo.setAttribute('aBindPos', new THREE.Float32BufferAttribute(hBindPos, 3));
        hGeo.setAttribute('aTattooCoord', new THREE.Float32BufferAttribute(hTatCoord, 4));
        hGeo.setAttribute('aTattooMask', new THREE.Float32BufferAttribute(hTatMask, 1));
      }

      const mat = new THREE.MeshStandardMaterial({
        map: headTex,
        color: 0xffffff,
        roughness: 0.48,
        metalness: 0.02,
        envMapIntensity: 0.92,
      });

      mat.customProgramCacheKey = () => 'custom_travis_head_tattoo_v4';
      mat.onBeforeCompile = (shader) => {
        shader.uniforms.uTattooMap = { value: tattooTex };
        shader.uniforms.uHairFadeMap = { value: dreadMaps.map };
        shader.uniforms.uSkinDetailMap = { value: skinDetailTex };
        shader.vertexShader = shader.vertexShader
          .replace(
            '#include <common>',
            `#include <common>
attribute vec3 aBindPos;
attribute vec4 aTattooCoord;
attribute float aTattooMask;
varying vec3 vBindPos;
varying vec2 vHeadUv;
varying vec4 vTattooCoord;
varying float vTattooMask;`
          )
          .replace(
            '#include <begin_vertex>',
            `#include <begin_vertex>
vBindPos = aBindPos;
vHeadUv = uv;
vTattooCoord = aTattooCoord;
vTattooMask = aTattooMask;`
          );
        shader.fragmentShader = shader.fragmentShader
          .replace(
            '#include <common>',
            `#include <common>
uniform sampler2D uTattooMap;
uniform sampler2D uHairFadeMap;
uniform sampler2D uSkinDetailMap;
varying vec3 vBindPos;
varying vec2 vHeadUv;
varying vec4 vTattooCoord;
varying float vTattooMask;`
          )
          .replace(
            '#include <map_fragment>',
            `#include <map_fragment>
// 1. Photorealistic 3D-aligned eyeballs (bind-pose centers (+-0.02935, 1.7432, 0.0718))
if (vHeadUv.x > 0.82 && vHeadUv.x < 0.962 && vHeadUv.y > 0.33 && vHeadUv.y < 0.56) {
  float ex = abs(vBindPos.x) - 0.02935;
  float ey = vBindPos.y - 1.7432;
  float r = length(vec2(ex, ey));

  // Warm moist sclera with soft corner pink caruncle & upper-eyelid ambient shadow
  vec3 scleraCol = vec3(0.84, 0.79, 0.75);
  float cornerPink = smoothstep(0.0068, 0.0112, abs(ex)) * (1.0 - smoothstep(0.002, 0.0055, abs(ey)));
  scleraCol = mix(scleraCol, vec3(0.68, 0.36, 0.34), cornerPink * 0.45);
  float perimAO = smoothstep(0.0055, 0.0118, r);
  scleraCol *= (1.0 - perimAO * 0.34);

  // Rich striated hazel/dark-brown human iris (radius 5.4mm) + dark limbal ring + 2.0mm pupil
  float ang = atan(ey, ex);
  float fiberA = sin(ang * 29.0 + r * 950.0) * 0.5 + 0.5;
  float fiberB = sin(ang * 53.0 - r * 420.0) * 0.5 + 0.5;
  float radialT = clamp((r - 0.0020) / 0.0034, 0.0, 1.0);

  vec3 innerAmber = vec3(0.18, 0.088, 0.042);
  vec3 midHazel = vec3(0.11, 0.052, 0.024);
  vec3 outerLimbus = vec3(0.028, 0.015, 0.009);
  vec3 irisCol = mix(innerAmber, midHazel, smoothstep(0.15, 0.72, radialT));
  irisCol *= (0.76 + 0.36 * fiberA + 0.16 * fiberB);
  irisCol = mix(irisCol, outerLimbus, smoothstep(0.72, 0.96, radialT));

  float irisMask = 1.0 - smoothstep(0.0051, 0.0056, r);
  float pupilMask = 1.0 - smoothstep(0.00185, 0.00215, r);

  vec3 eyeCol = mix(scleraCol, irisCol, irisMask);
  eyeCol = mix(eyeCol, vec3(0.008, 0.006, 0.006), pupilMask);

  // Upper eyelid shadow cast softly onto top of sclera & iris
  float lidShadow = smoothstep(0.0012, 0.0062, ey);
  eyeCol *= (1.0 - lidShadow * 0.46);

  // Crisp wet corneal catchlights (upper-left key + subtle lower-right bounce)
  float catchMain = 1.0 - smoothstep(0.00055, 0.00105, length(vec2(ex + 0.00135, ey - 0.00155)));
  float catchSub = 1.0 - smoothstep(0.00030, 0.00060, length(vec2(ex - 0.00145, ey + 0.00125)));
  eyeCol = mix(eyeCol, vec3(1.0, 0.98, 0.94), clamp(catchMain * 0.92 + catchSub * 0.45, 0.0, 1.0));

  diffuseColor.rgb = eyeCol;
} else if (vHeadUv.x >= 0.962 && vHeadUv.y > 0.40 && vHeadUv.y < 0.54) {
  // Warm mucosal tear-line rim along lower eyelid
  diffuseColor.rgb = vec3(0.28, 0.11, 0.09);
} else if (vHeadUv.x <= 0.78) {
  // 2. Exact 3D-aligned face skin, eyelid depth, nostrils, lips, goatee & hairline fade
  float ax = abs(vBindPos.x);
  float py = vBindPos.y;
  float pz = vBindPos.z;

  vec2 headPoreUv = vec2((vBindPos.x + vBindPos.z) * 26.0, py * 26.0);
  vec3 poreTex = texture2D(uSkinDetailMap, headPoreUv).rgb;
  diffuseColor.rgb *= mix(vec3(1.0), poreTex * 1.04, 0.42);

  // Natural cheek, nose-bridge & brow highlights for sculpted "rostinho"
  float noseBridge = exp(-pow(ax / 0.0080, 2.0)) * smoothstep(1.725, 1.748, py) * (1.0 - smoothstep(1.765, 1.785, py)) * smoothstep(0.078, 0.098, pz);
  float cheekGlow = exp(-pow((ax - 0.038) / 0.017, 2.0)) * exp(-pow((py - 1.725) / 0.015, 2.0)) * smoothstep(0.052, 0.080, pz);
  diffuseColor.rgb *= (1.0 + (noseBridge * 0.14 + cheekGlow * 0.10));

  // Nostril cavity shading (actual 3D nostril coordinates: |x|~0.011, y~1.720, z~0.095)
  float nostrilDark = exp(-pow((ax - 0.0105) / 0.0055, 2.0)) * exp(-pow((py - 1.720) / 0.0042, 2.0)) * smoothstep(0.085, 0.097, pz);
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.035, 0.016, 0.012), nostrilDark * 0.78);

  // Upper & lower eyelid crease + lash-line framing the eyeball socket
  float upperLid = exp(-pow((ax - 0.031) / 0.013, 2.0)) * exp(-pow((py - 1.751) / 0.0038, 2.0)) * smoothstep(0.072, 0.084, pz);
  float lowerLid = exp(-pow((ax - 0.031) / 0.013, 2.0)) * exp(-pow((py - 1.735) / 0.0032, 2.0)) * smoothstep(0.072, 0.084, pz);
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.045, 0.024, 0.018), clamp(upperLid * 0.62 + lowerLid * 0.34, 0.0, 0.75));

  // Exact 3D sculpted lips (lip_top=1.705, lip_mid=1.6964, lip_bot=1.691)
  float isLip = (1.0 - smoothstep(0.016, 0.024, ax)) * smoothstep(1.688, 1.693, py) * (1.0 - smoothstep(1.703, 1.708, py)) * smoothstep(0.088, 0.098, pz);
  float lipLine = exp(-pow((py - 1.6968) / 0.0018, 2.0)) * (1.0 - smoothstep(0.015, 0.022, ax)) * smoothstep(0.090, 0.100, pz);
  vec3 lipTone = mix(vec3(0.24, 0.095, 0.072), vec3(0.16, 0.065, 0.052), smoothstep(1.696, 1.703, py));
  diffuseColor.rgb = mix(diffuseColor.rgb, lipTone, isLip * 0.56);
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.05, 0.02, 0.018), lipLine * 0.65);

  // Clean-trimmed street "bigodinho + cavanhaque disfarçado" aligned to actual 3D mouth & chin
  float grain = fract(sin(dot(floor(vBindPos.xy * 650.0), vec2(12.9898, 78.233))) * 43758.5453);
  float mustache = (1.0 - smoothstep(0.020, 0.028, ax)) * smoothstep(1.706, 1.709, py) * (1.0 - smoothstep(1.714, 1.718, py)) * smoothstep(0.086, 0.097, pz);
  float goatee = (1.0 - smoothstep(0.015, 0.023, ax)) * smoothstep(1.658, 1.666, py) * (1.0 - smoothstep(1.684, 1.690, py)) * smoothstep(0.074, 0.088, pz);
  float jawStubble = smoothstep(0.028, 0.064, ax) * smoothstep(1.665, 1.682, py) * (1.0 - smoothstep(1.706, 1.726, py)) * smoothstep(0.018, 0.062, pz) * 0.22;
  float facialHair = clamp((mustache * 0.82 + goatee * 0.84 + jawStubble) * (0.65 + 0.35 * grain), 0.0, 0.88);
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.020, 0.014, 0.011), facialHair);

  // Barbershop scalp fade + crisp line-up ("pezinho") so zero bald skin ever shows under dreadlocks
  float hairlineY = 1.786 - 0.014 * pow(clamp(ax / 0.066, 0.0, 1.0), 2.0);
  float frontScalp = smoothstep(hairlineY - 0.004, hairlineY + 0.005, py);
  float templeCut = smoothstep(0.046, 0.066, ax) * smoothstep(1.732, 1.772, py) * (1.0 - smoothstep(0.028, 0.048, pz));
  float backNapeCut = (1.0 - smoothstep(-0.048, -0.010, pz)) * smoothstep(1.668, 1.715, py);
  float scalpHairMask = clamp(max(frontScalp, max(templeCut * 0.94, backNapeCut * 0.98)), 0.0, 1.0);
  if (scalpHairMask > 0.01) {
    vec2 fadeUv = vec2((vBindPos.x + pz) * 18.0, py * 18.0);
    vec3 hairCol = texture2D(uHairFadeMap, fadeUv).rgb * 0.82;
    diffuseColor.rgb = mix(diffuseColor.rgb, hairCol, scalpHairMask);
  }
}

// Neck side tattoo below jaw/nape fade
if (vTattooMask > 0.01) {
  float angle = atan(vTattooCoord.y, vTattooCoord.x);
  float tatU = fract(angle / 6.2831853 + vTattooCoord.w);
  float tatV = clamp(vTattooCoord.z, 0.0, 1.0);
  vec4 tatSample = texture2D(uTattooMap, vec2(tatU, 1.0 - tatV));
  float tatInk = tatSample.a * clamp(vTattooMask, 0.0, 1.0);
  vec3 inkedSkin = diffuseColor.rgb * vec3(0.24, 0.29, 0.35);
  diffuseColor.rgb = mix(diffuseColor.rgb, inkedSkin, tatInk * 0.84);
}`
          )
          .replace(
            '#include <roughnessmap_fragment>',
            `#include <roughnessmap_fragment>
if (vHeadUv.x > 0.82 && vHeadUv.x < 0.962 && vHeadUv.y > 0.33 && vHeadUv.y < 0.56) {
  roughnessFactor = 0.06;
} else if (vHeadUv.x >= 0.962 && vHeadUv.y > 0.40 && vHeadUv.y < 0.54) {
  roughnessFactor = 0.24;
}`
          );
      };

      obj.material = mat;
      return;
    }

    if (isBodyMesh && obj.isSkinnedMesh && obj.skeleton) {
      handBoneIndices.clear();
      torsoBoneIndices.clear();
      neckHeadBoneIndices.clear();
      limbBoneIndices.clear();

      obj.skeleton.bones.forEach((b: THREE.Bone, idx: number) => {
        const bn = b.name || '';
        const isNecklace = bn.includes('necklace');
        if (bn.includes('wrist') || bn.includes('finger') || bn.includes('metacarpal')) {
          handBoneIndices.add(idx);
        }
        if ((bn.includes('neck') && !isNecklace) || bn.includes('head')) {
          neckHeadBoneIndices.add(idx);
        }
        if (
          bn.startsWith('root_hips') ||
          bn.startsWith('root hips') ||
          bn.startsWith('spine') ||
          bn.includes('Spine3') ||
          bn.includes('neck') ||
          bn.includes('shoulder_2') ||
          bn.includes('shoulder 2') ||
          bn.includes('pectoralis') ||
          bn.includes('lattissimus') ||
          bn.includes('scapula')
        ) {
          torsoBoneIndices.add(idx);
        }
        if (
          bn.includes('shoulder_1') ||
          bn.includes('shoulder 1') ||
          bn.includes('elbow') ||
          bn.includes('wrist') ||
          bn.includes('finger') ||
          bn.includes('metacarpal') ||
          bn.includes('upperarm') ||
          bn.includes('lowerarm') ||
          bn.includes('bicep') ||
          bn.includes('tricep') ||
          bn.startsWith('leg_') ||
          bn.startsWith('leg ') ||
          bn.includes('thigh') ||
          bn.includes('calf') ||
          bn.includes('legdangle')
        ) {
          limbBoneIndices.add(idx);
        }
      });

      const geo = obj.geometry as THREE.BufferGeometry;
      const posAttr = geo.attributes.position as THREE.BufferAttribute | undefined;
      const normAttr = geo.attributes.normal as THREE.BufferAttribute | undefined;
      const uvAttr = geo.attributes.uv as THREE.BufferAttribute | undefined;
      const skinIdxAttr = geo.attributes.skinIndex as THREE.BufferAttribute | undefined;
      const skinWtAttr = geo.attributes.skinWeight as THREE.BufferAttribute | undefined;

      // Strip the detached 3D ring triangles around left middle (3a) & pinky (5a) fingers
      // (`domName.includes('finger')` and isolated ring UV island u < 0.25, v > 0.82)
      if (geo.index && uvAttr && skinIdxAttr && skinWtAttr) {
        const isRingVertex = new Uint8Array(uvAttr.count);
        for (let i = 0; i < uvAttr.count; i++) {
          let maxW = -1;
          let domName = '';
          for (let k = 0; k < 4; k++) {
            const wt = skinWtAttr.getComponent(i, k);
            if (wt > maxW) {
              maxW = wt;
              domName = obj.skeleton.bones[skinIdxAttr.getComponent(i, k)]?.name || '';
            }
          }
          if (domName.includes('finger')) {
            const u = uvAttr.getX(i);
            const v = uvAttr.getY(i);
            if (u < 0.25 && v > 0.82) {
              isRingVertex[i] = 1;
            }
          }
        }
        const oldIdx = geo.index.array;
        const kept: number[] = [];
        let strippedTris = 0;
        for (let t = 0; t < oldIdx.length; t += 3) {
          const ia = oldIdx[t];
          const ib = oldIdx[t + 1];
          const ic = oldIdx[t + 2];
          if (isRingVertex[ia] && isRingVertex[ib] && isRingVertex[ic]) {
            strippedTris++;
            continue;
          }
          kept.push(ia, ib, ic);
        }
        if (strippedTris > 0) {
          geo.setIndex(kept);
        }
      }

      // Slim down torso, waist, arms, and thighs for a leaner street silhouette ("mais seco")
      slimCustomRiderBodyGeometry(geo, obj.skeleton.bones);

      if (posAttr && skinIdxAttr && skinWtAttr) {
        const count = posAttr.count;
        const gloveData = new Float32Array(count * 4);
        const torsoMask = new Float32Array(count * 2);
        const bodyZone = new Float32Array(count * 4); // x: shirt, y: pants, z: shoes, w: bare arm/hand/neck skin
        const bindPos = new Float32Array(count * 3);
        const bindNorm = new Float32Array(count * 3);
        const tattooCoord = new Float32Array(count * 4); // x: radX, y: radY, z: axialV, w: uOffset
        const tattooMask = new Float32Array(count);

        // Hand direction unit vectors in bind A-pose (wrist -> fingertips)
        const dirL = new THREE.Vector3(0.44, -0.90, 0.14).normalize();
        const dirR = new THREE.Vector3(-0.44, -0.90, 0.14).normalize();
        const wristL = new THREE.Vector3(0.58, 1.146, 0.046);
        const wristR = new THREE.Vector3(-0.58, 1.146, 0.046);
        const shoulderL = new THREE.Vector3(0.1984, 1.5003, -0.0541);
        const shoulderR = new THREE.Vector3(-0.1984, 1.5003, -0.0541);
        const elbowL = new THREE.Vector3(0.4205, 1.3028, -0.0646);
        const elbowR = new THREE.Vector3(-0.4205, 1.3028, -0.0646);
        const neckLow = new THREE.Vector3(0, 1.5896, -0.0482);
        const neckAxis = new THREE.Vector3(0, 0.1069, 0.0294).normalize();

        // Build clean orthonormal cylindrical frames per limb so atan2(radY, radX) maps
        // u=0.5 cleanly onto the dorsal/lateral face of upper arms, forearms, and back of hands.
        const makeCylFrame = (start: THREE.Vector3, end: THREE.Vector3, dorsalHint: THREE.Vector3) => {
          const axis = end.clone().sub(start);
          const len = axis.length();
          axis.normalize();
          const up = dorsalHint.clone().addScaledVector(axis, -dorsalHint.dot(axis)).normalize();
          const side = new THREE.Vector3().crossVectors(axis, up).normalize();
          return { start, axis, len, up, side };
        };

        const frameUpperL = makeCylFrame(shoulderL, elbowL, new THREE.Vector3(0.75, 0.65, 0.05));
        const frameUpperR = makeCylFrame(shoulderR, elbowR, new THREE.Vector3(-0.75, 0.65, 0.05));
        const frameForeL = makeCylFrame(elbowL, wristL, new THREE.Vector3(0.68, 0.72, 0.08));
        const frameForeR = makeCylFrame(elbowR, wristR, new THREE.Vector3(-0.68, 0.72, 0.08));
        const frameHandL = makeCylFrame(wristL, wristL.clone().add(dirL), new THREE.Vector3(0.72, 0.62, 0.25));
        const frameHandR = makeCylFrame(wristR, wristR.clone().add(dirR), new THREE.Vector3(-0.72, 0.62, 0.25));
        const neckUp = new THREE.Vector3(0, 0, -1).addScaledVector(neckAxis, neckAxis.z).normalize();
        const neckSide = new THREE.Vector3().crossVectors(neckAxis, neckUp).normalize();

        const rel = new THREE.Vector3();

        for (let i = 0; i < count; i++) {
          let handWeight = 0;
          let tWeight = 0;
          let nhWeight = 0;
          let lWeight = 0;
          let maxW = -1;
          let domName = '';

          for (let k = 0; k < 4; k++) {
            const bIdx = skinIdxAttr.getComponent(i, k);
            const wt = skinWtAttr.getComponent(i, k);
            if (wt > maxW) {
              maxW = wt;
              domName = obj.skeleton.bones[bIdx]?.name || '';
            }
            if (handBoneIndices.has(bIdx)) handWeight += wt;
            if (torsoBoneIndices.has(bIdx)) tWeight += wt;
            if (neckHeadBoneIndices.has(bIdx)) nhWeight += wt;
            if (limbBoneIndices.has(bIdx)) lWeight += wt;
          }

          posVec.fromBufferAttribute(posAttr, i);
          bindPos[i * 3] = posVec.x;
          bindPos[i * 3 + 1] = posVec.y;
          bindPos[i * 3 + 2] = posVec.z;

          const nx = normAttr ? normAttr.getX(i) : 0;
          const ny = normAttr ? normAttr.getY(i) : 0;
          const nz = normAttr ? normAttr.getZ(i) : 1;
          bindNorm[i * 3] = nx;
          bindNorm[i * 3 + 1] = ny;
          bindNorm[i * 3 + 2] = nz;

          // First-person visibility rule (both mounted & on-foot):
          // Hide 100% of head, neck, necklace/chain/cross, chest, torso, hips/waist, shoulders, and short sleeves,
          // keeping ONLY non-obstructing distal forearms/wrists/hands (|x| >= 0.385, y <= 1.35)
          // and lower legs/knees/calves/sneakers (y < 0.72 mounted, y < 0.64 on-foot).
          const isTorsoDominant =
            domName.startsWith('root_hips') ||
            domName.startsWith('root hips') ||
            domName.startsWith('spine') ||
            domName.includes('Spine3') ||
            domName.includes('shoulder_2') ||
            domName.includes('shoulder 2') ||
            domName.includes('pectoralis') ||
            domName.includes('lattissimus') ||
            domName.includes('scapula') ||
            domName.includes('necklace') ||
            domName.includes('neck') ||
            domName.includes('head');
          const isCleanForearmOrHand =
            !isTorsoDominant &&
            Math.abs(posVec.x) >= 0.385 &&
            posVec.y <= 1.35 &&
            (lWeight >= 0.45 || handWeight > 0.15);
          const isMountedLowerLeg = !isTorsoDominant && tWeight < 0.35 && posVec.y < 0.70;
          const isOnFootLowerLeg = !isTorsoDominant && tWeight < 0.35 && posVec.y < 0.62;

          if (!isCleanForearmOrHand && !isMountedLowerLeg) {
            torsoMask[i * 2] = 1.0;
          }
          if (!isCleanForearmOrHand && !isOnFootLowerLeg) {
            torsoMask[i * 2 + 1] = 1.0;
          }

          // Glove UV & mask on hands
          const isLeft = posVec.x >= 0;
          const signX = isLeft ? 1 : -1;
          let alongHand = 0;
          const isDorsal = smoothstep(-0.15, 0.35, signX * nx);
          if (handWeight > 0.25) {
            rel.copy(posVec).sub(isLeft ? wristL : wristR);
            alongHand = clamp01(rel.dot(isLeft ? dirL : dirR) / 0.165);
            const gMask = smoothstep(0.28, 0.72, handWeight);
            const gU = alongHand * 1.4;
            const gV = (posVec.z - 0.02) * 8.0;
            let gZone = 0.0;
            if (handWeight < 0.68 || alongHand < 0.18) {
              gZone = 0.35; // Wrist cuff
            } else if (alongHand >= 0.32 && alongHand <= 0.56 && isDorsal > 0.45) {
              gZone = 0.85; // Carbon knuckle armor
            }
            gloveData[i * 4] = gMask;
            gloveData[i * 4 + 1] = gU;
            gloveData[i * 4 + 2] = gV;
            gloveData[i * 4 + 3] = gZone;
          }

          // Region classification for shoes & bare skin micro-pore detail
          const isFinger = domName.includes('finger');
          const isHandOrForearm =
            domName.includes('wrist') ||
            isFinger ||
            domName.includes('metacarpal') ||
            domName.includes('elbow') ||
            domName.includes('lowerarm');
          const isLowerUpperArmSkin =
            (domName.includes('shoulder_1') ||
              domName.includes('shoulder 1') ||
              domName.includes('upperarm') ||
              domName.includes('bicep') ||
              domName.includes('tricep')) &&
            posVec.y < 1.375;
          const isNeckUpper = domName.includes('neck') && !domName.includes('necklace') && posVec.y > 1.50;
          const isShoe = !isHandOrForearm && (posVec.y < 0.145 || domName.includes('ankle') || domName.includes('toe'));
          const isSkinSurface = isHandOrForearm || isLowerUpperArmSkin || isNeckUpper;

          bodyZone[i * 4] = 0.0;
          bodyZone[i * 4 + 1] = 0.0;
          bodyZone[i * 4 + 2] = isShoe ? 1.0 : 0.0;
          bodyZone[i * 4 + 3] = isSkinSurface ? 1.0 : 0.0;

          // Cylindrical tattoo coordinates & mask (never applied onto fingers so no ring illusion ever forms!)
          if (isSkinSurface && !isFinger) {
            if (isLowerUpperArmSkin) {
              const f = isLeft ? frameUpperL : frameUpperR;
              rel.copy(posVec).sub(f.start);
              const t = clamp01(rel.dot(f.axis) / f.len);
              // Fade in cleanly right below the t-shirt sleeve edge (t >= 0.48)
              const tMask = smoothstep(0.46, 0.56, t) * (1.0 - smoothstep(0.95, 1.0, t));
              if (tMask > 0.01) {
                const normT = clamp01((t - 0.48) / 0.50);
                tattooCoord[i * 4] = rel.dot(f.up);
                tattooCoord[i * 4 + 1] = rel.dot(f.side) * signX;
                tattooCoord[i * 4 + 2] = 0.06 + normT * 0.31;
                tattooCoord[i * 4 + 3] = isLeft ? 0.5 : 0.85;
                tattooMask[i] = tMask;
              }
            } else if (domName.includes('elbow') || domName.includes('lowerarm')) {
              const f = isLeft ? frameForeL : frameForeR;
              rel.copy(posVec).sub(f.start);
              const t = clamp01(rel.dot(f.axis) / f.len);
              const tMask = smoothstep(0.03, 0.12, t);
              tattooCoord[i * 4] = rel.dot(f.up);
              tattooCoord[i * 4 + 1] = rel.dot(f.side) * signX;
              tattooCoord[i * 4 + 2] = 0.41 + t * 0.42;
              tattooCoord[i * 4 + 3] = isLeft ? 0.5 : 0.88;
              tattooMask[i] = tMask;
            } else if (domName.includes('wrist') || domName.includes('metacarpal')) {
              if (alongHand < 0.14) {
                const f = isLeft ? frameForeL : frameForeR;
                rel.copy(posVec).sub(f.start);
                const t = clamp01(rel.dot(f.axis) / f.len);
                tattooCoord[i * 4] = rel.dot(f.up);
                tattooCoord[i * 4 + 1] = rel.dot(f.side) * signX;
                tattooCoord[i * 4 + 2] = 0.41 + t * 0.42;
                tattooCoord[i * 4 + 3] = isLeft ? 0.5 : 0.88;
                tattooMask[i] = 1.0 - smoothstep(0.08, 0.14, alongHand);
              } else if (alongHand >= 0.14 && alongHand <= 0.39) {
                // Subtle back-of-hand dorsal motif, strictly stopping before knuckles & fingers
                const f = isLeft ? frameHandL : frameHandR;
                rel.copy(posVec).sub(f.start);
                const handT = clamp01((alongHand - 0.14) / 0.24);
                const tMask =
                  smoothstep(0.14, 0.20, alongHand) *
                  (1.0 - smoothstep(0.32, 0.39, alongHand)) *
                  smoothstep(0.10, 0.55, isDorsal);
                tattooCoord[i * 4] = rel.dot(f.up);
                tattooCoord[i * 4 + 1] = rel.dot(f.side) * signX;
                tattooCoord[i * 4 + 2] = 0.852 + handT * 0.056;
                tattooCoord[i * 4 + 3] = 0.5;
                tattooMask[i] = tMask;
              }
            } else if (isNeckUpper) {
              rel.copy(posVec).sub(neckLow);
              const t = clamp01(rel.dot(neckAxis) / 0.11);
              const sideNeck = smoothstep(0.28, 0.65, Math.abs(nx));
              const tMask =
                smoothstep(0.08, 0.25, t) * (1.0 - smoothstep(0.75, 0.94, t)) * sideNeck;
              tattooCoord[i * 4] = rel.dot(neckUp);
              tattooCoord[i * 4 + 1] = rel.dot(neckSide);
              tattooCoord[i * 4 + 2] = 0.925 + t * 0.065;
              tattooCoord[i * 4 + 3] = 0.0;
              tattooMask[i] = tMask;
            }
          }
        }

        geo.setAttribute('aTorsoMask', new THREE.Float32BufferAttribute(torsoMask, 2));
        geo.setAttribute('aGloveData', new THREE.Float32BufferAttribute(gloveData, 4));
        geo.setAttribute('aBodyZone', new THREE.Float32BufferAttribute(bodyZone, 4));
        geo.setAttribute('aBindPos', new THREE.Float32BufferAttribute(bindPos, 3));
        geo.setAttribute('aBindNorm', new THREE.Float32BufferAttribute(bindNorm, 3));
        geo.setAttribute('aTattooCoord', new THREE.Float32BufferAttribute(tattooCoord, 4));
        geo.setAttribute('aTattooMask', new THREE.Float32BufferAttribute(tattooMask, 1));
      }

      const bodyMat = new THREE.MeshStandardMaterial({
        map: bodyTex,
        color: 0xffffff,
        roughness: 0.64,
        metalness: 0.03,
        envMapIntensity: 0.88,
      });
      bodyMat.customProgramCacheKey = () => 'custom_travis_rider_v4';
      bodyMat.onBeforeCompile = (shader) => {
        shader.uniforms.uHideTorso = hideTorsoUniform;
        shader.uniforms.uGloveEnabled = gloveUniforms.uGloveEnabled;
        shader.uniforms.uGlovePrimary = gloveUniforms.uGlovePrimary;
        shader.uniforms.uGloveAccent = gloveUniforms.uGloveAccent;
        shader.uniforms.uGloveMap = gloveUniforms.uGloveMap;
        shader.uniforms.uCarbonMap = gloveUniforms.uCarbonMap;
        shader.uniforms.uShoeMode = outfitUniforms.uShoeMode;
        shader.uniforms.uSkinBaseColor = gloveUniforms.uSkinBaseColor ?? { value: skinLinearColor };
        shader.uniforms.uSkinDetailMap = { value: skinDetailTex };
        shader.uniforms.uTattooMap = { value: tattooTex };

        shader.vertexShader = shader.vertexShader
          .replace(
            '#include <common>',
            `#include <common>
attribute vec2 aTorsoMask;
attribute vec4 aGloveData;
attribute vec4 aBodyZone;
attribute vec3 aBindPos;
attribute vec3 aBindNorm;
attribute vec4 aTattooCoord;
attribute float aTattooMask;
varying vec2 vTorsoMask;
varying vec4 vGloveData;
varying vec4 vBodyZone;
varying vec3 vBindPos;
varying vec3 vBindNorm;
varying vec4 vTattooCoord;
varying float vTattooMask;`
          )
          .replace(
            '#include <begin_vertex>',
            `#include <begin_vertex>
vTorsoMask = aTorsoMask;
vGloveData = aGloveData;
vBodyZone = aBodyZone;
vBindPos = aBindPos;
vBindNorm = aBindNorm;
vTattooCoord = aTattooCoord;
vTattooMask = aTattooMask;`
          );

        shader.fragmentShader = shader.fragmentShader
          .replace(
            '#include <common>',
            `#include <common>
uniform float uHideTorso;
uniform float uGloveEnabled;
uniform vec3 uGlovePrimary;
uniform vec3 uGloveAccent;
uniform sampler2D uGloveMap;
uniform sampler2D uCarbonMap;
uniform float uShoeMode;
uniform vec3 uSkinBaseColor;
uniform sampler2D uSkinDetailMap;
uniform sampler2D uTattooMap;
varying vec2 vTorsoMask;
varying vec4 vGloveData;
varying vec4 vBodyZone;
varying vec3 vBindPos;
varying vec3 vBindNorm;
varying vec4 vTattooCoord;
varying float vTattooMask;`
          )
          .replace(
            '#include <map_fragment>',
            `#include <map_fragment>
if ((uHideTorso > 0.5 && uHideTorso < 1.5 && vTorsoMask.x > 0.25) || (uHideTorso >= 1.5 && vTorsoMask.y > 0.25)) discard;

// High-detail skin pore & dermal subsurface shading on exposed arms/hands/neck
float skinMask = vBodyZone.w;

// Micro-pore skin modulation on arms & bare hands (uniform natural tone without knuckle ring tint)
if (skinMask > 0.15 && (uGloveEnabled <= 0.5 || vGloveData.x < 0.5)) {
  vec2 skinDetUv = vec2(vBindPos.x * 22.0 + vBindPos.z * 22.0, vBindPos.y * 22.0);
  vec3 poreSample = texture2D(uSkinDetailMap, skinDetUv).rgb;
  diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * mix(vec3(1.0), poreSample * 1.07, 0.72), skinMask);

  // Subdermal black-and-grey tattoos on forearms, upper arms, back-of-hand & neck
  if (vTattooMask > 0.01) {
    float angle = atan(vTattooCoord.y, vTattooCoord.x);
    float tatU = fract(angle / 6.2831853 + vTattooCoord.w);
    float tatV = clamp(vTattooCoord.z, 0.0, 1.0);
    vec4 tatSample = texture2D(uTattooMap, vec2(tatU, 1.0 - tatV));
    float tatInk = tatSample.a * clamp(vTattooMask, 0.0, 1.0);
    vec3 inkedSkin = diffuseColor.rgb * vec3(0.24, 0.29, 0.35);
    diffuseColor.rgb = mix(diffuseColor.rgb, inkedSkin, tatInk * 0.86);
  }
}

// Optional monochrome classic sneaker swap ("Original" shoe option)
if (vBodyZone.z > 0.5 && uShoeMode > 0.5) {
  float luma = dot(diffuseColor.rgb, vec3(0.299, 0.587, 0.114));
  vec3 monoCol = vec3(clamp(luma * 1.15, 0.03, 0.85));
  diffuseColor.rgb = mix(diffuseColor.rgb, monoCol, smoothstep(0.45, 0.85, vBodyZone.z));
}

// Tactical riding gloves overlay on hands
if (uGloveEnabled > 0.5 && vGloveData.x > 0.01) {
  float gMask = smoothstep(0.05, 0.95, vGloveData.x);
  vec2 gUv = vec2(vGloveData.y * 1.45, vGloveData.z * 0.55 + 0.5);
  vec3 rawG = texture2D(uGloveMap, gUv).rgb;
  vec3 aiTex = rawG * rawG;
  vec3 rawC = texture2D(uCarbonMap, gUv * 2.5).rgb;
  vec3 carbTex = rawC * rawC;

  float isCuff = smoothstep(0.15, 0.45, vGloveData.w) * (1.0 - smoothstep(0.55, 0.75, vGloveData.w));
  float isKnuckle = smoothstep(0.65, 0.92, vGloveData.w);

  vec3 leatherColor = aiTex * uGlovePrimary * 1.68;
  vec3 cuffColor = aiTex * uGloveAccent * 1.50;
  vec3 knuckleColor = mix(carbTex * 0.75, uGloveAccent * 0.45, 0.22);

  vec3 gloveCol = mix(leatherColor, cuffColor, isCuff);
  gloveCol = mix(gloveCol, knuckleColor, isKnuckle);
  diffuseColor.rgb = mix(diffuseColor.rgb, gloveCol, gMask);
}`
          )
          .replace(
            '#include <roughnessmap_fragment>',
            `#include <roughnessmap_fragment>
if (uGloveEnabled > 0.5 && vGloveData.x > 0.01) {
  roughnessFactor = mix(roughnessFactor, 0.44, vGloveData.x);
} else if (vBodyZone.w > 0.5) {
  roughnessFactor = mix(roughnessFactor, 0.54, 0.85);
}`
          );
      };

      obj.material = bodyMat;
    }
  });

  riderScene.updateMatrixWorld(true);
  const headBone = bones.get('Head_') ?? null;

  // Register all 13 dyn_braid_* physics bone chains so braids swing, bounce, and trail in the wind
  if (hairChains && headBone) {
    const chainRoots: THREE.Bone[] = [];
    for (const child of headBone.children) {
      if ((child as THREE.Bone).isBone && child.name.includes('dyn_braid_')) {
        chainRoots.push(child as THREE.Bone);
      }
    }

    const worldPitchAxis = new THREE.Vector3(1, 0, 0);
    const worldRollAxis = new THREE.Vector3(0, 0, 1);
    const segWeights = [0.46, 0.82, 1.05, 1.25];

    chainRoots.forEach((rootB, cIdx) => {
      const segments: CustomHairSegment[] = [];
      let cur: THREE.Bone | undefined = rootB;
      let segIdx = 0;
      while (cur && !cur.name.includes('_end_') && segIdx < 4) {
        const bWorldQ = cur.getWorldQuaternion(new THREE.Quaternion());
        const invBWorldQ = bWorldQ.clone().invert();
        segments.push({
          bone: cur,
          restLocal: cur.quaternion.clone(),
          pitchAxisLocal: worldPitchAxis.clone().applyQuaternion(invBWorldQ).normalize(),
          rollAxisLocal: worldRollAxis.clone().applyQuaternion(invBWorldQ).normalize(),
          segWeight: segWeights[segIdx] ?? 1.0,
        });
        cur = cur.children.find(
          (c): c is THREE.Bone =>
            (c as THREE.Bone).isBone && c.name.includes('dyn_braid_') && !c.name.includes('_end_')
        );
        segIdx++;
      }

      if (segments.length > 0) {
        const isFront = rootB.name.includes('_fr_');
        hairChains.push({
          segments,
          pitch: 0,
          pitchVel: 0,
          roll: 0,
          rollVel: 0,
          phaseOffset: cIdx * 0.73,
          stiffness: isFront ? 58 : 44 + (cIdx % 3) * 5,
          damping: isFront ? 7.8 : 6.4,
          isFront,
        });
      }
    });
  }

  return {
    hipsBone: bones.get('Hips') ?? null,
    spine2Bone: bones.get('Spine2_') ?? null,
    neckBone: bones.get('Neck_') ?? null,
    headBone,
  };
}

/**
 * Extracts and bakes the detachable motorcycle helmet (`Wolf3D_Headwear`) from `bike_rider.glb`
 * aligned cleanly to `travis_scott.glb`'s head bone coordinate space (`head neck upper_081`),
 * with a subtle fit scale & backward shift so no hair or ears ever clip through the shell.
 */
export function extractHelmetForCustomRider(
  helmetSourceScene: THREE.Group,
  headBone: THREE.Bone | null,
  qOffHead?: CustomRiderBoneEntry
): THREE.Mesh | null {
  let helmetMesh: THREE.Mesh | null = null;
  let rpmHeadBone: THREE.Bone | null = null;

  helmetSourceScene.updateMatrixWorld(true);
  helmetSourceScene.traverse((obj: any) => {
    if (obj.isBone && !rpmHeadBone && obj.name?.startsWith('Head_')) {
      rpmHeadBone = obj as THREE.Bone;
    }
  });

  helmetSourceScene.traverse((obj: any) => {
    if (!obj.isMesh || helmetMesh) return;
    const matName = Array.isArray(obj.material)
      ? obj.material[0]?.name || ''
      : obj.material?.name || '';
    if (!matName.includes('Wolf3D_Headwear')) return;

    const helmetGeo = (obj.geometry as THREE.BufferGeometry).clone();
    if (obj.isSkinnedMesh && obj.skeleton && rpmHeadBone) {
      const headIdx = obj.skeleton.bones.indexOf(rpmHeadBone);
      const bakeMat = new THREE.Matrix4();
      if (headIdx >= 0 && obj.skeleton.boneInverses[headIdx]) {
        bakeMat.multiplyMatrices(obj.skeleton.boneInverses[headIdx], obj.bindMatrix);
      }
      helmetGeo.applyMatrix4(bakeMat);
    }

    // Shift and scale slightly to wrap travis_scott.glb's cranial dome & braids cleanly:
    // TS head neck upper_081 is ~0.058m higher and ~0.026m further back than RPM Head_.
    helmetGeo.translate(0, -0.052, -0.004);
    helmetGeo.scale(1.05, 1.03, 1.05);
    helmetGeo.computeBoundingBox();
    helmetGeo.computeBoundingSphere();

    // Verify qOffHead exists (headBone is referenced in updateHelmet via RPM frame)
    void headBone;
    void qOffHead;

    const srcMat = Array.isArray(obj.material) ? obj.material[0] : obj.material;
    const helmetMat = (
      srcMat ? srcMat.clone() : new THREE.MeshStandardMaterial({ color: 0x18181b })
    ) as THREE.MeshStandardMaterial;
    helmetMat.side = THREE.DoubleSide;
    helmetMat.envMapIntensity = 1.05;

    helmetMesh = new THREE.Mesh(helmetGeo, helmetMat);
    helmetMesh.name = 'Rider_Detachable_Helmet';
    helmetMesh.castShadow = false;
    helmetMesh.receiveShadow = false;
    helmetMesh.frustumCulled = false;
  });

  return helmetMesh;
}

export function syncCustomOutfitUniforms(
  uniforms: CustomRiderOutfitUniforms,
  shoeStyle: RiderShoeStyle
): void {
  uniforms.uShoeMode.value = shoeStyle === 'street_sneaker' ? 0.0 : 1.0;
}
