import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { PlanarGroundReflector, installGroundPlanarReflectionShader } from './PlanarGroundReflector';
import { ProceduralTextureSet } from './ProceduralTextures';
import {
  GroundHit,
  LOMBADAS,
  PLAZA_RECT,
  RoadTerrain,
  STREETS,
  STUNT_RAMPS,
  StreetSegment,
} from './RoadTerrain';
import { GraphicsQuality } from './types';

interface Particle {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  maxAge: number;
  size: number;
  kind: 'smoke' | 'spark';
}

export class FavelaWorld {
  public readonly group = new THREE.Group();
  public readonly groundGroup = new THREE.Group();
  public readonly sunLight: THREE.DirectionalLight;
  private readonly skyDome: THREE.Mesh;
  public readonly reflector: PlanarGroundReflector;

  private readonly smokeMesh: THREE.InstancedMesh;
  private readonly sparkMesh: THREE.InstancedMesh;
  private readonly particles: Particle[] = [];
  private readonly maxSmoke = 120;
  private readonly maxSparks = 90;
  private smokeDirty = false;
  private sparkDirty = false;
  private readonly dummy = new THREE.Object3D();
  private readonly tmpColor = new THREE.Color();
  private readonly _reflPoint = new THREE.Vector3();
  private readonly _reflNormal = new THREE.Vector3(0, 1, 0);
  private _lastReflFx = NaN;
  private _lastReflFz = NaN;
  private readonly reflectionHiddenMeshes: THREE.Object3D[] = [];
  private readonly prevReflVis: boolean[] = [];

  private readonly disposables: Array<{ dispose: () => void }> = [];
  private readonly terrain: RoadTerrain;
  private readonly _groundHit: GroundHit = { height: 0, nx: 0, ny: 1, nz: 0, surface: 'asphalt' };

  // Map-wide Reflection Materials & Props
  public reflectionsEnabled = true;
  public realGroundReflectionsEnabled = true;
  private asphaltMat!: THREE.MeshStandardMaterial;
  private walkMat!: THREE.MeshStandardMaterial;
  private plazaMat!: THREE.MeshStandardMaterial;
  private courtMat!: THREE.MeshStandardMaterial;
  private bumpMat!: THREE.MeshStandardMaterial;
  private rampMat!: THREE.MeshStandardMaterial;
  private terrainMat!: THREE.MeshStandardMaterial;
  private readonly sceneRef: THREE.Scene;
  private readonly asphaltUniforms = {
    uReflectionsEnabled: { value: 1.0 },
  };

  constructor(
    scene: THREE.Scene,
    terrain: RoadTerrain,
    textures: ProceduralTextureSet,
    isSoftwareGl: boolean
  ) {
    this.sceneRef = scene;
    this.terrain = terrain;
    this.reflector = new PlanarGroundReflector(isSoftwareGl);
    this.group.add(this.groundGroup);
    // 1. Photorealistic AI-Generated Brazilian Golden-Hour Sky Dome & Fog
    const fogColor = new THREE.Color(0xd9b89c);
    scene.background = fogColor;
    scene.fog = new THREE.FogExp2(0xd9b89c, 0.0014);

    const skyGeo = new THREE.SphereGeometry(360, 40, 28);
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        skyMap: { value: textures.skyMap },
        fogColor: { value: new THREE.Color(0xd9b89c) },
        zenithColor: { value: new THREE.Color(0x1b5290) },
        sunDir: { value: new THREE.Vector3(0.6, 0.32, -0.72).normalize() },
      },
      vertexShader: `
        varying vec3 vLocalDir;
        void main() {
          vLocalDir = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform sampler2D skyMap;
        uniform vec3 fogColor;
        uniform vec3 zenithColor;
        uniform vec3 sunDir;
        varying vec3 vLocalDir;
        void main() {
          vec3 dir = normalize(vLocalDir);
          float sunAz = atan(sunDir.z, sunDir.x);
          float az = atan(dir.z, dir.x) - sunAz;
          // Mirrored horizontal wrap keeps 360-degree panorama 100% seamless
          float u = (az / 3.14159265) + 0.59;
          float h = clamp(dir.y, 0.0, 1.0);
          float v = clamp(0.14 + pow(h, 0.72) * 0.84, 0.02, 0.98);
          vec3 sky = texture2D(skyMap, vec2(u, v)).rgb;
          // Smooth zenith & horizon fog integration
          sky = mix(sky, zenithColor, smoothstep(0.74, 1.0, h) * 0.45);
          sky = mix(fogColor, sky, smoothstep(-0.02, 0.14, dir.y));
          float sunDot = max(dot(dir, sunDir), 0.0);
          sky += vec3(1.0, 0.88, 0.72) * pow(sunDot, 22.0) * 0.28;
          sky += vec3(1.0, 0.96, 0.86) * smoothstep(0.9965, 0.9996, sunDot) * 0.95;
          gl_FragColor = vec4(sky, 1.0);
        }
      `,
    });
    this.skyDome = new THREE.Mesh(skyGeo, skyMat);
    this.skyDome.renderOrder = -100;
    this.skyDome.frustumCulled = false;
    this.group.add(this.skyDome);
    this.disposables.push(skyGeo, skyMat);

    // 2. Fast Shadow-Free Warm/Cool Outdoor Lighting
    const hemiLight = new THREE.HemisphereLight(0x9bc4e8, 0x6b4f3a, 0.92);
    this.group.add(hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff0d6, 2.2);
    this.sunLight.position.set(80, 95, -90);
    this.sunLight.castShadow = false;
    this.group.add(this.sunLight);

    // 3. Open-World Terrain Mesh + Street Network + Plaza / Quadra + Ramps
    this.buildTerrain(terrain, textures);
    this.buildStreets(terrain, textures);
    this.buildPlazaAndRamps(textures);

    // 4. Open-World Street Props
    this.buildStreetProps(terrain, textures);

    // 5. Instanced Smoke & Spark Particles
    const smokeGeo = new THREE.PlaneGeometry(1, 1);
    const smokeMat = new THREE.MeshBasicMaterial({
      map: textures.particleGlow,
      transparent: true,
      depthWrite: false,
      opacity: 0.45,
      color: 0xd9dce0,
    });
    this.smokeMesh = new THREE.InstancedMesh(smokeGeo, smokeMat, this.maxSmoke);
    this.smokeMesh.frustumCulled = false;
    this.smokeMesh.visible = false;
    this.smokeMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.group.add(this.smokeMesh);
    this.disposables.push(smokeGeo, smokeMat);

    const sparkGeo = new THREE.BoxGeometry(0.03, 0.03, 0.24);
    const sparkMat = new THREE.MeshBasicMaterial({ color: 0xffb347 });
    this.sparkMesh = new THREE.InstancedMesh(sparkGeo, sparkMat, this.maxSparks);
    this.sparkMesh.frustumCulled = false;
    this.sparkMesh.visible = false;
    this.sparkMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.group.add(this.sparkMesh);
    this.disposables.push(sparkGeo, sparkMat);

    for (let i = 0; i < this.maxSmoke; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: -999,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        age: 0,
        maxAge: 1,
        size: 0.5,
        kind: 'smoke',
      });
    }
    for (let i = 0; i < this.maxSparks; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: -999,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        age: 0,
        maxAge: 0.4,
        size: 1,
        kind: 'spark',
      });
    }

    scene.add(this.group);
  }

  private buildTerrain(terrain: RoadTerrain, _textures: ProceduralTextureSet): void {
    const size = 1500;
    const segs = 84;
    const geo = new THREE.PlaneGeometry(size, size, segs, segs);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes.position as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const y = terrain.baseTerrainHeight(x, z) - 0.08;
      pos.setY(i, y);

      const inBlock = terrain.isPointInBlock(x, z, 0);
      if (inBlock) {
        const patch = (Math.sin(x * 0.05) * Math.cos(z * 0.05) + 1) * 0.5;
        colors[i * 3] = 0.27 + patch * 0.09;
        colors[i * 3 + 1] = 0.36 + patch * 0.09;
        colors[i * 3 + 2] = 0.21 + patch * 0.04;
      } else {
        colors[i * 3] = 0.30;
        colors[i * 3 + 1] = 0.29;
        colors[i * 3 + 2] = 0.26;
      }
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();

    this.terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.94,
      metalness: 0.0,
      envMapIntensity: this.reflectionsEnabled ? 1.0 : 0.2,
    });
    const mesh = new THREE.Mesh(geo, this.terrainMat);
    this.groundGroup.add(mesh);
    this.disposables.push(geo, this.terrainMat);
  }

  private buildStreetRibbonGeos(
    seg: StreetSegment,
    terrain: RoadTerrain,
    roadGeos: THREE.BufferGeometry[],
    walkGeos: THREE.BufferGeometry[]
  ): void {
    const len = Math.hypot(seg.bx - seg.ax, seg.bz - seg.az);
    const steps = Math.max(10, Math.round(len / 5));
    const dx = (seg.bx - seg.ax) / len;
    const dz = (seg.bz - seg.az) / len;
    const rx = -dz;
    const rz = dx;

    const verts: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];

    const walkVerts: number[] = [];
    const walkUVs: number[] = [];
    const walkIndices: number[] = [];

    const hw = seg.halfWidth;
    const sw = hw + 1.85;

    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const cx = seg.ax + (seg.bx - seg.ax) * t;
      const cz = seg.az + (seg.bz - seg.az) * t;

      const lx = cx - rx * hw;
      const lz = cz - rz * hw;
      const rxp = cx + rx * hw;
      const rzp = cz + rz * hw;

      const yL = terrain.baseTerrainHeight(lx, lz) + 0.03;
      const yR = terrain.baseTerrainHeight(rxp, rzp) + 0.03;

      verts.push(lx, yL, lz, rxp, yR, rzp);
      uvs.push(0, (t * len) / 12, 1, (t * len) / 12);

      const lOutX = cx - rx * sw;
      const lOutZ = cz - rz * sw;
      const rOutX = cx + rx * sw;
      const rOutZ = cz + rz * sw;
      const yLOut = terrain.baseTerrainHeight(lOutX, lOutZ) + 0.13;
      const yROut = terrain.baseTerrainHeight(rOutX, rOutZ) + 0.13;

      walkVerts.push(
        lx, yL + 0.1, lz,
        lOutX, yLOut, lOutZ,
        rxp, yR + 0.1, rzp,
        rOutX, yROut, rOutZ
      );
      const vW = (t * len) / 4;
      walkUVs.push(0, vW, 1, vW, 0, vW, 1, vW);

      if (i < steps) {
        const b = i * 2;
        indices.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
        const w = i * 4;
        walkIndices.push(w, w + 1, w + 4, w + 1, w + 5, w + 4);
        walkIndices.push(w + 3, w + 2, w + 7, w + 2, w + 6, w + 7);
      }
    }

    const rGeo = new THREE.BufferGeometry();
    rGeo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    rGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    rGeo.setIndex(indices);
    rGeo.computeVertexNormals();
    roadGeos.push(rGeo);

    const wGeo = new THREE.BufferGeometry();
    wGeo.setAttribute('position', new THREE.Float32BufferAttribute(walkVerts, 3));
    wGeo.setAttribute('uv', new THREE.Float32BufferAttribute(walkUVs, 2));
    wGeo.setIndex(walkIndices);
    wGeo.computeVertexNormals();
    walkGeos.push(wGeo);
  }

  private buildStreets(terrain: RoadTerrain, textures: ProceduralTextureSet): void {
    this.asphaltMat = new THREE.MeshStandardMaterial({
      map: textures.asphaltMap,
      roughnessMap: textures.asphaltRoughness,
      roughness: this.reflectionsEnabled ? 0.76 : 0.90,
      metalness: this.reflectionsEnabled ? 0.12 : 0.04,
      envMapIntensity: this.reflectionsEnabled ? 2.2 : 0.3,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });

    installGroundPlanarReflectionShader(this.asphaltMat, this.reflector, {
      mode: 'asphalt',
      cacheKey: 'favela_asphalt_planar_v1',
      reflectStrength: 0.94,
      wetDarken: 0.56,
      blurScale: 2.35,
      includePuddleRoughness: true,
      uReflectionsEnabled: this.asphaltUniforms.uReflectionsEnabled,
    });

    this.walkMat = new THREE.MeshStandardMaterial({
      map: textures.concreteMap,
      color: 0xc2bcb2,
      roughness: this.reflectionsEnabled ? 0.80 : 0.90,
      metalness: this.reflectionsEnabled ? 0.08 : 0.02,
      envMapIntensity: this.reflectionsEnabled ? 1.4 : 0.2,
    });
    installGroundPlanarReflectionShader(this.walkMat, this.reflector, {
      mode: 'concrete',
      cacheKey: 'favela_walk_planar_v1',
      reflectStrength: 0.52,
      wetDarken: 0.72,
      blurScale: 3.1,
    });

    const roadGeos: THREE.BufferGeometry[] = [];
    const walkGeos: THREE.BufferGeometry[] = [];
    for (const seg of STREETS) {
      this.buildStreetRibbonGeos(seg, terrain, roadGeos, walkGeos);
    }

    const mergedRoad = mergeGeometries(roadGeos, false);
    for (const g of roadGeos) g.dispose();
    if (mergedRoad) {
      mergedRoad.computeBoundingSphere();
      const roadMesh = new THREE.Mesh(mergedRoad, this.asphaltMat);
      this.groundGroup.add(roadMesh);
      this.disposables.push(mergedRoad);
    }

    const mergedWalk = mergeGeometries(walkGeos, false);
    for (const g of walkGeos) g.dispose();
    if (mergedWalk) {
      mergedWalk.computeBoundingSphere();
      const walkMesh = new THREE.Mesh(mergedWalk, this.walkMat);
      this.groundGroup.add(walkMesh);
      this.disposables.push(mergedWalk);
    }
    this.disposables.push(this.asphaltMat, this.walkMat);

    // Instanced Yellow Lombada Speed Bumps
    this.bumpMat = new THREE.MeshStandardMaterial({
      color: 0xeab308,
      roughness: this.reflectionsEnabled ? 0.50 : 0.72,
      metalness: this.reflectionsEnabled ? 0.15 : 0.05,
      envMapIntensity: this.reflectionsEnabled ? 1.5 : 0.3,
    });
    const bumpGeo = new THREE.CylinderGeometry(0.14, 0.14, 1, 10, 1, false, 0, Math.PI);
    bumpGeo.rotateZ(Math.PI / 2);
    bumpGeo.scale(1, 1, 8.5);

    const bumpInst = new THREE.InstancedMesh(bumpGeo, this.bumpMat, Math.max(1, LOMBADAS.length));
    LOMBADAS.forEach((l, i) => {
      const baseH = terrain.baseTerrainHeight(l.x, l.z);
      this.dummy.position.set(l.x, baseH + 0.03, l.z);
      const yaw = Math.atan2(-l.nz, l.nx);
      this.dummy.rotation.set(0, yaw + Math.PI / 2, 0);
      this.dummy.scale.set(l.halfWidth * 1.9, 1, 1);
      this.dummy.updateMatrix();
      bumpInst.setMatrixAt(i, this.dummy.matrix);
    });
    bumpInst.computeBoundingSphere();
    this.group.add(bumpInst);
    this.reflectionHiddenMeshes.push(bumpInst);
    this.disposables.push(bumpGeo, this.bumpMat);
  }

  private buildPlazaAndRamps(textures: ProceduralTextureSet): void {
    const w = PLAZA_RECT.maxX - PLAZA_RECT.minX;
    const d = PLAZA_RECT.maxZ - PLAZA_RECT.minZ;
    const cx = (PLAZA_RECT.minX + PLAZA_RECT.maxX) * 0.5;
    const cz = (PLAZA_RECT.minZ + PLAZA_RECT.maxZ) * 0.5;

    const plazaGeo = new THREE.PlaneGeometry(w, d);
    plazaGeo.rotateX(-Math.PI / 2);
    const pUv = plazaGeo.attributes.uv as THREE.BufferAttribute;
    for (let i = 0; i < pUv.count; i++) {
      pUv.setXY(i, pUv.getX(i) * (w / 7), pUv.getY(i) * (d / 7));
    }
    this.plazaMat = new THREE.MeshStandardMaterial({
      map: textures.concreteMap,
      color: 0xb0aba2,
      roughness: this.reflectionsEnabled ? 0.78 : 0.88,
      metalness: this.reflectionsEnabled ? 0.10 : 0.02,
      envMapIntensity: this.reflectionsEnabled ? 1.6 : 0.25,
    });
    installGroundPlanarReflectionShader(this.plazaMat, this.reflector, {
      mode: 'concrete',
      cacheKey: 'favela_plaza_planar_v1',
      reflectStrength: 0.60,
      wetDarken: 0.70,
      blurScale: 2.8,
    });
    const plaza = new THREE.Mesh(plazaGeo, this.plazaMat);
    plaza.position.set(cx, 0.05, cz);
    this.groundGroup.add(plaza);
    this.disposables.push(plazaGeo, this.plazaMat);

    // Painted Favela Futsal Court ("Quadra") inside the plaza
    const courtGeo = new THREE.PlaneGeometry(34, 20);
    courtGeo.rotateX(-Math.PI / 2);
    this.courtMat = new THREE.MeshStandardMaterial({
      color: 0x1f6b58,
      roughness: this.reflectionsEnabled ? 0.35 : 0.85,
      metalness: this.reflectionsEnabled ? 0.18 : 0.0,
      envMapIntensity: this.reflectionsEnabled ? 2.0 : 0.2,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    installGroundPlanarReflectionShader(this.courtMat, this.reflector, {
      mode: 'court',
      cacheKey: 'favela_court_planar_v1',
      reflectStrength: 0.85,
      wetDarken: 0.78,
      blurScale: 1.35,
    });
    const court = new THREE.Mesh(courtGeo, this.courtMat);
    court.position.set(cx - 10, 0.07, cz - 8);
    this.groundGroup.add(court);
    this.disposables.push(courtGeo, this.courtMat);

    const lineMat = new THREE.MeshBasicMaterial({ color: 0xf4f4f0 });
    const midLineGeo = new THREE.PlaneGeometry(0.25, 19.6);
    midLineGeo.rotateX(-Math.PI / 2);
    const midLine = new THREE.Mesh(midLineGeo, lineMat);
    midLine.position.set(cx - 10, 0.085, cz - 8);
    this.groundGroup.add(midLine);
    this.disposables.push(midLineGeo, lineMat);

    // Merged Stunt Launch Ramps (single draw call)
    this.rampMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: this.reflectionsEnabled ? 0.55 : 0.75,
      metalness: this.reflectionsEnabled ? 0.35 : 0.2,
      envMapIntensity: this.reflectionsEnabled ? 1.8 : 0.3,
    });
    const rampGeos: THREE.BufferGeometry[] = [];
    const rampMat4 = new THREE.Matrix4();
    const rampEuler = new THREE.Euler();
    for (const r of STUNT_RAMPS) {
      const shape = new THREE.Shape();
      shape.moveTo(-r.length * 0.5, 0);
      shape.lineTo(r.length * 0.5, 0);
      shape.lineTo(r.length * 0.5, r.height);
      shape.closePath();

      const extrude = new THREE.ExtrudeGeometry(shape, {
        depth: r.halfWidth * 2,
        bevelEnabled: false,
      });
      extrude.translate(0, 0, -r.halfWidth);
      rampEuler.set(0, r.yaw, 0);
      rampMat4.makeRotationFromEuler(rampEuler);
      rampMat4.setPosition(r.x, 0.02, r.z);
      extrude.applyMatrix4(rampMat4);
      rampGeos.push(extrude);
    }
    const mergedRamps = mergeGeometries(rampGeos, false);
    for (const g of rampGeos) g.dispose();
    if (mergedRamps) {
      mergedRamps.computeBoundingSphere();
      this.group.add(new THREE.Mesh(mergedRamps, this.rampMat));
      this.disposables.push(mergedRamps);
    }
    this.disposables.push(this.rampMat);
  }

  private buildStreetProps(terrain: RoadTerrain, textures: ProceduralTextureSet): void {
    // Utility poles along major avenues
    const poleCoords: Array<[number, number, number]> = [];
    for (const seg of STREETS) {
      if (seg.isAlley) continue;
      const len = Math.hypot(seg.bx - seg.ax, seg.bz - seg.az);
      const dx = (seg.bx - seg.ax) / len;
      const dz = (seg.bz - seg.az) / len;
      const rx = -dz;
      const rz = dx;
      for (let d = 24; d < len - 18; d += 36) {
        const px = seg.ax + dx * d + rx * (seg.halfWidth + 0.65);
        const pz = seg.az + dz * d + rz * (seg.halfWidth + 0.65);
        if (terrain.isPointInBlock(px, pz, -0.5)) {
          poleCoords.push([px, terrain.baseTerrainHeight(px, pz) + 0.1, pz]);
        }
      }
    }

    const poleGeo = new THREE.CylinderGeometry(0.11, 0.14, 7.0, 6);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x7a7670, roughness: 0.9 });
    const poleMesh = new THREE.InstancedMesh(poleGeo, poleMat, Math.max(1, poleCoords.length));
    poleCoords.forEach(([x, y, z], i) => {
      this.dummy.position.set(x, y + 3.5, z);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.scale.set(1, 1, 1);
      this.dummy.updateMatrix();
      poleMesh.setMatrixAt(i, this.dummy.matrix);
    });
    poleMesh.computeBoundingSphere();
    this.group.add(poleMesh);
    this.disposables.push(poleGeo, poleMat);

    // Instanced Lombada Warning Signs (2 draw calls instead of 18)
    const signPostGeo = new THREE.CylinderGeometry(0.035, 0.035, 2.3, 6);
    const signPlateGeo = new THREE.BoxGeometry(0.65, 0.65, 0.04);
    const signPostMat = new THREE.MeshStandardMaterial({ color: 0x55595e, metalness: 0.6, roughness: 0.4 });
    const signPlateMat = new THREE.MeshStandardMaterial({ map: textures.signLombadaMap, roughness: 0.4 });

    const signPostMesh = new THREE.InstancedMesh(signPostGeo, signPostMat, Math.max(1, LOMBADAS.length));
    const signPlateMesh = new THREE.InstancedMesh(signPlateGeo, signPlateMat, Math.max(1, LOMBADAS.length));

    LOMBADAS.forEach((l, i) => {
      const sx = l.x - l.nx * 10 - l.nz * (l.halfWidth + 0.6);
      const sz = l.z - l.nz * 10 + l.nx * (l.halfWidth + 0.6);
      const sy = terrain.baseTerrainHeight(sx, sz) + 0.1;

      this.dummy.position.set(sx, sy + 1.15, sz);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.scale.set(1, 1, 1);
      this.dummy.updateMatrix();
      signPostMesh.setMatrixAt(i, this.dummy.matrix);

      this.dummy.position.set(sx, sy + 2.25, sz);
      this.dummy.rotation.set(0, Math.atan2(-l.nx, -l.nz), Math.PI / 4);
      this.dummy.updateMatrix();
      signPlateMesh.setMatrixAt(i, this.dummy.matrix);
    });
    signPostMesh.computeBoundingSphere();
    signPlateMesh.computeBoundingSphere();
    this.group.add(signPostMesh, signPlateMesh);
    this.reflectionHiddenMeshes.push(signPostMesh, signPlateMesh);
    this.disposables.push(signPostGeo, signPlateGeo, signPostMat, signPlateMat);

    // Tropical Hillside Trees on outer perimeter slopes
    const treeCount = 125;
    const trunkGeo = new THREE.CylinderGeometry(0.16, 0.28, 4.2, 6);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c4633, roughness: 0.92 });
    const crownGeo = new THREE.DodecahedronGeometry(1.85, 0);
    const crownMat = new THREE.MeshStandardMaterial({ color: 0x2d5e2b, roughness: 0.85 });

    const trunkMesh = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
    const crownMesh = new THREE.InstancedMesh(crownGeo, crownMat, treeCount);

    let seed = 9182;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 4294967296;
    };

    for (let t = 0; t < treeCount; t++) {
      const ang = (t / treeCount) * Math.PI * 2;
      const rad = 455 + rand() * 110;
      const tx = Math.cos(ang) * rad;
      const tz = Math.sin(ang) * rad * 0.72 - 45;
      const ty = terrain.baseTerrainHeight(tx, tz);
      const scale = 0.85 + rand() * 0.7;

      this.dummy.position.set(tx, ty + 2.0 * scale, tz);
      this.dummy.rotation.set(0, rand() * Math.PI * 2, 0);
      this.dummy.scale.set(scale, scale, scale);
      this.dummy.updateMatrix();
      trunkMesh.setMatrixAt(t, this.dummy.matrix);

      this.dummy.position.set(tx, ty + 4.3 * scale, tz);
      this.dummy.scale.set(scale * 1.1, scale * 0.85, scale * 1.1);
      this.dummy.updateMatrix();
      crownMesh.setMatrixAt(t, this.dummy.matrix);
      crownMesh.setColorAt(
        t,
        this.tmpColor.setHSL(0.28 + (rand() - 0.5) * 0.06, 0.45, 0.24 + rand() * 0.1)
      );
    }
    if (crownMesh.instanceColor) crownMesh.instanceColor.needsUpdate = true;
    trunkMesh.computeBoundingSphere();
    crownMesh.computeBoundingSphere();
    this.group.add(trunkMesh, crownMesh);
    this.reflectionHiddenMeshes.push(trunkMesh, crownMesh);
    this.disposables.push(trunkGeo, trunkMat, crownGeo, crownMat);
  }

  public spawnSmoke(x: number, y: number, z: number, vx: number, vy: number, vz: number): void {
    for (let i = 0; i < this.maxSmoke; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.kind = 'smoke';
        p.x = x + (Math.random() - 0.5) * 0.14;
        p.y = y + 0.08;
        p.z = z + (Math.random() - 0.5) * 0.14;
        p.vx = vx + (Math.random() - 0.5) * 1.2;
        p.vy = vy + 0.6 + Math.random() * 0.9;
        p.vz = vz + (Math.random() - 0.5) * 1.2;
        p.age = 0;
        p.maxAge = 0.65 + Math.random() * 0.45;
        p.size = 0.38 + Math.random() * 0.25;
        this.smokeDirty = true;
        this.smokeMesh.visible = true;
        return;
      }
    }
  }

  public spawnSparks(x: number, y: number, z: number, vx: number, vz: number, count = 4): void {
    let spawned = 0;
    for (let i = this.maxSmoke; i < this.particles.length && spawned < count; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.kind = 'spark';
        p.x = x;
        p.y = y + 0.04;
        p.z = z;
        p.vx = vx * 0.45 + (Math.random() - 0.5) * 4.5;
        p.vy = 1.6 + Math.random() * 3.4;
        p.vz = vz * 0.45 + (Math.random() - 0.5) * 4.5;
        p.age = 0;
        p.maxAge = 0.2 + Math.random() * 0.22;
        p.size = 0.8 + Math.random() * 0.6;
        this.sparkDirty = true;
        this.sparkMesh.visible = true;
        spawned++;
      }
    }
  }

  public updateParticles(dt: number, cameraPos: THREE.Vector3, playerPos: THREE.Vector3): void {
    this.skyDome.position.copy(cameraPos);
    if (!this.smokeDirty && !this.sparkDirty) return;

    if (this.smokeDirty) {
      let anyActiveSmoke = false;
      for (let i = 0; i < this.maxSmoke; i++) {
        const p = this.particles[i];
        if (p.active) {
          p.age += dt;
          if (p.age >= p.maxAge) {
            p.active = false;
          } else {
            anyActiveSmoke = true;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
            p.vx *= 0.96;
            p.vz *= 0.96;
            p.vy += 0.4 * dt;
          }
        }
        if (p.active) {
          const t = p.age / p.maxAge;
          const sc = p.size * (1 + t * 2.4) * (1 - t * 0.35);
          this.dummy.position.set(p.x, p.y, p.z);
          this.dummy.lookAt(cameraPos);
          this.dummy.scale.set(sc, sc, sc);
        } else {
          this.dummy.position.set(0, -999, 0);
          this.dummy.scale.set(0, 0, 0);
        }
        this.dummy.updateMatrix();
        this.smokeMesh.setMatrixAt(i, this.dummy.matrix);
      }
      this.smokeMesh.instanceMatrix.needsUpdate = true;
      this.smokeDirty = anyActiveSmoke;
      this.smokeMesh.visible = anyActiveSmoke;
    }

    if (this.sparkDirty) {
      let anyActiveSpark = false;
      for (let i = this.maxSmoke; i < this.particles.length; i++) {
        const p = this.particles[i];
        if (p.active) {
          p.age += dt;
          if (p.age >= p.maxAge) {
            p.active = false;
          } else {
            anyActiveSpark = true;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
            p.vy -= 14 * dt;
            if (p.y < playerPos.y - 0.5) p.vy = Math.abs(p.vy) * 0.35;
          }
        }
        if (p.active) {
          const t = p.age / p.maxAge;
          const sc = p.size * (1 - t);
          this.dummy.position.set(p.x, p.y, p.z);
          this.dummy.lookAt(p.x + p.vx, p.y + p.vy, p.z + p.vz);
          this.dummy.scale.set(sc, sc, sc);
        } else {
          this.dummy.position.set(0, -999, 0);
          this.dummy.scale.set(0, 0, 0);
        }
        this.dummy.updateMatrix();
        this.sparkMesh.setMatrixAt(i - this.maxSmoke, this.dummy.matrix);
      }
      this.sparkMesh.instanceMatrix.needsUpdate = true;
      this.sparkDirty = anyActiveSpark;
      this.sparkMesh.visible = anyActiveSpark;
    }
  }

  public setReflectionsEnabled(enabled: boolean): void {
    this.reflectionsEnabled = enabled;
    this.asphaltUniforms.uReflectionsEnabled.value = enabled ? 1.0 : 0.0;
    if (this.asphaltMat) {
      this.asphaltMat.roughness = enabled ? 0.38 : 0.90;
      this.asphaltMat.metalness = enabled ? 0.22 : 0.04;
      this.asphaltMat.envMapIntensity = enabled ? 3.8 : 0.2;
    }
    if (this.walkMat) {
      this.walkMat.roughness = enabled ? 0.45 : 0.90;
      this.walkMat.metalness = enabled ? 0.15 : 0.02;
      this.walkMat.envMapIntensity = enabled ? 2.8 : 0.2;
    }
    if (this.plazaMat) {
      this.plazaMat.roughness = enabled ? 0.40 : 0.88;
      this.plazaMat.metalness = enabled ? 0.18 : 0.02;
      this.plazaMat.envMapIntensity = enabled ? 3.2 : 0.2;
    }
    if (this.courtMat) {
      this.courtMat.roughness = enabled ? 0.18 : 0.85;
      this.courtMat.metalness = enabled ? 0.32 : 0.0;
      this.courtMat.envMapIntensity = enabled ? 4.0 : 0.2;
    }
    if (this.rampMat) {
      this.rampMat.roughness = enabled ? 0.32 : 0.75;
      this.rampMat.metalness = enabled ? 0.45 : 0.2;
      this.rampMat.envMapIntensity = enabled ? 3.5 : 0.3;
    }
    if (this.bumpMat) {
      this.bumpMat.roughness = enabled ? 0.28 : 0.72;
      this.bumpMat.metalness = enabled ? 0.35 : 0.05;
      this.bumpMat.envMapIntensity = enabled ? 3.0 : 0.3;
    }
    if (this.terrainMat) {
      this.terrainMat.roughness = enabled ? 0.65 : 0.94;
      this.terrainMat.envMapIntensity = enabled ? 1.8 : 0.2;
    }
  }

  public setRealGroundReflectionEnabled(enabled: boolean): void {
    this.realGroundReflectionsEnabled = enabled;
    this.reflector.setEnabled(enabled);
    if (enabled && !this.reflectionsEnabled) {
      if (this.asphaltMat) {
        this.asphaltMat.roughness = 0.44;
        this.asphaltMat.metalness = 0.18;
      }
      if (this.courtMat) {
        this.courtMat.roughness = 0.22;
        this.courtMat.metalness = 0.24;
      }
    } else {
      this.setReflectionsEnabled(this.reflectionsEnabled);
    }
  }

  public setReflectionQuality(quality: GraphicsQuality): void {
    this.reflector.setQuality(quality);
  }

  public setRenderDistance(distanceMeters: number): void {
    const clamped = THREE.MathUtils.clamp(distanceMeters, 150, 2000);
    // Shrink skyDome smoothly if camera.far drops below its 360m radius so the sky never clips
    const skyScale = Math.min(1, (clamped * 0.82) / 360);
    this.skyDome.scale.setScalar(skyScale);

    if (this.sceneRef.fog instanceof THREE.FogExp2) {
      this.sceneRef.fog.density = THREE.MathUtils.clamp(1.85 / clamped, 0.00085, 0.0135);
    }
  }

  public updateRenderCulling(
    _focusPos: THREE.Vector3,
    _renderDistance: number,
    _camera?: THREE.Camera
  ): void {
    // Houses removed; terrain, streets, poles, signs, and trees are single merged/instanced draw calls.
  }

  public renderGroundReflection(
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    camera: THREE.PerspectiveCamera,
    focusPos: THREE.Vector3,
    dt: number,
    onBeforeRender?: () => void,
    onAfterRender?: () => void
  ): void {
    if (!this.realGroundReflectionsEnabled) return;

    const fx = focusPos.x;
    const fz = focusPos.z;
    const inPlaza =
      fx >= PLAZA_RECT.minX - 2 &&
      fx <= PLAZA_RECT.maxX + 2 &&
      fz >= PLAZA_RECT.minZ - 2 &&
      fz <= PLAZA_RECT.maxZ + 2;

    if (inPlaza) {
      this._reflPoint.set(fx, 0.06, fz);
      this._reflNormal.set(0, 1, 0);
    } else if (
      Number.isNaN(this._lastReflFx) ||
      Math.hypot(fx - this._lastReflFx, fz - this._lastReflFz) > 0.35
    ) {
      this._lastReflFx = fx;
      this._lastReflFz = fz;
      const eps = 1.5;
      const hC = this.terrain.baseTerrainHeight(fx, fz) + 0.03;
      const hX1 = this.terrain.baseTerrainHeight(fx + eps, fz) + 0.03;
      const hX0 = this.terrain.baseTerrainHeight(fx - eps, fz) + 0.03;
      const hZ1 = this.terrain.baseTerrainHeight(fx, fz + eps) + 0.03;
      const hZ0 = this.terrain.baseTerrainHeight(fx, fz - eps) + 0.03;
      this._reflPoint.set(fx, hC, fz);
      this._reflNormal.set((hX0 - hX1) / (2 * eps), 1, (hZ0 - hZ1) / (2 * eps)).normalize();
    } else {
      this._reflPoint.x = fx;
      this._reflPoint.z = fz;
    }

    const prevGroundVis = this.groundGroup.visible;
    const prevSkyX = this.skyDome.position.x;
    const prevSkyY = this.skyDome.position.y;
    const prevSkyZ = this.skyDome.position.z;

    this.reflector.render(
      renderer,
      scene,
      camera,
      this._reflPoint,
      this._reflNormal,
      dt,
      (reflCamPos) => {
        this.groundGroup.visible = false;
        for (let i = 0; i < this.reflectionHiddenMeshes.length; i++) {
          const obj = this.reflectionHiddenMeshes[i];
          this.prevReflVis[i] = obj.visible;
          obj.visible = false;
        }
        this.skyDome.position.copy(reflCamPos);
        onBeforeRender?.();
      },
      () => {
        this.groundGroup.visible = prevGroundVis;
        for (let i = 0; i < this.reflectionHiddenMeshes.length; i++) {
          this.reflectionHiddenMeshes[i].visible = this.prevReflVis[i];
        }
        this.skyDome.position.set(prevSkyX, prevSkyY, prevSkyZ);
        onAfterRender?.();
      }
    );
  }

  public dispose(): void {
    this.reflector.dispose();
    for (const d of this.disposables) {
      d.dispose();
    }
  }
}
