import * as THREE from 'three';
import { GraphicsQuality } from './types';

export interface GroundReflectionUniforms {
  uRealGroundReflection: { value: number };
  uReflectMap: { value: THREE.Texture | null };
  uReflectMatrix: { value: THREE.Matrix4 };
  uReflectPlaneY: { value: number };
  uFocusXZ: { value: THREE.Vector2 };
  uReflectTexelSize: { value: THREE.Vector2 };
  uReflectTime: { value: number };
}

export interface GroundSurfaceReflectionConfig {
  mode: 'asphalt' | 'court' | 'concrete';
  cacheKey: string;
  reflectStrength: number;
  wetDarken: number;
  blurScale: number;
  includePuddleRoughness?: boolean;
  uReflectionsEnabled?: { value: number };
}

/**
 * Real-time planar ground reflector that renders an inverted oblique-clipped reflection
 * pass of the sky, favela houses, poles, particles, CG 160 bike, and rider, then projects
 * it onto wet asphalt, puddles, concrete sidewalks, and the futsal court with Fresnel,
 * micro-ripple distortion, and roughness-driven multi-tap specular blur.
 */
export class PlanarGroundReflector {
  private renderTarget: THREE.WebGLRenderTarget;
  private readonly reflectionCamera = new THREE.PerspectiveCamera();
  private readonly isSoftwareGl: boolean;
  private resolution = 512;
  private useHalfFloat = false;
  private renderInterval = 1;
  private frameCounter = 0;
  public enabled = true;

  public readonly uniforms: GroundReflectionUniforms;

  // Scratch math objects (zero per-frame GC)
  private readonly reflectorPlane = new THREE.Plane();
  private readonly normal = new THREE.Vector3();
  private readonly cameraWorldPosition = new THREE.Vector3();
  private readonly rotationMatrix = new THREE.Matrix4();
  private readonly lookAtPosition = new THREE.Vector3();
  private readonly clipPlane = new THREE.Vector4();
  private readonly view = new THREE.Vector3();
  private readonly target = new THREE.Vector3();
  private readonly q = new THREE.Vector4();

  constructor(isSoftwareGl: boolean) {
    this.isSoftwareGl = isSoftwareGl;
    this.resolution = isSoftwareGl ? 192 : 256;
    this.useHalfFloat = false;
    this.renderInterval = isSoftwareGl ? 3 : 1;

    this.renderTarget = this.createTarget(this.resolution, this.useHalfFloat);

    this.uniforms = {
      uRealGroundReflection: { value: 1.0 },
      uReflectMap: { value: this.renderTarget.texture },
      uReflectMatrix: { value: new THREE.Matrix4() },
      uReflectPlaneY: { value: 0.0 },
      uFocusXZ: { value: new THREE.Vector2(0, 0) },
      uReflectTexelSize: { value: new THREE.Vector2(1 / this.resolution, 1 / this.resolution) },
      uReflectTime: { value: 0.0 },
    };
  }

  private createTarget(size: number, halfFloat: boolean): THREE.WebGLRenderTarget {
    const rt = new THREE.WebGLRenderTarget(size, size, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: halfFloat ? THREE.HalfFloatType : THREE.UnsignedByteType,
      depthBuffer: true,
    });
    rt.texture.generateMipmaps = false;
    return rt;
  }

  public setEnabled(enabled: boolean): void {
    this.enabled = enabled;
    this.uniforms.uRealGroundReflection.value = enabled ? 1.0 : 0.0;
  }

  public setQuality(quality: GraphicsQuality): void {
    let nextRes = 256;
    let nextHalfFloat = false;
    let nextInterval = 1;

    if (this.isSoftwareGl) {
      nextRes = quality === 'low' ? 128 : 192;
      nextHalfFloat = false;
      nextInterval = quality === 'low' ? 4 : 3;
    } else if (quality === 'low') {
      nextRes = 128;
      nextHalfFloat = false;
      nextInterval = 3;
    } else if (quality === 'medium') {
      nextRes = 192;
      nextHalfFloat = false;
      nextInterval = 2;
    } else if (quality === 'high') {
      nextRes = 256;
      nextHalfFloat = false;
      nextInterval = 1;
    } else {
      nextRes = 384;
      nextHalfFloat = false;
      nextInterval = 1;
    }

    this.renderInterval = nextInterval;
    this.frameCounter = 0;
    if (nextRes === this.resolution && nextHalfFloat === this.useHalfFloat) return;
    this.resolution = nextRes;
    this.useHalfFloat = nextHalfFloat;
    const oldTarget = this.renderTarget;
    this.renderTarget = this.createTarget(nextRes, nextHalfFloat);
    this.uniforms.uReflectMap.value = this.renderTarget.texture;
    this.uniforms.uReflectTexelSize.value.set(1 / nextRes, 1 / nextRes);
    oldTarget.dispose();
  }

  public render(
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    camera: THREE.PerspectiveCamera,
    planePoint: THREE.Vector3,
    planeNormal: THREE.Vector3,
    dt: number,
    onBeforeRender: (reflCamPos: THREE.Vector3) => void,
    onAfterRender: () => void
  ): void {
    if (!this.enabled) return;

    this.uniforms.uReflectTime.value += dt;
    this.uniforms.uReflectPlaneY.value = planePoint.y;
    this.uniforms.uFocusXZ.value.set(planePoint.x, planePoint.z);

    if (this.renderInterval > 1) {
      const shouldRender = this.frameCounter === 0;
      this.frameCounter = (this.frameCounter + 1) % this.renderInterval;
      if (!shouldRender) return;
    }

    this.normal.copy(planeNormal).normalize();
    this.cameraWorldPosition.setFromMatrixPosition(camera.matrixWorld);

    this.view.subVectors(planePoint, this.cameraWorldPosition);
    // Avoid rendering when the camera is below the ground plane
    if (this.view.dot(this.normal) > 0.05) return;

    // Reflect camera position across ground plane
    this.view.reflect(this.normal).negate().add(planePoint);

    // Reflect look target across ground plane
    this.rotationMatrix.extractRotation(camera.matrixWorld);
    this.lookAtPosition.set(0, 0, -1).applyMatrix4(this.rotationMatrix).add(this.cameraWorldPosition);
    this.target.subVectors(planePoint, this.lookAtPosition).reflect(this.normal).negate().add(planePoint);

    this.reflectionCamera.position.copy(this.view);
    this.reflectionCamera.up.set(0, 1, 0).applyMatrix4(this.rotationMatrix).reflect(this.normal);
    this.reflectionCamera.lookAt(this.target);

    // Ground reflection fades out completely by 130m (distFade), so 215m far clip avoids rendering distant hills twice
    this.reflectionCamera.far = Math.min(camera.far, 215);
    this.reflectionCamera.near = camera.near;
    this.reflectionCamera.fov = camera.fov;
    this.reflectionCamera.aspect = camera.aspect;
    this.reflectionCamera.updateMatrixWorld(true);
    this.reflectionCamera.projectionMatrix.copy(camera.projectionMatrix);

    // Mirror any view offset horizontally
    this.reflectionCamera.projectionMatrix.elements[8] *= -1;
    this.reflectionCamera.projectionMatrix.elements[12] *= -1;

    // World-space projective texture matrix (before oblique clip plane modification)
    this.uniforms.uReflectMatrix.value.set(
      0.5, 0.0, 0.0, 0.5,
      0.0, 0.5, 0.0, 0.5,
      0.0, 0.0, 0.5, 0.5,
      0.0, 0.0, 0.0, 1.0
    );
    this.uniforms.uReflectMatrix.value.multiply(this.reflectionCamera.projectionMatrix);
    this.uniforms.uReflectMatrix.value.multiply(this.reflectionCamera.matrixWorldInverse);

    // Oblique near-plane clipping (Lengyel) so geometry below the ground plane never leaks into reflection
    this.reflectorPlane.setFromNormalAndCoplanarPoint(this.normal, planePoint);
    this.reflectorPlane.applyMatrix4(this.reflectionCamera.matrixWorldInverse);
    this.clipPlane.set(
      this.reflectorPlane.normal.x,
      this.reflectorPlane.normal.y,
      this.reflectorPlane.normal.z,
      this.reflectorPlane.constant
    );

    const pm = this.reflectionCamera.projectionMatrix;
    this.q.x = (Math.sign(this.clipPlane.x) + pm.elements[8]) / pm.elements[0];
    this.q.y = (Math.sign(this.clipPlane.y) + pm.elements[9]) / pm.elements[5];
    this.q.z = -1.0;
    this.q.w = (1.0 + pm.elements[10]) / pm.elements[14];

    this.clipPlane.multiplyScalar(2.0 / this.clipPlane.dot(this.q));
    const clipBias = 0.004;
    pm.elements[2] = this.clipPlane.x;
    pm.elements[6] = this.clipPlane.y;
    pm.elements[10] = this.clipPlane.z + 1.0 - clipBias;
    pm.elements[14] = this.clipPlane.w;

    const prevRenderTarget = renderer.getRenderTarget();
    const prevXrEnabled = renderer.xr.enabled;
    const prevShadowAutoUpdate = renderer.shadowMap.autoUpdate;

    onBeforeRender(this.reflectionCamera.position);

    renderer.xr.enabled = false;
    renderer.shadowMap.autoUpdate = false;
    renderer.setRenderTarget(this.renderTarget);
    renderer.state.buffers.depth.setMask(true);
    renderer.clear();
    renderer.render(scene, this.reflectionCamera);

    renderer.xr.enabled = prevXrEnabled;
    renderer.shadowMap.autoUpdate = prevShadowAutoUpdate;
    renderer.setRenderTarget(prevRenderTarget);

    onAfterRender();
  }

  public dispose(): void {
    this.renderTarget.dispose();
  }
}

export function installGroundPlanarReflectionShader(
  mat: THREE.MeshStandardMaterial,
  reflector: PlanarGroundReflector,
  cfg: GroundSurfaceReflectionConfig
): void {
  mat.customProgramCacheKey = () => cfg.cacheKey;
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uRealGroundReflection = reflector.uniforms.uRealGroundReflection;
    shader.uniforms.uReflectMap = reflector.uniforms.uReflectMap;
    shader.uniforms.uReflectMatrix = reflector.uniforms.uReflectMatrix;
    shader.uniforms.uReflectPlaneY = reflector.uniforms.uReflectPlaneY;
    shader.uniforms.uFocusXZ = reflector.uniforms.uFocusXZ;
    shader.uniforms.uReflectTexelSize = reflector.uniforms.uReflectTexelSize;
    shader.uniforms.uReflectTime = reflector.uniforms.uReflectTime;
    if (cfg.uReflectionsEnabled) {
      shader.uniforms.uReflectionsEnabled = cfg.uReflectionsEnabled;
    }

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
uniform mat4 uReflectMatrix;
varying vec4 vReflectCoord;
varying vec3 vReflectWorldPos;`
      )
      .replace(
        '#include <worldpos_vertex>',
        `#include <worldpos_vertex>
vec4 reflWorldPos = modelMatrix * vec4(transformed, 1.0);
vReflectWorldPos = reflWorldPos.xyz;
vReflectCoord = uReflectMatrix * reflWorldPos;`
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
uniform float uRealGroundReflection;
uniform sampler2D uReflectMap;
uniform float uReflectPlaneY;
uniform vec2 uFocusXZ;
uniform vec2 uReflectTexelSize;
uniform float uReflectTime;
${cfg.uReflectionsEnabled ? 'uniform float uReflectionsEnabled;' : ''}
varying vec4 vReflectCoord;
varying vec3 vReflectWorldPos;`
      );

    const hasSharedPuddle = Boolean(cfg.includePuddleRoughness && cfg.uReflectionsEnabled);
    if (hasSharedPuddle) {
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <roughnessmap_fragment>',
        `#include <roughnessmap_fragment>
float gMacroPuddle = -1.0;
if (uReflectionsEnabled > 0.5 || uRealGroundReflection > 0.5) {
  float puddleTex = 1.0 - texelRoughness.g;
  gMacroPuddle = 0.5 + 0.5 * sin(vReflectWorldPos.x * 0.085 + cos(vReflectWorldPos.z * 0.075) * 1.8)
    * cos(vReflectWorldPos.z * 0.092 - sin(vReflectWorldPos.x * 0.064) * 1.4);
  float combinedPuddle = clamp(puddleTex * 0.65 + gMacroPuddle * 0.52, 0.0, 1.0);
  roughnessFactor = mix(roughnessFactor * 0.72, 0.035, smoothstep(0.42, 0.80, combinedPuddle));
}`
      );
    }

    const wetModeCode =
      cfg.mode === 'asphalt'
        ? `
  float grainRough = texelRoughness.g;
  float macroNoise = ${
    hasSharedPuddle
      ? 'gMacroPuddle >= 0.0 ? gMacroPuddle : 0.5 + 0.5 * sin(vReflectWorldPos.x * 0.085 + cos(vReflectWorldPos.z * 0.075) * 1.8) * cos(vReflectWorldPos.z * 0.092 - sin(vReflectWorldPos.x * 0.064) * 1.4);'
      : '0.5 + 0.5 * sin(vReflectWorldPos.x * 0.085 + cos(vReflectWorldPos.z * 0.075) * 1.8) * cos(vReflectWorldPos.z * 0.092 - sin(vReflectWorldPos.x * 0.064) * 1.4);'
  }
  float puddleMask = smoothstep(0.45, 0.78, macroNoise * 0.56 + (1.0 - grainRough) * 0.64);
  float surfaceWet = mix(0.46, 1.0, puddleMask);
  float rippleA = sin(vReflectWorldPos.x * 13.5 + uReflectTime * 1.8 + vReflectWorldPos.z * 5.2);
  float rippleB = cos(vReflectWorldPos.z * 14.5 - uReflectTime * 1.5 - vReflectWorldPos.x * 4.7);
  float grainSlopeX = (grainRough - 0.74) * 0.012 + rippleA * 0.0014;
  float grainSlopeY = (0.74 - grainRough) * 0.010 + rippleB * 0.0014;
  vec2 uvDistort = mix(vec2(grainSlopeX, grainSlopeY), vec2(rippleA, rippleB) * 0.0009, puddleMask);
  float blurRadius = mix(${cfg.blurScale.toFixed(2)}, 0.65, puddleMask);`
        : cfg.mode === 'court'
          ? `
  float puddleMask = 0.62;
  float surfaceWet = 0.76;
  float rippleA = sin(vReflectWorldPos.x * 7.0 + vReflectWorldPos.z * 6.0);
  float rippleB = cos(vReflectWorldPos.z * 7.5 - vReflectWorldPos.x * 5.5);
  vec2 uvDistort = vec2(rippleA, rippleB) * 0.0008;
  float blurRadius = ${cfg.blurScale.toFixed(2)};`
          : `
  float macroNoise = 0.5 + 0.5 * sin(vReflectWorldPos.x * 0.11 + cos(vReflectWorldPos.z * 0.09) * 1.6)
    * cos(vReflectWorldPos.z * 0.10 - sin(vReflectWorldPos.x * 0.08) * 1.5);
  float puddleMask = smoothstep(0.56, 0.86, macroNoise);
  float surfaceWet = mix(0.28, 0.78, puddleMask);
  float rippleA = sin(vReflectWorldPos.x * 11.0 + uReflectTime * 1.4);
  float rippleB = cos(vReflectWorldPos.z * 11.0 - uReflectTime * 1.2);
  vec2 uvDistort = vec2(rippleA, rippleB) * mix(0.0032, 0.0011, puddleMask);
  float blurRadius = mix(${cfg.blurScale.toFixed(2)}, 1.15, puddleMask);`;

    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <opaque_fragment>',
      `if (uRealGroundReflection > 0.5 && vReflectCoord.w > 0.001) {
  ${wetModeCode}
  vec2 baseUv = clamp(vReflectCoord.xy / vReflectCoord.w + uvDistort, vec2(0.003), vec2(0.997));
  vec3 reflSample = texture2D(uReflectMap, baseUv).rgb;

  float ndotv = clamp(dot(normalize(geometryNormal), normalize(geometryViewDir)), 0.0, 1.0);
  float oneMinusN = 1.0 - ndotv;
  float n2 = oneMinusN * oneMinusN;
  float fresnel = mix(0.07, 0.94, n2 * n2);
  float heightMatch = 1.0 - smoothstep(0.65, 3.6, abs(vReflectWorldPos.y - uReflectPlaneY));
  vec2 focusDelta = vReflectWorldPos.xz - uFocusXZ;
  float distFade = 1.0 - smoothstep(1764.0, 16900.0, dot(focusDelta, focusDelta));

  float reflAlpha = clamp(fresnel * surfaceWet * ${cfg.reflectStrength.toFixed(2)}, 0.0, 0.93) * heightMatch * distFade;
  vec3 darkenedBase = outgoingLight * mix(1.0, ${cfg.wetDarken.toFixed(2)}, surfaceWet * heightMatch);
  vec3 baseWithoutEnv = max(vec3(0.0), darkenedBase - reflectedLight.indirectSpecular * reflAlpha * 0.80);
  outgoingLight = mix(baseWithoutEnv, reflSample, reflAlpha);
}
#include <opaque_fragment>`
    );
  };
  mat.needsUpdate = true;
}
