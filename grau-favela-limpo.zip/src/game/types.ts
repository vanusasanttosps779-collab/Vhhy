export type CameraMode = 'first_person' | 'third_person' | 'moto_vlog' | 'free_orbit';

export type PhysicsPreset = 'mx_pro' | 'simulation' | 'assist';

export type GraphicsQuality = 'low' | 'medium' | 'high' | 'ultra';

export type ScreenStretchMode = 'normal' | 'stretched' | 'ultra';

export type EmoteId =
  | 'none'
  | 'salve'
  | 'hang_loose'
  | 'salute'
  | 'flex'
  | 'celebrate'
  | 'clap'
  | 'middle_finger';

export interface ControlInputs {
  throttle: number; // 0..1
  frontBrake: number; // 0..1
  rearBrake: number; // 0..1 (freio no pé - essencial pro grau)
  steer: number; // -1 (left) .. +1 (right)
  riderPitch: number; // -1 (lean forward/tuck) .. +1 (lean back/pull grau)
  molejo: number; // -1 .. +1 (extra body sway)
  clutch: boolean; // clutch kick / embrear
  noHand: boolean; // grau sem mão / salve
  burnout: boolean;
  emote?: EmoteId;
}

export type BikeModelId = 'cg_160';

export type RiderState = 'mounted' | 'dismounting' | 'on_foot' | 'mounting';

export type GloveStyle = 'none' | 'black' | 'red' | 'white';

export type RiderShoeStyle = 'street_sneaker' | 'default';

export type BikePaintColor =
  | 'titan_red'
  | 'black'
  | 'white'
  | 'blue'
  | 'green'
  | 'yellow'
  | 'purple'
  | 'nardo_gray';

export type BikePaintFinish = 'gloss' | 'matte' | 'chrome';

export type BikeWheelColor = 'original' | 'gold' | 'red' | 'white' | 'blue' | 'bronze' | 'chrome';

export type BikeExhaustStyle = 'original' | 'titanium' | 'black' | 'gold' | 'shorty';

export type BikeFenderStyle = 'original' | 'paint' | 'carbon' | 'hidden';

export type BikeMirrorStyle = 'stock' | 'removed';

export type BikeSeatColor = 'black' | 'red' | 'brown' | 'white';

export type BikeHeadlightTint = 'white' | 'yellow' | 'blue' | 'red';

export type BikeCaliperColor = 'original' | 'red' | 'gold' | 'green' | 'blue';

export type ExhaustSoundMode = 'usa_racing' | 'original';

export interface BikeCustomization {
  paintColor: BikePaintColor;
  paintFinish: BikePaintFinish;
  wheelColor: BikeWheelColor;
  exhaustStyle: BikeExhaustStyle;
  frontFender: BikeFenderStyle;
  rearFender: BikeFenderStyle;
  mirrors: BikeMirrorStyle;
  seatColor: BikeSeatColor;
  headlightTint: BikeHeadlightTint;
  caliperColor: BikeCaliperColor;
}

export const DEFAULT_BIKE_CUSTOMIZATION: BikeCustomization = {
  paintColor: 'titan_red',
  paintFinish: 'gloss',
  wheelColor: 'original',
  exhaustStyle: 'original',
  frontFender: 'original',
  rearFender: 'original',
  mirrors: 'stock',
  seatColor: 'black',
  headlightTint: 'white',
  caliperColor: 'original',
};

export type DrinkPhase =
  | 'idle'
  | 'grabbing'
  | 'unscrewing'
  | 'removing_cap'
  | 'drinking'
  | 'recapping'
  | 'stowing';

export interface TelemetryState {
  bikeModel: BikeModelId;
  speedKmh: number;
  rpm: number;
  maxRpm: number;
  gear: number; // 0 = N, 1..5
  wheelieAngleDeg: number; // 0..95
  stoppieAngleDeg: number; // 0..60
  leanAngleDeg: number; // -55..+55
  frontSuspRatio: number; // 0..1 compressed
  rearSuspRatio: number; // 0..1 compressed
  rearSlip: number; // 0..1
  isWheelie: boolean;
  isBalancePoint: boolean;
  isScrape: boolean;
  isStoppie: boolean;
  isAirborne: boolean;
  isNoHand: boolean;
  activeEmote: EmoteId;
  revLimiter: boolean;
  clutchEngaged: boolean;
  grauDistanceM: number;
  grauDurationS: number;
  currentCombo: number;
  totalScore: number;
  bestGrauDistanceM: number;
  bestCombo: number;
  crashed: boolean;
  crashReason: string;
  posX: number;
  posZ: number;
  yawRad: number;
  riderState: RiderState;
  nearBike: boolean;
  dismountHint: string;
  isPhoneOpen: boolean;
  phoneApp: 'home' | 'maps' | 'camera';
  helmetOn: boolean;
  helmetAnimating: boolean;
  headlightOn: boolean;
  headlightLevel: number;
  drinkPhase: DrinkPhase;
  waterLevel: number;
}

export interface LoadProgress {
  loaded: boolean;
  percent: number;
  statusText: string;
  error: string | null;
}
