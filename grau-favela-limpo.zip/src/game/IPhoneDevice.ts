import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { LOMBADAS, PLAZA_RECT, STREETS, STUNT_RAMPS } from './RoadTerrain';
import type { GraphicsQuality } from './types';

export type IPhoneAppId = 'home' | 'maps' | 'camera';
export type CameraZoomOption = 0.5 | 1 | 2;

interface HitRect {
  id: string;
  x: number; // normalized 0..1 from left
  y: number; // normalized 0..1 from top
  w: number;
  h: number;
}

export interface IPhoneMapTelemetry {
  playerX: number;
  playerZ: number;
  playerYawRad: number;
  bikeX: number;
  bikeZ: number;
  bikeYawRad: number;
  speedKmh: number;
  riderState: 'mounted' | 'dismounting' | 'on_foot' | 'mounting';
}

const CANVAS_W = 560;
const CANVAS_H = 1188;

// 3:4 portrait viewfinder bounds inside CANVAS_W x CANVAS_H
const CAM_VF_Y = 154;
const CAM_VF_H = 750;

interface QualityBudget {
  canvasScale: number;
  anisoScale: number;
  useMipmaps: boolean;
  activeRedrawMs: number;
  idleRedrawMs: number;
  rtW: number;
  rtH: number;
  liveCamIntervalMs: number;
  liveCamFar: number;
  bodyEnvMult: number;
  screenEnvMult: number;
}

const QUALITY_BUDGETS: Record<GraphicsQuality, QualityBudget> = {
  low: {
    canvasScale: 0.58,
    anisoScale: 1,
    useMipmaps: false,
    activeRedrawMs: 85,
    idleRedrawMs: 1600,
    rtW: 160,
    rtH: 214,
    liveCamIntervalMs: 80,
    liveCamFar: 260,
    bodyEnvMult: 0.28,
    screenEnvMult: 0.12,
  },
  medium: {
    canvasScale: 0.72,
    anisoScale: 2,
    useMipmaps: true,
    activeRedrawMs: 58,
    idleRedrawMs: 1150,
    rtW: 224,
    rtH: 300,
    liveCamIntervalMs: 50,
    liveCamFar: 420,
    bodyEnvMult: 0.68,
    screenEnvMult: 0.35,
  },
  high: {
    canvasScale: 0.88,
    anisoScale: 4,
    useMipmaps: true,
    activeRedrawMs: 42,
    idleRedrawMs: 950,
    rtW: 300,
    rtH: 400,
    liveCamIntervalMs: 33,
    liveCamFar: 650,
    bodyEnvMult: 1.0,
    screenEnvMult: 0.65,
  },
  ultra: {
    canvasScale: 1.0,
    anisoScale: 8,
    useMipmaps: true,
    activeRedrawMs: 28,
    idleRedrawMs: 800,
    rtW: 384,
    rtH: 512,
    liveCamIntervalMs: 0,
    liveCamFar: 900,
    bodyEnvMult: 1.18,
    screenEnvMult: 0.85,
  },
};

function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
): void {
  const rad = Math.min(r, w * 0.5, h * 0.5);
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.lineTo(x + w - rad, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
  ctx.lineTo(x + w, y + h - rad);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
  ctx.lineTo(x + rad, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rad);
  ctx.lineTo(x, y + rad);
  ctx.quadraticCurveTo(x, y, x + rad, y);
  ctx.closePath();
}

function createRoundedScreenGeometry(w: number, h: number, r: number): THREE.ShapeGeometry {
  const hw = w * 0.5;
  const hh = h * 0.5;
  const rad = Math.min(r, hw, hh);
  const shape = new THREE.Shape();
  shape.moveTo(-hw + rad, -hh);
  shape.lineTo(hw - rad, -hh);
  shape.quadraticCurveTo(hw, -hh, hw, -hh + rad);
  shape.lineTo(hw, hh - rad);
  shape.quadraticCurveTo(hw, hh, hw - rad, hh);
  shape.lineTo(-hw + rad, hh);
  shape.quadraticCurveTo(-hw, hh, -hw, hh - rad);
  shape.lineTo(-hw, -hh + rad);
  shape.quadraticCurveTo(-hw, -hh, -hw + rad, -hh);

  const geo = new THREE.ShapeGeometry(shape, 10);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const uvs = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    const px = pos.getX(i);
    const py = pos.getY(i);
    uvs[i * 2] = (px + hw) / w;
    uvs[i * 2 + 1] = (py + hh) / h;
  }
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  return geo;
}

export class IPhoneDevice {
  public readonly root = new THREE.Group();
  public screenMesh: THREE.Mesh | null = null;
  public cameraViewfinderMesh: THREE.Mesh | null = null;
  public cameraRenderTarget: THREE.WebGLRenderTarget;

  private readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  private readonly texture: THREE.CanvasTexture;
  private screenMat: THREE.MeshStandardMaterial | null = null;
  private readonly bodyMaterials: { mat: THREE.MeshStandardMaterial; baseEnv: number }[] = [];
  private readonly hitRects: HitRect[] = [];

  public activeApp: IPhoneAppId = 'home';
  private openingApp: 'maps' | 'camera' = 'maps';
  private appOpenAnim = 0; // 0 = home, 1 = active app
  private appTargetOpen = false;
  private pressedIcon: 'maps' | 'camera' | null = null;
  private darkMapMode = false;

  // Map view state (world meters)
  private mapCenterX = 0;
  private mapCenterZ = 0;
  private mapZoom = 1.65; // px per world meter
  private followPlayer = true;

  // Real Live Camera App state
  public cameraZoom: CameraZoomOption = 1;
  public cameraSelfie = false;
  public cameraGrid = true;
  private cameraShutterFlash = 0;
  private cameraShutterPress = 0;
  private focusReticleX = 0.5;
  private focusReticleY = 0.44;
  private focusReticleAnim = 0;
  private pendingSnapshot = false;
  private photoCount = 0;
  private readonly thumbCanvas: HTMLCanvasElement;
  private readonly thumbCtx: CanvasRenderingContext2D | null;
  private hasThumb = false;
  private snapshotFeedbackTimer = 0;
  private lastCamRenderMs = -1000;

  // Graphics optimization budget (keeps all apps & features intact)
  private quality: GraphicsQuality = 'high';
  private budget: QualityBudget = QUALITY_BUDGETS.high;
  private reflectionsEnabled = true;
  private readonly maxAnisotropy: number;

  // Pointer interaction state
  private pointerDown = false;
  private pointerDownId: string | null = null;
  private downNx = 0;
  private downNy = 0;
  private lastNx = 0;
  private lastNy = 0;
  private draggedOnMap = false;
  private hoverTargetId: string | null = null;

  private lastDrawTime = -1000;
  private dirty = true;
  private tapFeedbackPulse = 0;

  // Cached latest telemetry
  private telemetry: IPhoneMapTelemetry = {
    playerX: -65,
    playerZ: 0,
    playerYawRad: 0,
    bikeX: -65,
    bikeZ: 0,
    bikeYawRad: 0,
    speedKmh: 0,
    riderState: 'mounted',
  };

  constructor(private readonly scene: THREE.Scene, maxAnisotropy = 4) {
    this.maxAnisotropy = maxAnisotropy;
    this.root.name = 'IPhone17Pro_Device';
    this.root.visible = false;
    this.scene.add(this.root);

    this.canvas = document.createElement('canvas');
    this.canvas.width = Math.round(CANVAS_W * this.budget.canvasScale);
    this.canvas.height = Math.round(CANVAS_H * this.budget.canvasScale);
    const ctx = this.canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Could not initialize 2D context for iPhone screen');
    }
    this.ctx = ctx;

    this.texture = new THREE.CanvasTexture(this.canvas);
    this.texture.colorSpace = THREE.SRGBColorSpace;
    this.texture.anisotropy = Math.min(this.budget.anisoScale, maxAnisotropy);
    this.texture.minFilter = THREE.LinearMipmapLinearFilter;
    this.texture.magFilter = THREE.LinearFilter;
    this.texture.generateMipmaps = true;

    this.cameraRenderTarget = new THREE.WebGLRenderTarget(this.budget.rtW, this.budget.rtH, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      depthBuffer: true,
      stencilBuffer: false,
    });
    this.cameraRenderTarget.texture.generateMipmaps = false;

    this.thumbCanvas = document.createElement('canvas');
    this.thumbCanvas.width = 72;
    this.thumbCanvas.height = 72;
    this.thumbCtx = this.thumbCanvas.getContext('2d');
  }

  public async loadModel(): Promise<void> {
    const loader = new GLTFLoader();
    const gltf = await loader.loadAsync('/models/apple_iphone_17_pro.glb');

    let bodyNode: THREE.Object3D | undefined =
      gltf.scene.getObjectByName('Apple_iPhone_17_Pro') ??
      gltf.scene.getObjectByName('Apple iPhone 17 Pro');
    if (!bodyNode) {
      gltf.scene.traverse((obj) => {
        if (!bodyNode && obj.children.length > 0 && /apple.*iphone/i.test(obj.name)) {
          bodyNode = obj;
        }
      });
    }
    const phoneBody = bodyNode ?? gltf.scene;

    // Strip the floating Apple boot-logo triangles on the front glass (z_raw < -0.22)
    // while keeping the rear Apple logo and triple camera metallic trim intact.
    phoneBody.traverse((obj: any) => {
      if (!obj.isMesh) return;
      obj.castShadow = false;
      obj.receiveShadow = false;
      obj.frustumCulled = false;

      const geo = obj.geometry as THREE.BufferGeometry;
      const mat = obj.material as THREE.MeshStandardMaterial | undefined;

      if (mat) {
        let baseEnv = 1.35;
        if (mat.name === '.003') {
          mat.roughness = 0.28;
          mat.metalness = 0.25;
        } else if (mat.name === 'material' || mat.name === '.001') {
          mat.roughness = 0.24;
          mat.metalness = 0.72;
        } else if (mat.name === '.006') {
          mat.roughness = 0.08;
          mat.metalness = 0.15;
          baseEnv = 1.75;
        }
        mat.envMapIntensity = baseEnv * this.budget.bodyEnvMult;
        this.bodyMaterials.push({ mat, baseEnv });
      }

      if (obj.name.toLowerCase().includes('apple') && geo.attributes.position && geo.index) {
        const pos = geo.attributes.position as THREE.BufferAttribute;
        const idx = geo.index;
        const keep: number[] = [];
        for (let i = 0; i < idx.count; i += 3) {
          const ia = idx.getX(i);
          const ib = idx.getX(i + 1);
          const ic = idx.getX(i + 2);
          const cz = (pos.getZ(ia) + pos.getZ(ib) + pos.getZ(ic)) / 3;
          if (cz > -0.22) {
            keep.push(ia, ib, ic);
          }
        }
        geo.setIndex(keep);
      }
    });

    // Normalize raw "Apple_iPhone_17_Pro" local coords into clean upright portrait meters (+Y up, +X right, +Z screen front)
    const cxRaw = 1.11595;
    const cyRaw = 0.5618;
    const czRaw = -0.0923;
    const scale = 0.160 / 3.9625; // ~16.0cm tall Pro Max scale for crisp legibility in 1st person

    const pivot = new THREE.Group();
    pivot.rotation.order = 'YXZ';
    pivot.rotation.set(0, Math.PI, -Math.PI / 2);
    pivot.scale.setScalar(scale);

    const offsetGroup = new THREE.Group();
    offsetGroup.position.set(-cxRaw, -cyRaw, -czRaw);
    offsetGroup.add(phoneBody);
    phoneBody.position.set(0, 0, 0);
    phoneBody.quaternion.identity();
    phoneBody.scale.set(1, 1, 1);

    pivot.add(offsetGroup);
    this.root.add(pivot);

    // Exact front display glass inner bounds in normalized meters (0.12mm proud of 0.00620 bezel glass)
    const screenW = 1.8359 * scale - 0.0008;
    const screenH = 3.8936 * scale - 0.0008;
    const screenCenterX = -(0.56405 - cyRaw) * scale;
    const screenCenterY = -(1.1159 - cxRaw) * scale;
    const screenZ = 0.00632;

    // Live 3D Viewfinder quad tucked 0.03mm behind screenMesh, revealed cleanly through transparent viewfinder window
    const vfW = screenW * 0.992;
    const vfH = screenH * (CAM_VF_H / CANVAS_H);
    const vfCenterNy = (CAM_VF_Y + CAM_VF_H * 0.5) / CANVAS_H;
    const vfCenterY = screenCenterY + (0.5 - vfCenterNy) * screenH;
    const vfGeo = new THREE.PlaneGeometry(vfW, vfH);
    const vfMat = new THREE.MeshBasicMaterial({
      map: this.cameraRenderTarget.texture,
      color: 0xffffff,
      toneMapped: true,
      side: THREE.FrontSide,
    });
    const vfMesh = new THREE.Mesh(vfGeo, vfMat);
    vfMesh.name = 'IPhone_Camera_LiveFeed';
    vfMesh.frustumCulled = false;
    vfMesh.visible = false;
    vfMesh.renderOrder = 1;
    vfMesh.position.set(screenCenterX, vfCenterY, screenZ - 0.00003);
    this.root.add(vfMesh);
    this.cameraViewfinderMesh = vfMesh;

    const screenGeo = createRoundedScreenGeometry(screenW, screenH, 0.0086);
    const screenMat = new THREE.MeshStandardMaterial({
      color: 0x0a0a0c,
      map: this.texture,
      emissive: new THREE.Color(0xffffff),
      emissiveMap: this.texture,
      emissiveIntensity: 0.92,
      roughness: 0.12,
      metalness: 0.04,
      envMapIntensity: this.reflectionsEnabled ? this.budget.screenEnvMult : 0.12,
      transparent: true,
      side: THREE.FrontSide,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    this.screenMat = screenMat;

    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.name = 'IPhone_Interactive_Screen';
    screenMesh.frustumCulled = false;
    screenMesh.renderOrder = 2;
    screenMesh.position.set(screenCenterX, screenCenterY, screenZ);
    this.root.add(screenMesh);
    this.screenMesh = screenMesh;

    this.redraw(true);
  }

  public setGraphicsQuality(quality: GraphicsQuality): void {
    this.quality = quality;
    this.budget = QUALITY_BUDGETS[quality];

    const targetW = Math.round(CANVAS_W * this.budget.canvasScale);
    const targetH = Math.round(CANVAS_H * this.budget.canvasScale);
    if (this.canvas.width !== targetW || this.canvas.height !== targetH) {
      this.canvas.width = targetW;
      this.canvas.height = targetH;
      this.texture.anisotropy = Math.min(this.budget.anisoScale, this.maxAnisotropy);
      this.texture.generateMipmaps = this.budget.useMipmaps;
      this.texture.minFilter = this.budget.useMipmaps
        ? THREE.LinearMipmapLinearFilter
        : THREE.LinearFilter;
      this.dirty = true;
    }

    if (
      this.cameraRenderTarget.width !== this.budget.rtW ||
      this.cameraRenderTarget.height !== this.budget.rtH
    ) {
      this.cameraRenderTarget.setSize(this.budget.rtW, this.budget.rtH);
    }

    this.applyMaterialReflections();
    this.redraw(true);
  }

  public setReflectionsEnabled(enabled: boolean): void {
    this.reflectionsEnabled = enabled;
    this.applyMaterialReflections();
  }

  private applyMaterialReflections(): void {
    const envScale = this.reflectionsEnabled ? this.budget.bodyEnvMult : 0.25;
    for (let i = 0; i < this.bodyMaterials.length; i++) {
      const entry = this.bodyMaterials[i];
      entry.mat.envMapIntensity = entry.baseEnv * envScale;
    }
    if (this.screenMat) {
      this.screenMat.envMapIntensity = this.reflectionsEnabled ? this.budget.screenEnvMult : 0.10;
    }
  }

  public shouldRenderLiveCamera(nowMs: number): boolean {
    const liveActive = this.activeApp === 'camera' && this.appOpenAnim >= 0.72;
    if (this.cameraViewfinderMesh) {
      this.cameraViewfinderMesh.visible = liveActive && this.root.visible;
    }
    if (!liveActive || !this.root.visible) return false;
    if (this.pendingSnapshot) return true;
    return nowMs - this.lastCamRenderMs >= this.budget.liveCamIntervalMs;
  }

  public markCameraRendered(nowMs: number): void {
    this.lastCamRenderMs = nowMs;
  }

  public getLiveCameraFar(): number {
    return this.budget.liveCamFar;
  }

  public getCameraFovDeg(): number {
    if (this.cameraSelfie) return 68;
    if (this.cameraZoom === 0.5) return 90;
    if (this.cameraZoom === 2) return 35;
    return 60;
  }

  public capturePendingSnapshot(renderer: THREE.WebGLRenderer): boolean {
    if (!this.pendingSnapshot) return false;
    this.pendingSnapshot = false;

    if (!this.thumbCtx) return true;
    const w = this.cameraRenderTarget.width;
    const h = this.cameraRenderTarget.height;
    const buf = new Uint8Array(w * h * 4);
    renderer.readRenderTargetPixels(this.cameraRenderTarget, 0, 0, w, h, buf);

    const tmp = document.createElement('canvas');
    tmp.width = w;
    tmp.height = h;
    const tCtx = tmp.getContext('2d');
    if (tCtx) {
      const img = tCtx.createImageData(w, h);
      // Flip WebGL bottom-up rows to top-down canvas coordinates (plus mirror if selfie)
      for (let y = 0; y < h; y++) {
        const srcY = h - 1 - y;
        for (let x = 0; x < w; x++) {
          const srcX = this.cameraSelfie ? w - 1 - x : x;
          const sIdx = (srcY * w + srcX) * 4;
          const dIdx = (y * w + x) * 4;
          img.data[dIdx] = buf[sIdx];
          img.data[dIdx + 1] = buf[sIdx + 1];
          img.data[dIdx + 2] = buf[sIdx + 2];
          img.data[dIdx + 3] = 255;
        }
      }
      tCtx.putImageData(img, 0, 0);

      // Center square crop into 72x72 thumbnail canvas
      const crop = Math.min(w, h);
      const sx = (w - crop) * 0.5;
      const sy = (h - crop) * 0.5;
      this.thumbCtx.clearRect(0, 0, 72, 72);
      this.thumbCtx.drawImage(tmp, sx, sy, crop, crop, 0, 0, 72, 72);
      this.hasThumb = true;
      this.dirty = true;
    }
    return true;
  }

  private updateViewfinderSelfieUV(): void {
    if (!this.cameraViewfinderMesh) return;
    const uv = this.cameraViewfinderMesh.geometry.attributes.uv as THREE.BufferAttribute;
    if (this.cameraSelfie) {
      // PlaneGeometry standard UV corners: (0,1), (1,1), (0,0), (1,0) -> mirrored horizontally
      uv.setXY(0, 1, 1);
      uv.setXY(1, 0, 1);
      uv.setXY(2, 1, 0);
      uv.setXY(3, 0, 0);
    } else {
      uv.setXY(0, 0, 1);
      uv.setXY(1, 1, 1);
      uv.setXY(2, 0, 0);
      uv.setXY(3, 1, 0);
    }
    uv.needsUpdate = true;
  }

  public setTelemetry(t: IPhoneMapTelemetry): void {
    this.telemetry = t;
    if (this.followPlayer) {
      this.mapCenterX = t.playerX;
      this.mapCenterZ = t.playerZ;
    }
  }

  public openApp(app: IPhoneAppId): void {
    this.activeApp = app;
    if (app === 'maps' || app === 'camera') {
      this.openingApp = app;
      this.appTargetOpen = true;
    } else {
      this.appTargetOpen = false;
    }
    if (app === 'maps') {
      this.followPlayer = true;
      this.mapCenterX = this.telemetry.playerX;
      this.mapCenterZ = this.telemetry.playerZ;
    }
    if (app !== 'camera' && this.cameraViewfinderMesh) {
      this.cameraViewfinderMesh.visible = false;
    }
    this.dirty = true;
  }

  /** Returns true if back action was consumed inside phone (e.g. App -> Home) */
  public handleBackAction(): boolean {
    if (this.activeApp !== 'home' || this.appTargetOpen) {
      this.openApp('home');
      return true;
    }
    return false;
  }

  public consumeTapFeedback(): number {
    const val = this.tapFeedbackPulse;
    this.tapFeedbackPulse = Math.max(0, this.tapFeedbackPulse - 0.12);
    return val;
  }

  public isHoveringInteractive(nx: number, ny: number): boolean {
    const hit = this.findHitTarget(nx, ny);
    this.hoverTargetId = hit?.id ?? null;
    return hit !== null || this.activeApp === 'maps' || this.activeApp === 'camera';
  }

  public onPointerDown(nx: number, ny: number): void {
    this.pointerDown = true;
    this.downNx = nx;
    this.downNy = ny;
    this.lastNx = nx;
    this.lastNy = ny;
    this.draggedOnMap = false;

    const hit = this.findHitTarget(nx, ny);
    this.pointerDownId = hit?.id ?? null;

    if (this.pointerDownId === 'app_maps') {
      this.pressedIcon = 'maps';
      this.tapFeedbackPulse = 1;
      this.dirty = true;
    } else if (this.pointerDownId === 'app_camera') {
      this.pressedIcon = 'camera';
      this.tapFeedbackPulse = 1;
      this.dirty = true;
    } else if (this.pointerDownId === 'cam_shutter') {
      this.cameraShutterPress = 1;
      this.tapFeedbackPulse = 1;
      this.dirty = true;
    } else if (this.pointerDownId) {
      this.tapFeedbackPulse = 0.7;
      this.dirty = true;
    }
  }

  public onPointerMove(nx: number, ny: number): void {
    if (!this.pointerDown) {
      this.hoverTargetId = this.findHitTarget(nx, ny)?.id ?? null;
      return;
    }

    if (this.activeApp === 'maps' && !this.pointerDownId) {
      const dist = Math.hypot(nx - this.downNx, ny - this.downNy);
      if (dist > 0.012) {
        this.draggedOnMap = true;
      }
      if (this.draggedOnMap) {
        const dxPx = (nx - this.lastNx) * CANVAS_W;
        const dyPx = (ny - this.lastNy) * CANVAS_H;
        this.mapCenterX -= dxPx / this.mapZoom;
        this.mapCenterZ -= dyPx / this.mapZoom;
        this.mapCenterX = THREE.MathUtils.clamp(this.mapCenterX, -460, 460);
        this.mapCenterZ = THREE.MathUtils.clamp(this.mapCenterZ, -330, 260);
        this.followPlayer = false;
        this.dirty = true;
      }
    }

    this.lastNx = nx;
    this.lastNy = ny;
  }

  public onPointerUp(nx: number, ny: number): void {
    if (!this.pointerDown) return;
    this.pointerDown = false;
    this.pressedIcon = null;
    this.cameraShutterPress = 0;

    if (!this.draggedOnMap) {
      const hit = this.findHitTarget(nx, ny);
      if (hit && hit.id === this.pointerDownId) {
        this.activateTarget(hit.id);
      } else if (
        this.activeApp === 'camera' &&
        !hit &&
        ny >= CAM_VF_Y / CANVAS_H &&
        ny <= (CAM_VF_Y + CAM_VF_H) / CANVAS_H
      ) {
        // Tap anywhere in live camera viewfinder -> yellow iOS focus reticle pulse
        this.focusReticleX = THREE.MathUtils.clamp(nx, 0.14, 0.86);
        this.focusReticleY = THREE.MathUtils.clamp(ny, 0.18, 0.70);
        this.focusReticleAnim = 1;
        this.tapFeedbackPulse = 0.55;
      }
    }
    this.pointerDownId = null;
    this.draggedOnMap = false;
    this.dirty = true;
  }

  public onWheel(deltaY: number): void {
    if (this.activeApp === 'maps') {
      const factor = deltaY < 0 ? 1.18 : 1 / 1.18;
      this.mapZoom = THREE.MathUtils.clamp(this.mapZoom * factor, 0.56, 6.2);
      this.dirty = true;
    } else if (this.activeApp === 'camera') {
      if (deltaY < 0) {
        this.cameraZoom = this.cameraZoom === 0.5 ? 1 : 2;
      } else {
        this.cameraZoom = this.cameraZoom === 2 ? 1 : 0.5;
      }
      this.dirty = true;
    }
  }

  private activateTarget(id: string): void {
    this.tapFeedbackPulse = 1;
    switch (id) {
      case 'app_maps':
        this.openApp('maps');
        break;
      case 'app_camera':
        this.openApp('camera');
        break;
      case 'home_bar':
      case 'back_menu':
        this.openApp('home');
        break;
      case 'map_recenter':
        this.followPlayer = true;
        this.mapCenterX = this.telemetry.playerX;
        this.mapCenterZ = this.telemetry.playerZ;
        break;
      case 'map_zoom_in':
        this.mapZoom = THREE.MathUtils.clamp(this.mapZoom * 1.38, 0.56, 6.2);
        break;
      case 'map_zoom_out':
        this.mapZoom = THREE.MathUtils.clamp(this.mapZoom / 1.38, 0.56, 6.2);
        break;
      case 'map_theme':
        this.darkMapMode = !this.darkMapMode;
        break;
      case 'cam_shutter':
        this.cameraShutterFlash = 1;
        this.pendingSnapshot = true;
        this.photoCount++;
        this.snapshotFeedbackTimer = 1.6;
        break;
      case 'cam_flip':
        this.cameraSelfie = !this.cameraSelfie;
        this.updateViewfinderSelfieUV();
        this.lastCamRenderMs = -1000;
        break;
      case 'cam_grid':
        this.cameraGrid = !this.cameraGrid;
        break;
      case 'cam_zoom_05':
        this.cameraZoom = 0.5;
        this.cameraSelfie = false;
        this.updateViewfinderSelfieUV();
        break;
      case 'cam_zoom_1':
        this.cameraZoom = 1;
        break;
      case 'cam_zoom_2':
        this.cameraZoom = 2;
        this.cameraSelfie = false;
        this.updateViewfinderSelfieUV();
        break;
      case 'cam_thumb':
        if (this.hasThumb) {
          this.snapshotFeedbackTimer = 1.6;
        }
        break;
      default:
        break;
    }
  }

  private findHitTarget(nx: number, ny: number): HitRect | null {
    for (let i = this.hitRects.length - 1; i >= 0; i--) {
      const r = this.hitRects[i];
      if (nx >= r.x && nx <= r.x + r.w && ny >= r.y && ny <= r.y + r.h) {
        return r;
      }
    }
    return null;
  }

  public update(dt: number, isVisible: boolean): void {
    if (!isVisible) {
      if (this.cameraViewfinderMesh) this.cameraViewfinderMesh.visible = false;
      return;
    }

    const targetAnim = this.appTargetOpen ? 1 : 0;
    const prevAnim = this.appOpenAnim;
    this.appOpenAnim = THREE.MathUtils.damp(this.appOpenAnim, targetAnim, 14, dt);
    if (Math.abs(this.appOpenAnim - targetAnim) < 0.005) {
      this.appOpenAnim = targetAnim;
    }
    if (Math.abs(this.appOpenAnim - prevAnim) > 0.001) {
      this.dirty = true;
    }

    if (this.cameraShutterFlash > 0) {
      this.cameraShutterFlash = Math.max(0, this.cameraShutterFlash - dt * 4.5);
      this.dirty = true;
    }
    if (this.focusReticleAnim > 0) {
      this.focusReticleAnim = Math.max(0, this.focusReticleAnim - dt * 1.1);
      this.dirty = true;
    }
    if (this.snapshotFeedbackTimer > 0) {
      this.snapshotFeedbackTimer = Math.max(0, this.snapshotFeedbackTimer - dt);
      if (this.snapshotFeedbackTimer === 0) this.dirty = true;
    }

    this.tapFeedbackPulse = Math.max(0, this.tapFeedbackPulse - dt * 5.2);

    const now = performance.now();
    const isInteractiveActive = this.appOpenAnim > 0.02 || this.activeApp !== 'home';
    const minIntervalMs = isInteractiveActive ? this.budget.activeRedrawMs : this.budget.idleRedrawMs;
    if (this.dirty || now - this.lastDrawTime >= minIntervalMs) {
      this.redraw(false);
    }
  }

  private registerHit(id: string, px: number, py: number, pw: number, ph: number): void {
    this.hitRects.push({
      id,
      x: px / CANVAS_W,
      y: py / CANVAS_H,
      w: pw / CANVAS_W,
      h: ph / CANVAS_H,
    });
  }

  private redraw(force: boolean): void {
    const now = performance.now();
    if (!force && !this.dirty && now - this.lastDrawTime < 28) return;
    this.lastDrawTime = now;
    this.dirty = false;
    this.hitRects.length = 0;

    const ctx = this.ctx;
    ctx.setTransform(this.budget.canvasScale, 0, 0, this.budget.canvasScale, 0, 0);
    ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);

    // Draw Home Screen as backdrop (and visible during iOS app open/close zoom)
    if (this.appOpenAnim < 0.995) {
      this.drawHomeScreen(ctx);
    }

    // Draw Active App with authentic iOS zoom-from-icon transition
    if (this.appOpenAnim > 0.01) {
      ctx.save();
      if (this.appOpenAnim < 0.995) {
        const iconCx = this.openingApp === 'camera' ? 236 : 100;
        const iconCy = 200;
        const t = this.appOpenAnim;
        const scale = THREE.MathUtils.lerp(0.18, 1.0, t);
        const cx = THREE.MathUtils.lerp(iconCx, CANVAS_W * 0.5, t);
        const cy = THREE.MathUtils.lerp(iconCy, CANVAS_H * 0.5, t);
        ctx.globalAlpha = THREE.MathUtils.clamp(t * 1.4, 0, 1);
        ctx.translate(cx, cy);
        ctx.scale(scale, scale);
        ctx.translate(-CANVAS_W * 0.5, -CANVAS_H * 0.5);
        roundRectPath(ctx, 0, 0, CANVAS_W, CANVAS_H, THREE.MathUtils.lerp(130, 0, t));
        ctx.clip();
      }
      if (this.openingApp === 'camera') {
        this.drawCameraApp(ctx);
      } else {
        this.drawMapsApp(ctx);
      }
      ctx.restore();
    }

    // Always draw real iPhone Status Bar + Dynamic Island + Home Indicator on top
    const lightTextOnTop =
      this.appOpenAnim < 0.5 || this.openingApp === 'camera' || this.darkMapMode;
    this.drawStatusBarAndIsland(ctx, lightTextOnTop);
    this.drawHomeIndicator(ctx, lightTextOnTop || this.appOpenAnim < 0.5);

    this.texture.needsUpdate = true;
  }

  private drawStatusBarAndIsland(ctx: CanvasRenderingContext2D, lightText: boolean): void {
    const fg = lightText ? '#ffffff' : '#0f172a';
    const d = new Date();
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');

    // Time (top-left beside Dynamic Island)
    ctx.fillStyle = fg;
    ctx.font = '700 22px -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${hh}:${mm}`, 94, 42);

    // Dynamic Island
    const diW = 166;
    const diH = 42;
    const diX = (CANVAS_W - diW) * 0.5;
    const diY = 21;
    roundRectPath(ctx, diX, diY, diW, diH, diH * 0.5);
    ctx.fillStyle = '#040406';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Sapphire front camera lens glint inside Dynamic Island
    const camX = diX + diW - 26;
    const camY = diY + diH * 0.5;
    ctx.beginPath();
    ctx.arc(camX, camY, 9.5, 0, Math.PI * 2);
    ctx.fillStyle = '#0c1220';
    ctx.fill();
    const lensGrad = ctx.createRadialGradient(camX - 2, camY - 2, 1, camX, camY, 6);
    lensGrad.addColorStop(0, '#38bdf8');
    lensGrad.addColorStop(0.55, '#1d4ed8');
    lensGrad.addColorStop(1, '#090d1a');
    ctx.beginPath();
    ctx.arc(camX, camY, 5.5, 0, Math.PI * 2);
    ctx.fillStyle = lensGrad;
    ctx.fill();

    // Green camera-in-use privacy indicator dot inside Dynamic Island when Camera app is active
    if (this.activeApp === 'camera') {
      ctx.beginPath();
      ctx.arc(diX + diW - 44, camY, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#30d158';
      ctx.fill();
    }

    // Right status icons: Cellular 5G bars + 5G label + Battery
    const barBaseX = 414;
    const barBaseY = 49;
    ctx.fillStyle = fg;
    for (let i = 0; i < 4; i++) {
      const bh = 6 + i * 3.5;
      roundRectPath(ctx, barBaseX + i * 6.5, barBaseY - bh, 4, bh, 1.5);
      ctx.fill();
    }

    ctx.font = '700 15px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('5G', 444, 42);

    // Battery body
    const bx = 478;
    const by = 32;
    const bw = 38;
    const bh = 20;
    roundRectPath(ctx, bx, by, bw, bh, 5.5);
    ctx.strokeStyle = lightText ? 'rgba(255,255,255,0.55)' : 'rgba(15,23,42,0.45)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Battery nub
    ctx.fillStyle = lightText ? 'rgba(255,255,255,0.55)' : 'rgba(15,23,42,0.45)';
    roundRectPath(ctx, bx + bw + 2, by + 6, 3, 8, 1.5);
    ctx.fill();

    // Green charge fill (88%)
    roundRectPath(ctx, bx + 3, by + 3, (bw - 6) * 0.88, bh - 6, 3);
    ctx.fillStyle = '#34c759';
    ctx.fill();
  }

  private drawHomeIndicator(ctx: CanvasRenderingContext2D, light: boolean): void {
    const w = 188;
    const h = 7;
    const x = (CANVAS_W - w) * 0.5;
    const y = CANVAS_H - 24;
    roundRectPath(ctx, x, y, w, h, 3.5);
    ctx.fillStyle = light ? 'rgba(255,255,255,0.88)' : 'rgba(15,23,42,0.72)';
    ctx.fill();
    if (this.activeApp !== 'home') {
      this.registerHit('home_bar', x - 40, y - 34, w + 80, 56);
    }
  }

  private drawHomeScreen(ctx: CanvasRenderingContext2D): void {
    // 1. iPhone 17 Pro Cosmic Titanium/Sunset Ocean Wallpaper
    const bg = ctx.createLinearGradient(0, 0, CANVAS_W, CANVAS_H);
    bg.addColorStop(0, '#071127');
    bg.addColorStop(0.32, '#132a5e');
    bg.addColorStop(0.62, '#2d1e5f');
    bg.addColorStop(0.84, '#9a3412');
    bg.addColorStop(1, '#ea580c');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    // Organic glowing Pro glass ribbons on wallpaper
    const glow1 = ctx.createRadialGradient(420, 290, 20, 420, 290, 320);
    glow1.addColorStop(0, 'rgba(56, 189, 248, 0.45)');
    glow1.addColorStop(0.55, 'rgba(37, 99, 235, 0.16)');
    glow1.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = glow1;
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    const glow2 = ctx.createRadialGradient(130, 820, 20, 130, 820, 340);
    glow2.addColorStop(0, 'rgba(251, 146, 60, 0.52)');
    glow2.addColorStop(0.55, 'rgba(234, 88, 12, 0.18)');
    glow2.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = glow2;
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    ctx.save();
    ctx.globalAlpha = 0.22;
    ctx.beginPath();
    ctx.moveTo(-40, 620);
    ctx.bezierCurveTo(160, 450, 380, 740, CANVAS_W + 40, 480);
    ctx.lineTo(CANVAS_W + 40, CANVAS_H);
    ctx.lineTo(-40, CANVAS_H);
    ctx.closePath();
    const waveGrad = ctx.createLinearGradient(0, 460, CANVAS_W, CANVAS_H);
    waveGrad.addColorStop(0, '#f97316');
    waveGrad.addColorStop(1, '#1e3a8a');
    ctx.fillStyle = waveGrad;
    ctx.fill();
    ctx.restore();

    const iconSize = 104;
    const iconY = 148;

    // 2A. App 1: Mapas (authentic Apple Maps artwork)
    const mapsX = 48;
    const mapsScale =
      this.pressedIcon === 'maps' ? 0.91 : this.hoverTargetId === 'app_maps' ? 1.04 : 1.0;

    ctx.save();
    ctx.translate(mapsX + iconSize * 0.5, iconY + iconSize * 0.5);
    ctx.scale(mapsScale, mapsScale);
    ctx.translate(-iconSize * 0.5, -iconSize * 0.5);
    ctx.shadowColor = 'rgba(0, 0, 0, 0.42)';
    ctx.shadowBlur = 18;
    ctx.shadowOffsetY = 8;
    roundRectPath(ctx, 0, 0, iconSize, iconSize, 24);
    ctx.fillStyle = '#f2efe4';
    ctx.fill();
    ctx.shadowColor = 'transparent';
    this.drawRealAppleMapsIcon(ctx, iconSize);
    ctx.restore();

    ctx.fillStyle = '#ffffff';
    ctx.font = '600 20px -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.65)';
    ctx.shadowBlur = 6;
    ctx.fillText('Mapas', mapsX + iconSize * 0.5, iconY + iconSize + 10);
    ctx.shadowColor = 'transparent';
    this.registerHit('app_maps', mapsX - 14, iconY - 14, iconSize + 28, iconSize + 52);

    // 2B. App 2: Câmera (authentic iPhone iOS Camera icon artwork)
    const camX = 184;
    const camScale =
      this.pressedIcon === 'camera' ? 0.91 : this.hoverTargetId === 'app_camera' ? 1.04 : 1.0;

    ctx.save();
    ctx.translate(camX + iconSize * 0.5, iconY + iconSize * 0.5);
    ctx.scale(camScale, camScale);
    ctx.translate(-iconSize * 0.5, -iconSize * 0.5);
    ctx.shadowColor = 'rgba(0, 0, 0, 0.42)';
    ctx.shadowBlur = 18;
    ctx.shadowOffsetY = 8;
    roundRectPath(ctx, 0, 0, iconSize, iconSize, 24);
    ctx.fillStyle = '#d1d5db';
    ctx.fill();
    ctx.shadowColor = 'transparent';
    this.drawRealAppleCameraIcon(ctx, iconSize);
    ctx.restore();

    ctx.fillStyle = '#ffffff';
    ctx.font = '600 20px -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.65)';
    ctx.shadowBlur = 6;
    ctx.fillText('Câmera', camX + iconSize * 0.5, iconY + iconSize + 10);
    ctx.shadowColor = 'transparent';
    this.registerHit('app_camera', camX - 14, iconY - 14, iconSize + 28, iconSize + 52);

    // Subtle iOS helper caption
    roundRectPath(ctx, 48, 336, CANVAS_W - 96, 56, 18);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.92)';
    ctx.font = '500 18px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Toque em Mapas ou Câmera para abrir', CANVAS_W * 0.5, 364);

    // 3. iOS Page Dots + "Buscar" Pill
    const searchW = 128;
    const searchH = 38;
    const searchX = (CANVAS_W - searchW) * 0.5;
    const searchY = CANVAS_H - 216;
    roundRectPath(ctx, searchX, searchY, searchW, searchH, 19);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.20)';
    ctx.fill();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.92)';
    ctx.font = '600 17px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('🔍  Buscar', CANVAS_W * 0.5, searchY + searchH * 0.5 + 1);

    // 4. Frosted Translucent iOS Dock at Bottom
    const dockX = 24;
    const dockY = CANVAS_H - 154;
    const dockW = CANVAS_W - 48;
    const dockH = 114;
    roundRectPath(ctx, dockX, dockY, dockW, dockH, 36);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  /**
   * Authentic original iPhone iOS Camera app icon cover art:
   * - Brushed metallic light silver rounded square
   * - Classic dark graphite camera silhouette with prism viewfinder hump + shutter nub
   * - Yellow/amber flash indicator dot
   * - Machined silver lens ring with deep blue/cyan optical glass coating
   */
  private drawRealAppleCameraIcon(ctx: CanvasRenderingContext2D, s: number): void {
    ctx.save();
    roundRectPath(ctx, 0, 0, s, s, s * 0.225);
    ctx.clip();

    // Brushed metallic silver-gray background gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, s);
    bgGrad.addColorStop(0, '#F2F3F5');
    bgGrad.addColorStop(0.5, '#D7DADF');
    bgGrad.addColorStop(1, '#AEB3BA');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, s, s);

    // Top-left shutter release nub
    roundRectPath(ctx, s * 0.19, s * 0.245, s * 0.11, s * 0.06, s * 0.02);
    ctx.fillStyle = '#3B3F46';
    ctx.fill();

    // Camera body + classic trapezoid top prism hump
    ctx.shadowColor = 'rgba(0, 0, 0, 0.24)';
    ctx.shadowBlur = s * 0.05;
    ctx.shadowOffsetY = s * 0.02;

    const bodyGrad = ctx.createLinearGradient(0, s * 0.20, 0, s * 0.78);
    bodyGrad.addColorStop(0, '#33363C');
    bodyGrad.addColorStop(0.35, '#1F2126');
    bodyGrad.addColorStop(1, '#121317');
    ctx.fillStyle = bodyGrad;

    // Prism viewfinder trapezoid
    ctx.beginPath();
    ctx.moveTo(s * 0.34, s * 0.31);
    ctx.lineTo(s * 0.39, s * 0.205);
    ctx.quadraticCurveTo(s * 0.405, s * 0.19, s * 0.43, s * 0.19);
    ctx.lineTo(s * 0.57, s * 0.19);
    ctx.quadraticCurveTo(s * 0.595, s * 0.19, s * 0.61, s * 0.205);
    ctx.lineTo(s * 0.66, s * 0.31);
    ctx.closePath();
    ctx.fill();

    // Main camera chassis rectangle
    roundRectPath(ctx, s * 0.12, s * 0.295, s * 0.76, s * 0.49, s * 0.085);
    ctx.fill();
    ctx.shadowColor = 'transparent';

    // Subtle inner rim highlight on top edge of camera body
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.16)';
    ctx.lineWidth = s * 0.014;
    roundRectPath(ctx, s * 0.125, s * 0.30, s * 0.75, s * 0.48, s * 0.082);
    ctx.stroke();

    // Signature amber-yellow optical flash / sensor dot (top-right of camera body)
    ctx.beginPath();
    ctx.arc(s * 0.76, s * 0.39, s * 0.032, 0, Math.PI * 2);
    ctx.fillStyle = '#FFD60A';
    ctx.fill();

    // Center lens assembly
    const cx = s * 0.50;
    const cy = s * 0.545;

    // Outer metallic aluminum barrel ring
    const ringGrad = ctx.createLinearGradient(cx, cy - s * 0.21, cx, cy + s * 0.21);
    ringGrad.addColorStop(0, '#E5E7EB');
    ringGrad.addColorStop(0.5, '#9CA3AF');
    ringGrad.addColorStop(1, '#4B5563');
    ctx.beginPath();
    ctx.arc(cx, cy, s * 0.205, 0, Math.PI * 2);
    ctx.fillStyle = ringGrad;
    ctx.fill();

    // Matte black inner barrel
    ctx.beginPath();
    ctx.arc(cx, cy, s * 0.168, 0, Math.PI * 2);
    ctx.fillStyle = '#0B0C0F';
    ctx.fill();

    // Thin machined graphite ring
    ctx.beginPath();
    ctx.arc(cx, cy, s * 0.132, 0, Math.PI * 2);
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = s * 0.018;
    ctx.stroke();

    // Deep sapphire optical glass element
    const glassGrad = ctx.createRadialGradient(
      cx - s * 0.03,
      cy - s * 0.035,
      s * 0.01,
      cx,
      cy,
      s * 0.115
    );
    glassGrad.addColorStop(0, '#38BDF8');
    glassGrad.addColorStop(0.35, '#1D4ED8');
    glassGrad.addColorStop(0.75, '#0F172A');
    glassGrad.addColorStop(1, '#030712');
    ctx.beginPath();
    ctx.arc(cx, cy, s * 0.115, 0, Math.PI * 2);
    ctx.fillStyle = glassGrad;
    ctx.fill();

    // Optical specular lens reflection glints
    ctx.beginPath();
    ctx.arc(cx - s * 0.036, cy - s * 0.038, s * 0.032, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.72)';
    ctx.fill();

    ctx.beginPath();
    ctx.arc(cx + s * 0.042, cy + s * 0.045, s * 0.018, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(125, 211, 252, 0.55)';
    ctx.fill();

    // Subtle top glossy sheen on app icon
    const sheen = ctx.createLinearGradient(0, 0, 0, s * 0.42);
    sheen.addColorStop(0, 'rgba(255,255,255,0.24)');
    sheen.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = sheen;
    ctx.fillRect(0, 0, s, s * 0.42);

    ctx.restore();
  }

  /**
   * Live 3D iOS Camera App:
   * - Opaque pure black top & bottom control bars
   * - Clear transparent 3:4 viewfinder window revealing the live GPU cameraViewfinderMesh
   * - Authentic iOS 0.5x / 1x / 2x lens pills, shutter button, selfie flip, rule-of-thirds grid & thumbnail
   */
  private drawCameraApp(ctx: CanvasRenderingContext2D): void {
    // 1. Opaque black top control strip
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, CANVAS_W, CAM_VF_Y);

    // 2. Opaque black bottom control deck
    const deckY = CAM_VF_Y + CAM_VF_H;
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, deckY, CANVAS_W, CANVAS_H - deckY);

    // During zoom animation before live quad fades in, keep dark camera iris backdrop
    if (this.appOpenAnim < 0.72) {
      ctx.fillStyle = '#060709';
      ctx.fillRect(0, CAM_VF_Y, CANVAS_W, CAM_VF_H);
    } else {
      // Clear viewfinder pixels completely so live 3D cameraRenderTarget shows cleanly behind
      ctx.clearRect(0, CAM_VF_Y, CANVAS_W, CAM_VF_H);
    }

    // Top Camera Bar: "< Menu" on left, Grid toggle & lens badge on right
    const backX = 20;
    const backY = 86;
    const backW = 108;
    const backH = 42;
    roundRectPath(ctx, backX, backY, backW, backH, 21);
    ctx.fillStyle = 'rgba(255,255,255,0.14)';
    ctx.fill();
    ctx.fillStyle = '#FFD60A';
    ctx.font = '700 18px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('‹ Menu', backX + backW * 0.5, backY + backH * 0.5 + 1);
    this.registerHit('back_menu', backX - 8, backY - 8, backW + 16, backH + 16);

    // Grid toggle button
    const gridX = CANVAS_W - 126;
    const gridY = 86;
    const gridW = 104;
    const gridH = 42;
    roundRectPath(ctx, gridX, gridY, gridW, gridH, 21);
    ctx.fillStyle = this.cameraGrid ? 'rgba(255, 214, 10, 0.20)' : 'rgba(255,255,255,0.12)';
    ctx.fill();
    ctx.strokeStyle = this.cameraGrid ? 'rgba(255, 214, 10, 0.55)' : 'rgba(255,255,255,0.16)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = this.cameraGrid ? '#FFD60A' : '#e5e7eb';
    ctx.font = '600 16px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.fillText('⊞ Grade', gridX + gridW * 0.5, gridY + gridH * 0.5 + 1);
    this.registerHit('cam_grid', gridX - 6, gridY - 6, gridW + 12, gridH + 12);

    // Subtle live mode indicator center of top bar
    ctx.fillStyle = 'rgba(255,255,255,0.72)';
    ctx.font = '700 13px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.fillText(
      this.cameraSelfie ? 'SELFIE · AO VIVO' : `${this.budget.rtW}×${this.budget.rtH} · AO VIVO`,
      CANVAS_W * 0.5,
      108
    );

    // Rule-of-thirds viewfinder grid overlay (subtle hairline lines over transparent live 3D feed)
    if (this.cameraGrid && this.appOpenAnim >= 0.72) {
      ctx.save();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
      ctx.lineWidth = 1.5;
      const x1 = CANVAS_W / 3;
      const x2 = (CANVAS_W * 2) / 3;
      const y1 = CAM_VF_Y + CAM_VF_H / 3;
      const y2 = CAM_VF_Y + (CAM_VF_H * 2) / 3;
      ctx.beginPath();
      ctx.moveTo(x1, CAM_VF_Y);
      ctx.lineTo(x1, deckY);
      ctx.moveTo(x2, CAM_VF_Y);
      ctx.lineTo(x2, deckY);
      ctx.moveTo(0, y1);
      ctx.lineTo(CANVAS_W, y1);
      ctx.moveTo(0, y2);
      ctx.lineTo(CANVAS_W, y2);
      ctx.stroke();
      ctx.restore();
    }

    // Yellow iOS tap-to-focus square reticle
    if (this.focusReticleAnim > 0.02) {
      const rx = this.focusReticleX * CANVAS_W;
      const ry = this.focusReticleY * CANVAS_H;
      const box = 82 + (1 - Math.min(1, this.focusReticleAnim * 1.8)) * 18;
      ctx.save();
      ctx.globalAlpha = Math.min(1, this.focusReticleAnim * 1.6);
      ctx.strokeStyle = '#FFD60A';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(rx - box * 0.5, ry - box * 0.5, box, box);
      // Small inner tick marks
      ctx.beginPath();
      ctx.moveTo(rx, ry - box * 0.5);
      ctx.lineTo(rx, ry - box * 0.5 + 8);
      ctx.moveTo(rx, ry + box * 0.5);
      ctx.lineTo(rx, ry + box * 0.5 - 8);
      ctx.moveTo(rx - box * 0.5, ry);
      ctx.lineTo(rx - box * 0.5 + 8, ry);
      ctx.moveTo(rx + box * 0.5, ry);
      ctx.lineTo(rx + box * 0.5 - 8, ry);
      ctx.stroke();
      ctx.restore();
    }

    // White shutter flash when capturing a photo
    if (this.cameraShutterFlash > 0.01) {
      ctx.fillStyle = `rgba(255, 255, 255, ${this.cameraShutterFlash * 0.85})`;
      ctx.fillRect(0, CAM_VF_Y, CANVAS_W, CAM_VF_H);
    }

    // Photo saved floating toast badge inside bottom of viewfinder
    if (this.snapshotFeedbackTimer > 0) {
      roundRectPath(ctx, CANVAS_W * 0.5 - 110, deckY - 56, 220, 38, 19);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.72)';
      ctx.fill();
      ctx.fillStyle = '#FFD60A';
      ctx.font = '700 15px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`Foto #${this.photoCount} capturada`, CANVAS_W * 0.5, deckY - 37);
    }

    // 3. Zoom Pills Row (0.5x | 1x | 2x)
    const zoomY = deckY + 34;
    const zoomOpts: { id: string; val: CameraZoomOption; label: string; dx: number }[] = [
      { id: 'cam_zoom_05', val: 0.5, label: '0,5', dx: -68 },
      { id: 'cam_zoom_1', val: 1, label: '1x', dx: 0 },
      { id: 'cam_zoom_2', val: 2, label: '2', dx: 68 },
    ];
    roundRectPath(ctx, CANVAS_W * 0.5 - 104, zoomY - 24, 208, 48, 24);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.10)';
    ctx.fill();

    for (const zOpt of zoomOpts) {
      const active = !this.cameraSelfie && this.cameraZoom === zOpt.val;
      const zx = CANVAS_W * 0.5 + zOpt.dx;
      const r = active ? 21 : 17;
      ctx.beginPath();
      ctx.arc(zx, zoomY, r, 0, Math.PI * 2);
      ctx.fillStyle = active ? 'rgba(255, 214, 10, 0.24)' : 'rgba(255, 255, 255, 0.08)';
      ctx.fill();
      ctx.fillStyle = active ? '#FFD60A' : '#ffffff';
      ctx.font = active
        ? '800 15px -apple-system, BlinkMacSystemFont, sans-serif'
        : '600 14px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(active && zOpt.val !== 1 ? `${zOpt.label}x` : zOpt.label, zx, zoomY + 1);
      this.registerHit(zOpt.id, zx - 28, zoomY - 26, 56, 52);
    }

    // Mode label "FOTO"
    ctx.fillStyle = '#FFD60A';
    ctx.font = '700 16px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('FOTO', CANVAS_W * 0.5, deckY + 86);

    // 4. Bottom Shutter Row: [Last Photo Thumb] --- [White Shutter] --- [Flip Camera]
    const rowY = deckY + 168;

    // Left: Last Photo Thumbnail
    const thumbX = 54;
    const thumbSize = 68;
    roundRectPath(ctx, thumbX, rowY - thumbSize * 0.5, thumbSize, thumbSize, 14);
    ctx.fillStyle = '#1c1c1e';
    ctx.fill();
    if (this.hasThumb) {
      ctx.save();
      roundRectPath(ctx, thumbX + 2, rowY - thumbSize * 0.5 + 2, thumbSize - 4, thumbSize - 4, 12);
      ctx.clip();
      ctx.drawImage(
        this.thumbCanvas,
        thumbX + 2,
        rowY - thumbSize * 0.5 + 2,
        thumbSize - 4,
        thumbSize - 4
      );
      ctx.restore();
    } else {
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.font = '600 22px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.fillText('🖼', thumbX + thumbSize * 0.5, rowY + 1);
    }
    ctx.strokeStyle = 'rgba(255,255,255,0.28)';
    ctx.lineWidth = 2;
    roundRectPath(ctx, thumbX, rowY - thumbSize * 0.5, thumbSize, thumbSize, 14);
    ctx.stroke();
    this.registerHit('cam_thumb', thumbX - 10, rowY - 42, thumbSize + 20, 84);

    // Center: Classic iOS White Circular Shutter Button
    const shutterCx = CANVAS_W * 0.5;
    ctx.beginPath();
    ctx.arc(shutterCx, rowY, 44, 0, Math.PI * 2);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 4.5;
    ctx.stroke();

    const innerR = this.cameraShutterPress > 0 ? 31 : 36;
    ctx.beginPath();
    ctx.arc(shutterCx, rowY, innerR, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    this.registerHit('cam_shutter', shutterCx - 54, rowY - 54, 108, 108);

    // Right: Classic iOS Flip Camera Button (Rear <-> Selfie)
    const flipCx = CANVAS_W - 88;
    ctx.beginPath();
    ctx.arc(flipCx, rowY, 32, 0, Math.PI * 2);
    ctx.fillStyle = this.cameraSelfie ? 'rgba(255, 214, 10, 0.24)' : 'rgba(255, 255, 255, 0.16)';
    ctx.fill();
    ctx.strokeStyle = this.cameraSelfie ? '#FFD60A' : 'rgba(255,255,255,0.85)';
    ctx.lineWidth = 2.5;
    // Draw crisp dual-arc flip icon
    ctx.beginPath();
    ctx.arc(flipCx, rowY, 14, -Math.PI * 0.85, -Math.PI * 0.12);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(flipCx, rowY, 14, Math.PI * 0.15, Math.PI * 0.88);
    ctx.stroke();
    // Arrowheads
    ctx.fillStyle = this.cameraSelfie ? '#FFD60A' : '#ffffff';
    ctx.beginPath();
    ctx.moveTo(flipCx + 16, rowY - 2);
    ctx.lineTo(flipCx + 8, rowY - 9);
    ctx.lineTo(flipCx + 18, rowY - 11);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(flipCx - 16, rowY + 2);
    ctx.lineTo(flipCx - 8, rowY + 9);
    ctx.lineTo(flipCx - 18, rowY + 11);
    ctx.closePath();
    ctx.fill();
    this.registerHit('cam_flip', flipCx - 42, rowY - 42, 84, 84);
  }

  /**
   * Faithful replica of the real iPhone Apple Maps app icon cover art
   */
  private drawRealAppleMapsIcon(ctx: CanvasRenderingContext2D, s: number): void {
    ctx.save();
    roundRectPath(ctx, 0, 0, s, s, s * 0.225);
    ctx.clip();

    ctx.fillStyle = '#F3EFE4';
    ctx.fillRect(0, 0, s, s);

    ctx.fillStyle = '#A8D8FF';
    ctx.beginPath();
    ctx.moveTo(0, s * 0.68);
    ctx.quadraticCurveTo(s * 0.22, s * 0.64, s * 0.34, s);
    ctx.lineTo(0, s);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#65D46E';
    ctx.beginPath();
    ctx.moveTo(s * 0.44, 0);
    ctx.lineTo(s, 0);
    ctx.lineTo(s, s * 0.56);
    ctx.quadraticCurveTo(s * 0.56, s * 0.48, s * 0.44, 0);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#A3E887';
    ctx.beginPath();
    ctx.moveTo(s * 0.26, 0);
    ctx.lineTo(s * 0.44, 0);
    ctx.quadraticCurveTo(s * 0.56, s * 0.48, s, s * 0.56);
    ctx.lineTo(s, s * 0.64);
    ctx.quadraticCurveTo(s * 0.48, s * 0.52, s * 0.26, 0);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#FF6482';
    ctx.lineWidth = s * 0.085;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-s * 0.05, s * 0.46);
    ctx.quadraticCurveTo(s * 0.52, s * 0.42, s * 0.92, s * 1.05);
    ctx.stroke();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = s * 0.075;
    ctx.beginPath();
    ctx.moveTo(s * 0.34, -s * 0.05);
    ctx.lineTo(s * 0.34, s * 1.05);
    ctx.stroke();

    ctx.lineWidth = s * 0.065;
    ctx.beginPath();
    ctx.moveTo(-s * 0.05, s * 0.72);
    ctx.lineTo(s * 1.05, s * 0.72);
    ctx.stroke();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = s * 0.145;
    ctx.beginPath();
    ctx.moveTo(-s * 0.08, s * 0.56);
    ctx.bezierCurveTo(s * 0.36, s * 0.52, s * 0.58, s * 0.28, s * 0.76, -s * 0.08);
    ctx.stroke();

    ctx.strokeStyle = '#FFCC00';
    ctx.lineWidth = s * 0.105;
    ctx.beginPath();
    ctx.moveTo(-s * 0.08, s * 0.56);
    ctx.bezierCurveTo(s * 0.36, s * 0.52, s * 0.58, s * 0.28, s * 0.76, -s * 0.08);
    ctx.stroke();

    const sx = s * 0.14;
    const sy = s * 0.13;
    const sw = s * 0.34;
    const sh = s * 0.28;
    roundRectPath(ctx, sx, sy, sw, sh, s * 0.07);
    ctx.fillStyle = '#007AFF';
    ctx.fill();
    ctx.save();
    roundRectPath(ctx, sx, sy, sw, sh, s * 0.07);
    ctx.clip();
    ctx.fillStyle = '#FF3B30';
    ctx.fillRect(sx, sy, sw, sh * 0.34);
    ctx.restore();
    roundRectPath(ctx, sx, sy, sw, sh, s * 0.07);
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = s * 0.022;
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = `800 ${Math.round(s * 0.14)}px -apple-system, BlinkMacSystemFont, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('280', sx + sw * 0.5, sy + sh * 0.68);

    const bx = s * 0.68;
    const by = s * 0.68;
    const br = s * 0.23;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.28)';
    ctx.shadowBlur = s * 0.07;
    ctx.shadowOffsetY = s * 0.02;
    ctx.beginPath();
    ctx.arc(bx, by, br, 0, Math.PI * 2);
    ctx.fillStyle = '#007AFF';
    ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.lineWidth = s * 0.025;
    ctx.strokeStyle = '#FFFFFF';
    ctx.stroke();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = s * 0.075;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(bx - br * 0.36, by + br * 0.42);
    ctx.lineTo(bx - br * 0.36, by - br * 0.06);
    ctx.quadraticCurveTo(bx - br * 0.36, by - br * 0.34, bx + br * 0.16, by - br * 0.34);
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.moveTo(bx + br * 0.46, by - br * 0.34);
    ctx.lineTo(bx + br * 0.12, by - br * 0.56);
    ctx.lineTo(bx + br * 0.12, by - br * 0.12);
    ctx.closePath();
    ctx.fill();

    const sheen = ctx.createLinearGradient(0, 0, 0, s * 0.45);
    sheen.addColorStop(0, 'rgba(255,255,255,0.22)');
    sheen.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = sheen;
    ctx.fillRect(0, 0, s, s * 0.45);

    ctx.restore();
  }

  private drawMapsApp(ctx: CanvasRenderingContext2D): void {
    const dark = this.darkMapMode;

    ctx.fillStyle = dark ? '#181e29' : '#F3EFE4';
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    const cx = CANVAS_W * 0.5;
    const cy = CANVAS_H * 0.46;
    const z = this.mapZoom;
    const toSx = (wx: number) => cx + (wx - this.mapCenterX) * z;
    const toSy = (wz: number) => cy + (wz - this.mapCenterZ) * z;

    const morroBottom = toSy(-25);
    if (morroBottom > 0) {
      const hillGrad = ctx.createLinearGradient(0, toSy(-320), 0, morroBottom);
      hillGrad.addColorStop(0, dark ? 'rgba(22, 101, 52, 0.35)' : 'rgba(134, 214, 134, 0.40)');
      hillGrad.addColorStop(1, 'rgba(134, 214, 134, 0)');
      ctx.fillStyle = hillGrad;
      ctx.fillRect(0, 0, CANVAS_W, Math.min(CANVAS_H, morroBottom));
    }

    const qx = toSx(PLAZA_RECT.minX);
    const qy = toSy(PLAZA_RECT.minZ);
    const qw = (PLAZA_RECT.maxX - PLAZA_RECT.minX) * z;
    const qh = (PLAZA_RECT.maxZ - PLAZA_RECT.minZ) * z;
    roundRectPath(ctx, qx, qy, qw, qh, Math.max(4, 5 * z));
    ctx.fillStyle = dark ? '#1a3f2f' : '#CDEBC1';
    ctx.fill();
    ctx.strokeStyle = dark ? '#34d399' : '#7BC96F';
    ctx.lineWidth = Math.max(1.5, 1.8 * z * 0.4);
    ctx.stroke();

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    for (let i = 0; i < STREETS.length; i++) {
      const s = STREETS[i];
      const isMain = !s.isAlley && s.halfWidth >= 5.0;
      ctx.strokeStyle = dark
        ? isMain
          ? '#64542d'
          : '#2f3a4d'
        : isMain
          ? '#E5B85C'
          : '#D6D1C4';
      ctx.lineWidth = Math.max(4, s.halfWidth * 2 * z + 3.5);
      ctx.beginPath();
      ctx.moveTo(toSx(s.ax), toSy(s.az));
      ctx.lineTo(toSx(s.bx), toSy(s.bz));
      ctx.stroke();
    }

    for (let i = 0; i < STREETS.length; i++) {
      const s = STREETS[i];
      const isMain = !s.isAlley && s.halfWidth >= 5.0;
      ctx.strokeStyle = dark
        ? isMain
          ? '#947431'
          : s.isAlley
            ? '#3e4756'
            : '#475569'
        : isMain
          ? '#FFE08A'
          : s.isAlley
            ? '#F8F7F2'
            : '#FFFFFF';
      ctx.lineWidth = Math.max(2.5, s.halfWidth * 2 * z);
      ctx.beginPath();
      ctx.moveTo(toSx(s.ax), toSy(s.az));
      ctx.lineTo(toSx(s.bx), toSy(s.bz));
      ctx.stroke();
    }

    for (let i = 0; i < LOMBADAS.length; i++) {
      const l = LOMBADAS[i];
      const lx = toSx(l.x);
      const ly = toSy(l.z);
      ctx.fillStyle = '#F59E0B';
      ctx.beginPath();
      ctx.arc(lx, ly, Math.max(2.2, 1.8 * z), 0, Math.PI * 2);
      ctx.fill();
    }

    for (let i = 0; i < STUNT_RAMPS.length; i++) {
      const r = STUNT_RAMPS[i];
      const rx = toSx(r.x);
      const ry = toSy(r.z);
      ctx.fillStyle = '#EA580C';
      ctx.beginPath();
      ctx.arc(rx, ry, Math.max(5.5, 4.5 * Math.min(2, z)), 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 1.8;
      ctx.stroke();
    }

    const drawLabel = (text: string, wx: number, wz: number, color?: string) => {
      const lx = toSx(wx);
      const ly = toSy(wz);
      if (lx < -80 || lx > CANVAS_W + 80 || ly < 80 || ly > CANVAS_H - 180) return;
      ctx.font = '700 14px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.lineWidth = 4;
      ctx.strokeStyle = dark ? 'rgba(15, 23, 42, 0.92)' : 'rgba(255, 255, 255, 0.92)';
      ctx.strokeText(text, lx, ly);
      ctx.fillStyle = color ?? (dark ? '#cbd5e1' : '#475569');
      ctx.fillText(text, lx, ly);
    };

    drawLabel('MORRO DO GRAU', 0, -242, dark ? '#86efac' : '#15803d');
    drawLabel('Av. Principal', -85, 0);
    drawLabel('Quadra', 63, 44, dark ? '#6ee7b7' : '#166534');
    drawLabel('Av. Brasil', 0, 115);
    drawLabel('Av. Marginal', 0, 210);
    drawLabel('Rua da Laje', 0, -95);
    drawLabel('Mirante', 0, -195);

    const bx = toSx(this.telemetry.bikeX);
    const by = toSy(this.telemetry.bikeZ);
    if (
      this.telemetry.riderState !== 'mounted' ||
      Math.hypot(this.telemetry.playerX - this.telemetry.bikeX, this.telemetry.playerZ - this.telemetry.bikeZ) > 1.5
    ) {
      ctx.save();
      ctx.translate(bx, by);
      ctx.shadowColor = 'rgba(0,0,0,0.35)';
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(0, -14, 14, 0, Math.PI * 2);
      ctx.fillStyle = '#EF4444';
      ctx.fill();
      ctx.shadowColor = 'transparent';
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = '#FFFFFF';
      ctx.stroke();

      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.moveTo(-6, -3);
      ctx.lineTo(6, -3);
      ctx.lineTo(0, 5);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.font = '700 11px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('CG', 0, -14);
      ctx.restore();
    }

    const px = toSx(this.telemetry.playerX);
    const py = toSy(this.telemetry.playerZ);
    const screenHeading = -this.telemetry.playerYawRad;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(screenHeading);

    const coneGrad = ctx.createRadialGradient(0, 0, 4, 0, 0, 54);
    coneGrad.addColorStop(0, 'rgba(0, 122, 255, 0.55)');
    coneGrad.addColorStop(1, 'rgba(0, 122, 255, 0)');
    ctx.fillStyle = coneGrad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, 54, -0.45, 0.45);
    ctx.closePath();
    ctx.fill();

    const pulseR = 16 + Math.sin(performance.now() * 0.005) * 3;
    ctx.beginPath();
    ctx.arc(0, 0, pulseR, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(0, 122, 255, 0.22)';
    ctx.fill();

    ctx.shadowColor = 'rgba(0,0,0,0.35)';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(0, 0, 10.5, 0, Math.PI * 2);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();
    ctx.shadowColor = 'transparent';

    ctx.beginPath();
    ctx.arc(0, 0, 7.6, 0, Math.PI * 2);
    ctx.fillStyle = '#007AFF';
    ctx.fill();
    ctx.restore();

    const pillBg = dark ? 'rgba(28, 34, 46, 0.90)' : 'rgba(255, 255, 255, 0.92)';
    const pillBorder = dark ? 'rgba(255, 255, 255, 0.14)' : 'rgba(15, 23, 42, 0.08)';
    const pillFg = dark ? '#f8fafc' : '#0f172a';

    const backX = 22;
    const backY = 86;
    const backW = 114;
    const backH = 44;
    ctx.shadowColor = 'rgba(0,0,0,0.16)';
    ctx.shadowBlur = 12;
    roundRectPath(ctx, backX, backY, backW, backH, 22);
    ctx.fillStyle = pillBg;
    ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.strokeStyle = pillBorder;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = '#007AFF';
    ctx.font = '700 18px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('‹ Menu', backX + backW * 0.5, backY + backH * 0.5 + 1);
    this.registerHit('back_menu', backX - 8, backY - 8, backW + 16, backH + 16);

    const btnX = CANVAS_W - 76;
    const btnS = 52;

    const drawCircleBtn = (id: string, y: number, label: string, active = false) => {
      ctx.shadowColor = 'rgba(0,0,0,0.18)';
      ctx.shadowBlur = 12;
      roundRectPath(ctx, btnX, y, btnS, btnS, 16);
      ctx.fillStyle = pillBg;
      ctx.fill();
      ctx.shadowColor = 'transparent';
      ctx.strokeStyle = pillBorder;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = active ? '#007AFF' : pillFg;
      ctx.font = '700 22px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, btnX + btnS * 0.5, y + btnS * 0.5 + 1);
      this.registerHit(id, btnX - 8, y - 6, btnS + 16, btnS + 12);
    };

    drawCircleBtn('map_recenter', 86, '⌖', this.followPlayer);
    drawCircleBtn('map_theme', 148, dark ? '☀' : '☾', false);
    drawCircleBtn('map_zoom_in', 220, '+', false);
    drawCircleBtn('map_zoom_out', 280, '−', false);

    const cardX = 16;
    const cardW = CANVAS_W - 32;
    const cardH = 190;
    const cardY = CANVAS_H - cardH - 12;

    ctx.shadowColor = 'rgba(0,0,0,0.24)';
    ctx.shadowBlur = 22;
    ctx.shadowOffsetY = -4;
    roundRectPath(ctx, cardX, cardY, cardW, cardH, 32);
    ctx.fillStyle = dark ? 'rgba(22, 27, 36, 0.96)' : 'rgba(255, 255, 255, 0.96)';
    ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.strokeStyle = pillBorder;
    ctx.lineWidth = 1.5;
    ctx.stroke();

    roundRectPath(ctx, CANVAS_W * 0.5 - 28, cardY + 11, 56, 6, 3);
    ctx.fillStyle = dark ? 'rgba(255,255,255,0.25)' : 'rgba(15,23,42,0.18)';
    ctx.fill();

    roundRectPath(ctx, cardX + 20, cardY + 28, cardW - 40, 48, 16);
    ctx.fillStyle = dark ? 'rgba(255,255,255,0.09)' : '#ECEFF4';
    ctx.fill();
    ctx.fillStyle = dark ? '#94a3b8' : '#64748b';
    ctx.font = '600 18px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText('🔍  Complexo do Grau · Favela', cardX + 38, cardY + 52);

    const distBike = Math.round(
      Math.hypot(this.telemetry.playerX - this.telemetry.bikeX, this.telemetry.playerZ - this.telemetry.bikeZ)
    );
    const zoneName =
      this.telemetry.playerZ < -55
        ? 'Morro do Grau'
        : this.telemetry.playerX >= PLAZA_RECT.minX - 6 &&
            this.telemetry.playerX <= PLAZA_RECT.maxX + 6 &&
            this.telemetry.playerZ >= PLAZA_RECT.minZ - 6 &&
            this.telemetry.playerZ <= PLAZA_RECT.maxZ + 6
          ? 'Quadra do Grau'
          : this.telemetry.playerZ > 155
            ? 'Av. Marginal'
            : 'Av. Principal';

    ctx.fillStyle = dark ? '#f8fafc' : '#0f172a';
    ctx.font = '700 22px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.fillText(zoneName, cardX + 24, cardY + 104);

    ctx.fillStyle = dark ? '#94a3b8' : '#475569';
    ctx.font = '500 17px -apple-system, BlinkMacSystemFont, sans-serif';
    const subInfo =
      this.telemetry.riderState === 'mounted'
        ? `CG 160 Titan · ${this.telemetry.speedKmh} km/h`
        : `A pé · CG 160 a ${distBike} m`;
    ctx.fillText(subInfo, cardX + 24, cardY + 132);

    roundRectPath(ctx, cardX + cardW - 150, cardY + 94, 128, 42, 14);
    ctx.fillStyle = '#007AFF';
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = '700 16px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(this.followPlayer ? 'GPS Ativo' : 'Livre', cardX + cardW - 86, cardY + 115);
  }

  public dispose(): void {
    this.texture.dispose();
    this.screenMat?.dispose();
    this.cameraRenderTarget.dispose();
    if (this.cameraViewfinderMesh) {
      this.cameraViewfinderMesh.geometry.dispose();
      (this.cameraViewfinderMesh.material as THREE.Material).dispose();
    }
    if (this.root.parent) {
      this.root.parent.remove(this.root);
    }
  }
}
