import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { BikePhysics } from './BikePhysics';
import { ProceduralTextureSet } from './ProceduralTextures';
import {
  BikeCustomization,
  BikeModelId,
  ControlInputs,
  DEFAULT_BIKE_CUSTOMIZATION,
  DrinkPhase,
  EmoteId,
  GloveStyle,
  RiderShoeStyle,
} from './types';
import {
  buildStreetSneakerMesh,
  ClothShaderUniforms,
  createSkinTexture,
  sampleSkinRgbFromMesh,
} from './RiderOutfitBuilder';
import {
  CustomFingerEntry,
  CustomHairChain,
  CustomRiderBoneEntry,
  CustomRiderOutfitUniforms,
  extractHelmetForCustomRider,
  isCustomTravisSkeleton,
  syncCustomOutfitUniforms,
  wireCustomTravisRider,
} from './CustomRiderAdapter';
import { WaterBottleDevice } from './WaterBottleDevice';

const RAKE_CG160_RAD = THREE.MathUtils.degToRad(25.75);

const CG160_TEX_URLS = {
  paint: '/src/assets/images/cg160_pearl_red_tile_1794943203116.jpg',
  alloy: '/src/assets/images/cg160_alloy_tile_1794943203921.jpg',
  dash: '/src/assets/images/cg160_digital_dash_1794943185756.jpg',
  seat: '/src/assets/images/cg160_seat_leather_1794943186102.jpg',
  tire: '/src/assets/images/cg160_tire_tread_1794943186903.jpg',
};

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = THREE.MathUtils.clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

export class BikeRig {
  public readonly root = new THREE.Group(); // World pos (rear ground contact), yaw
  public readonly leanPivot = new THREE.Group(); // Roll (leanAngle)
  public readonly pitchPivot = new THREE.Group(); // Wheelie/Stoppie pitch around rear contact
  public readonly chassisPivot = new THREE.Group(); // Suspension heave & chassis pitch
  public readonly steeringHeadPivot = new THREE.Group(); // Front steering axis (with rake)
  public readonly forkSlidePivot = new THREE.Group(); // Front wheel/fender suspension travel
  public readonly frontWheelSpinPivot = new THREE.Group(); // Front tire + disc spin
  public readonly swingarmPivot = new THREE.Group(); // Rear swingarm + fender
  public readonly rearWheelSpinPivot = new THREE.Group(); // Rear tire + disc spin

  public readonly leftGripTarget = new THREE.Object3D();
  public readonly rightGripTarget = new THREE.Object3D();
  public readonly headCamAnchor = new THREE.Object3D();
  public readonly footCamAnchor = new THREE.Object3D();
  public readonly bottleStowAnchor = new THREE.Object3D();

  private readonly scene: THREE.Scene;
  private readonly textures: ProceduralTextureSet;
  private readonly maxAnisotropy: number;
  public readonly contactShadowMesh: THREE.Mesh;
  private riderRoot = new THREE.Group();
  private bones = new Map<string, THREE.Bone>();
  private restQuats = new Map<string, THREE.Quaternion>();
  private restPositions = new Map<string, THREE.Vector3>();
  private restResetList: { bone: THREE.Bone; quat: THREE.Quaternion; pos: THREE.Vector3 }[] = [];
  private isCustomRider = false;
  private boneOffsets = new Map<THREE.Bone, CustomRiderBoneEntry>();
  private hairChains: CustomHairChain[] = [];
  private leftFingerBones: (Omit<CustomFingerEntry, 'qOff' | 'qOffInv'> & { qOff?: THREE.Quaternion; qOffInv?: THREE.Quaternion })[] = [];
  private rightFingerBones: (Omit<CustomFingerEntry, 'qOff' | 'qOffInv'> & { qOff?: THREE.Quaternion; qOffInv?: THREE.Quaternion })[] = [];
  private readonly customOutfitUniforms: CustomRiderOutfitUniforms = {
    uShoeMode: { value: 0.0 },
  };
  private readonly lastFingerPoseL = new Float64Array(10);
  private readonly lastFingerPoseR = new Float64Array(10);
  private hasFingerPoseL = false;
  private hasFingerPoseR = false;
  private activeBikeModel: BikeModelId = 'cg_160';
  private cg160Nodes: THREE.Object3D[] = [];
  private currentRakeRad = RAKE_CG160_RAD;
  private cgDashCanvas: HTMLCanvasElement | null = null;
  private cgDashBgCanvas: HTMLCanvasElement | null = null;
  private cgDashCtx: CanvasRenderingContext2D | null = null;
  private cgDashTexture: THREE.CanvasTexture | null = null;
  private cgDashLastDrawMs = -1000;
  private cgDashLastGear = -1;
  private cgDashLastSpeed = -1;
  private cgDashLastSegs = -1;
  private cgDashLastShift = -1;
  private cgDashLastOdo = -1;
  private cgDashLastRpmTenth = -1;
  private cgDashLastHeadlight = -1;
  private cgOdometerKm = 1428.4;

  private vestMeshes: THREE.Object3D[] = [];
  private firstPersonHeadMeshes: THREE.Object3D[] = [];
  private helmetHiddenHairMeshes: THREE.Object3D[] = [];
  private defaultShoeMeshes: THREE.Object3D[] = [];
  private streetSneakerMeshes: THREE.Object3D[] = [];
  private currentShoeStyle: RiderShoeStyle = 'street_sneaker';
  private headlightOn = true;
  private headlightPhase = 1.0;
  private headlightLevel = 1.0;
  private headlightTargetEmissive = 1.35;
  private headlightTintHex = 0xf8fafc;
  private readonly headlightOffColor = new THREE.Color(0x282d37);
  private readonly headlightOnColor = new THREE.Color(0xf8fafc);
  private readonly headlightBlendColor = new THREE.Color(0xf8fafc);
  private headlightSpotLight: THREE.SpotLight | null = null;
  private headlightSpotTarget: THREE.Object3D | null = null;
  private headlightHaloSprite: THREE.Sprite | null = null;
  private headlightBeamMesh: THREE.Mesh | null = null;
  private headlightIsFpView = false;
  private readonly helmetPivot = new THREE.Group();
  private helmetMesh: THREE.Mesh | null = null;
  private helmetOn = true;
  private helmetOffPhase = 0; // 0 = seated on head, 1 = stowed (left hip on foot / CG 160 lock mounted)
  private helmetAnimating = false;
  private lastFpMode: boolean | null = null;
  private lastOnFootMode: boolean | null = null;
  private readonly hideTorsoUniform = { value: 0.0 };
  private readonly gloveUniforms = {
    uGloveEnabled: { value: 1.0 },
    uGlovePrimary: { value: new THREE.Color(0x3d424d) },
    uGloveAccent: { value: new THREE.Color(0x6b7280) },
    uGloveMap: { value: null as THREE.Texture | null },
    uCarbonMap: { value: null as THREE.Texture | null },
    uBareHandMap: { value: null as THREE.Texture | null },
    uSkinBaseColor: { value: new THREE.Color(0xcc9272).convertSRGBToLinear() },
  };
  private readonly clothUniforms: ClothShaderUniforms = {
    uClothTime: { value: 0 },
    uClothWind: { value: 0 },
    uClothFlutter: { value: 0.08 },
    uClothSway: { value: new THREE.Vector3(0, -0.004, 0) },
  };
  private readonly clothSwayPos = new THREE.Vector3(0, -0.004, 0);
  private readonly clothSwayVel = new THREE.Vector3();
  private readonly clothTargetSway = new THREE.Vector3();
  private lastClothSpeed = 0;
  private currentGloveStyle: GloveStyle = 'black';
  private customization: BikeCustomization = { ...DEFAULT_BIKE_CUSTOMIZATION };
  private hipsBone: THREE.Bone | null = null;
  private spine2Bone: THREE.Bone | null = null;
  private neckBone: THREE.Bone | null = null;
  private headBone: THREE.Bone | null = null;

  // Customizable bike part references & shader uniforms
  private cgFrontFenderGroup: THREE.Object3D | null = null;
  private cgRearFenderGroup: THREE.Object3D | null = null;
  private mirrorMeshes: THREE.Object3D[] = [];
  private mufflerMeshes: THREE.Object3D[] = [];
  private paintMaterials: THREE.MeshStandardMaterial[] = [];
  private headlightMaterials: THREE.MeshStandardMaterial[] = [];
  private headlightGlassMaterials: THREE.MeshStandardMaterial[] = [];
  private readonly bikePaintUniforms = {
    uEnabled: { value: 0.0 },
    uColor: { value: new THREE.Color(0xd91e18) },
  };
  private readonly wheelHubUniforms = {
    uEnabled: { value: 0.0 },
    uColor: { value: new THREE.Color(0x1f2229) },
  };
  private readonly exhaustUniforms = {
    uEnabled: { value: 0.0 },
    uColor: { value: new THREE.Color(0x888d96) },
    uTitanium: { value: 0.0 },
  };
  private readonly seatUniforms = {
    uEnabled: { value: 0.0 },
    uColor: { value: new THREE.Color(0x1b1d22) },
  };
  private readonly caliperUniforms = {
    uEnabled: { value: 0.0 },
    uColor: { value: new THREE.Color(0x2d313a) },
  };
  private readonly frontFenderUniforms = {
    uMode: { value: 0.0 }, // 0: original, 1: paint, 2: carbon
    uColor: { value: new THREE.Color(0xd91e18) },
    uCarbonMap: { value: null as THREE.Texture | null },
  };
  private readonly rearFenderUniforms = {
    uMode: { value: 0.0 }, // 0: original, 1: paint, 2: carbon
    uColor: { value: new THREE.Color(0xd91e18) },
    uCarbonMap: { value: null as THREE.Texture | null },
  };

  // Reusable math scratch objects (zero per-frame GC)
  private readonly _vA = new THREE.Vector3();
  private readonly _vB = new THREE.Vector3();
  private readonly _vC = new THREE.Vector3();
  private readonly _vTarget = new THREE.Vector3();
  private readonly _vPole = new THREE.Vector3();
  private readonly _vOffset = new THREE.Vector3();
  private readonly _qWorld = new THREE.Quaternion();
  private readonly _qParent = new THREE.Quaternion();
  private readonly _qDelta = new THREE.Quaternion();
  private readonly _euler = new THREE.Euler();

  private readonly _ikToTarget = new THREE.Vector3();
  private readonly _ikDir = new THREE.Vector3();
  private readonly _ikToPole = new THREE.Vector3();
  private readonly _ikDesiredMid = new THREE.Vector3();
  private readonly _ikCurDir = new THREE.Vector3();
  private readonly _ikWantDir = new THREE.Vector3();
  private readonly _qSteer = new THREE.Quaternion();
  private readonly _qInv = new THREE.Quaternion();
  private readonly _qGrip = new THREE.Quaternion();
  private readonly _mBasis = new THREE.Matrix4();
  private readonly _vHX = new THREE.Vector3();
  private readonly _vHY = new THREE.Vector3();
  private readonly _vHZ = new THREE.Vector3();

  public fpCamDistance = 0; // -0.18 (mais perto) .. +0.24 (mais longe)
  private animTime = 0;
  private smoothThrottle = 0;
  private smoothFrontBrake = 0;
  private smoothRearBrake = 0;
  private smoothClutch = 0;
  private smoothEmoteBlend = 0;
  private activeEmoteType: EmoteId = 'none';
  private smoothFootSpeed = 0;
  private smoothFootTurn = 0;
  private smoothFootAir = 0;
  private footLandSquash = 0;
  private prevFootAirborne = false;
  private smoothFootDir = 1;
  private hasFootEyeInit = false;
  private readonly _footEyeLocal = new THREE.Vector3(0, 1.66, 0.085);
  private readonly _camPos = new THREE.Vector3();
  private readonly _camRight = new THREE.Vector3();
  private readonly _camUp = new THREE.Vector3();
  private readonly _camFwd = new THREE.Vector3();
  private readonly _camBack = new THREE.Vector3();
  private readonly _emPosL = new THREE.Vector3();
  private readonly _emPosR = new THREE.Vector3();
  private readonly _emPoleL = new THREE.Vector3();
  private readonly _emPoleR = new THREE.Vector3();
  private readonly _qStartL = new THREE.Quaternion();
  private readonly _qStartR = new THREE.Quaternion();
  private readonly _phPos = new THREE.Vector3();
  private readonly _phRight = new THREE.Vector3();
  private readonly _phUp = new THREE.Vector3();
  private readonly _phFront = new THREE.Vector3();
  private readonly _phRiderFwd = new THREE.Vector3();
  private readonly _phRiderRight = new THREE.Vector3();
  private readonly _phEye = new THREE.Vector3();
  private readonly _qMountRoot = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, Math.PI / 2, 0));
  private readonly _qStandWorld = new THREE.Quaternion();
  private readonly _upVec = new THREE.Vector3(0, 1, 0);
  private readonly _hlmHeadPos = new THREE.Vector3();
  private readonly _hlmHeadQuat = new THREE.Quaternion();
  private readonly _hlmNeckPos = new THREE.Vector3();
  private readonly _hlmSpine2Quat = new THREE.Quaternion();
  private readonly _hlmRight = new THREE.Vector3();
  private readonly _hlmFwd = new THREE.Vector3();
  private readonly _hlmLiftPos = new THREE.Vector3();
  private readonly _hlmLiftQuat = new THREE.Quaternion();
  private readonly _hlmStowPos = new THREE.Vector3();
  private readonly _hlmStowQuat = new THREE.Quaternion();
  private readonly _hlmBikeStowPos = new THREE.Vector3();
  private readonly _hlmBikeStowQuat = new THREE.Quaternion();
  private readonly _hlmFootStowPos = new THREE.Vector3();
  private readonly _hlmFootStowQuat = new THREE.Quaternion();
  private readonly _hlmPos = new THREE.Vector3();
  private readonly _hlmQuat = new THREE.Quaternion();
  private readonly _hlmHRight = new THREE.Vector3();
  private readonly _hlmHUp = new THREE.Vector3();
  private readonly _hlmHFwd = new THREE.Vector3();
  private readonly _hlmGripL = new THREE.Vector3();
  private readonly _hlmGripR = new THREE.Vector3();
  private readonly _hlmCradleL = new THREE.Vector3();
  private readonly _hlmTmpV = new THREE.Vector3();
  private readonly _hlmTmpQ = new THREE.Quaternion();
  private readonly _hairPrevHeadPos = new THREE.Vector3();
  private readonly _hairPrevHeadVel = new THREE.Vector3();
  private readonly _hairHeadVel = new THREE.Vector3();
  private readonly _hairHeadAccel = new THREE.Vector3();
  private readonly _hairHeadFwd = new THREE.Vector3();
  private readonly _hairPitchQ = new THREE.Quaternion();
  private readonly _hairRollQ = new THREE.Quaternion();
  private hasHairPrevPos = false;
  private readonly _wbAnchorPos = new THREE.Vector3();
  private readonly _wbAnchorQuat = new THREE.Quaternion();
  private readonly _wbChestPos = new THREE.Vector3();
  private readonly _wbChestQuat = new THREE.Quaternion();
  private readonly _wbDrinkPos = new THREE.Vector3();
  private readonly _wbDrinkQuat = new THREE.Quaternion();
  private readonly _wbTmpPos = new THREE.Vector3();
  private readonly _wbTmpQuat = new THREE.Quaternion();
  private readonly _wbGripPos = new THREE.Vector3();
  private readonly _wbCapWorldPos = new THREE.Vector3();
  private readonly _wbRight = new THREE.Vector3();
  private readonly _wbUp = new THREE.Vector3();
  private readonly _wbFwd = new THREE.Vector3();
  private readonly _wbMouthPos = new THREE.Vector3();
  private readonly _wbCapHoldPos = new THREE.Vector3();
  private readonly _wbCapHoldQuat = new THREE.Quaternion();
  private readonly _wbCapLocalTmp = new THREE.Vector3();

  constructor(scene: THREE.Scene, textures: ProceduralTextureSet, maxAnisotropy = 4) {
    this.scene = scene;
    this.textures = textures;
    this.maxAnisotropy = maxAnisotropy;
    this.gloveUniforms.uGloveMap.value = textures.gloveMap;
    this.gloveUniforms.uCarbonMap.value = textures.carbonMap;
    this.frontFenderUniforms.uCarbonMap.value = textures.carbonMap;
    this.rearFenderUniforms.uCarbonMap.value = textures.carbonMap;
    const shadowGeo = new THREE.PlaneGeometry(1.65, 2.75);
    shadowGeo.rotateX(-Math.PI / 2);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: textures.contactShadow,
      transparent: true,
      depthWrite: false,
      opacity: 0.72,
    });
    this.contactShadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    this.contactShadowMesh.position.y = 0.018;
    this.contactShadowMesh.rotation.y = Math.PI / 2;
    this.root.add(this.contactShadowMesh);

    this.applyBikePivotGeometry('cg_160');

    this.root.add(this.leanPivot);
    this.leanPivot.add(this.pitchPivot);
    this.pitchPivot.add(this.chassisPivot);

    this.chassisPivot.add(this.steeringHeadPivot);
    this.steeringHeadPivot.add(this.forkSlidePivot);
    this.forkSlidePivot.add(this.frontWheelSpinPivot);
    this.steeringHeadPivot.add(this.leftGripTarget);
    this.steeringHeadPivot.add(this.rightGripTarget);

    this.chassisPivot.add(this.swingarmPivot);
    this.swingarmPivot.add(this.rearWheelSpinPivot);

    this.chassisPivot.add(this.riderRoot);
    this.headCamAnchor.position.set(0.05, 1.28, 0);
    this.chassisPivot.add(this.headCamAnchor);
    this.footCamAnchor.position.set(0, 1.56, 0.08);
    this.riderRoot.add(this.footCamAnchor);

    scene.add(this.root);
    this.root.updateMatrixWorld(true);
  }

  private applyBikePivotGeometry(_model: BikeModelId): void {
    this.currentRakeRad = RAKE_CG160_RAD;
    const cosR = Math.cos(-this.currentRakeRad);
    const sinR = Math.sin(-this.currentRakeRad);

    const rearAxleX = -0.658;
    const rearAxleY = 0.311;
    const frontAxleX = 0.658;
    const frontAxleY = 0.314;
    const steerX = 0.385;
    const steerY = 0.88;
    const swingX = -0.22;
    const swingY = 0.36;

    this.pitchPivot.position.set(rearAxleX, 0, 0);
    this.chassisPivot.position.set(-rearAxleX, 0, 0);

    this.steeringHeadPivot.position.set(steerX, steerY, 0);
    this.steeringHeadPivot.rotation.order = 'ZYX';
    this.steeringHeadPivot.rotation.z = this.currentRakeRad;

    const dxF = frontAxleX - steerX;
    const dyF = frontAxleY - steerY;
    this.frontWheelSpinPivot.position.set(
      dxF * cosR - dyF * sinR,
      dxF * sinR + dyF * cosR,
      0
    );

    this.swingarmPivot.position.set(swingX, swingY, 0);
    this.rearWheelSpinPivot.position.set(rearAxleX - swingX, rearAxleY - swingY, 0);

    // Honda CG 160 Titan grips: rubber barrel center at (0.165, 1.082, ±0.262)
    const gripWorldX = 0.165;
    const gripWorldY = 1.082;
    const gripHalfW = 0.262;

    const dxG = gripWorldX - steerX;
    const dyG = gripWorldY - steerY;
    const gx = dxG * cosR - dyG * sinR;
    const gy = dxG * sinR + dyG * cosR;
    this.leftGripTarget.position.set(gx, gy, -gripHalfW);
    this.rightGripTarget.position.set(gx, gy, gripHalfW);
  }

  public setBikeModel(model: BikeModelId): void {
    this.activeBikeModel = model;
    this.applyBikePivotGeometry(model);
    for (const n of this.cg160Nodes) n.visible = true;
    this.setCustomization(this.customization);
    this.root.updateMatrixWorld(true);
  }

  public async loadModels(
    onProgress: (percent: number, label: string) => void
  ): Promise<void> {
    const loader = new GLTFLoader();
    const texLoader = new THREE.TextureLoader();

    let cgPct = 0;
    let riderPct = 0;
    const report = (label: string) => {
      onProgress(
        Math.min(95, Math.round((cgPct * 0.65 + riderPct * 0.35) * 95)),
        label
      );
    };

    const loadGlb = (url: string, slot: 'cg' | 'rider', fallbackTotal: number) =>
      new Promise<any>((resolve, reject) => {
        loader.load(
          url,
          (gltf) => {
            if (slot === 'cg') cgPct = 1;
            else riderPct = 1;
            report(slot === 'cg' ? 'CG 160 Titan carregada...' : 'Piloto carregado...');
            resolve(gltf);
          },
          (evt) => {
            const total = evt.total > 0 ? evt.total : fallbackTotal;
            if (total > 0) {
              const p = Math.min(0.98, evt.loaded / total);
              if (slot === 'cg') cgPct = Math.max(cgPct, p);
              else riderPct = Math.max(riderPct, p);
              report('Carregando CG 160 Titan e piloto 3D...');
            }
          },
          reject
        );
      });

    const loadAiTex = (url: string, repeat: boolean): Promise<THREE.Texture> =>
      new Promise((resolve) => {
        texLoader.load(
          url,
          (tex) => {
            tex.colorSpace = THREE.SRGBColorSpace;
            tex.wrapS = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
            tex.wrapT = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
            tex.anisotropy = Math.min(4, this.maxAnisotropy);
            tex.needsUpdate = true;
            resolve(tex);
          },
          undefined,
          () => resolve(this.textures.carbonMap)
        );
      });

    report('Baixando CG 160 Titan e Piloto 3D...');
    const [cgGltf, riderGltf, helmetGltf, paintTex, alloyTex, dashTex, seatTex, tireTex] =
      await Promise.all([
        loadGlb('/models/cg_160.glb', 'cg', 5689632),
        loadGlb('/models/travis_scott.glb', 'rider', 1730000),
        loadGlb('/models/bike_rider.glb', 'rider', 2468568).catch(() => null),
        loadAiTex(CG160_TEX_URLS.paint, true),
        loadAiTex(CG160_TEX_URLS.alloy, true),
        loadAiTex(CG160_TEX_URLS.dash, false),
        loadAiTex(CG160_TEX_URLS.seat, true),
        loadAiTex(CG160_TEX_URLS.tire, true),
      ]);

    this.mirrorMeshes = [];
    this.mufflerMeshes = [];
    this.paintMaterials = [];
    this.headlightMaterials = [];
    this.headlightGlassMaterials = [];
    this.headlightSpotLight = null;
    this.headlightSpotTarget = null;
    this.headlightHaloSprite = null;
    this.headlightBeamMesh = null;
    this.cg160Nodes = [];

    this.setupCg160Model(cgGltf.scene, { paintTex, alloyTex, dashTex, seatTex, tireTex });
    this.setupRiderModel(riderGltf.scene, helmetGltf?.scene ?? null);
    this.setBikeModel(this.activeBikeModel);
  }

  /**
   * Normalizes cg_160.glb (untextured Sketchfab Honda CG 160 Titan) into BikeRig coordinates
   * and applies AI-generated PBR textures, Titan racing decals, LCD digital dash, and Oficina hooks.
   */
  private setupCg160Model(
    cgScene: THREE.Group,
    aiTex: {
      paintTex: THREE.Texture;
      alloyTex: THREE.Texture;
      dashTex: THREE.Texture;
      seatTex: THREE.Texture;
      tireTex: THREE.Texture;
    }
  ): void {
    this.root.position.set(0, 0, 0);
    this.root.rotation.set(0, 0, 0);
    this.applyBikePivotGeometry('cg_160');
    this.root.updateMatrixWorld(true);

    // Transform Sketchfab CG 160 world coords (+Z forward, +Y up, X centered at -54.8015) into BikeRig meters (+X forward, y=0 ground, rear axle x=-0.658)
    const normWrapper = new THREE.Group();
    const s = 0.267;
    normWrapper.rotation.y = Math.PI / 2;
    normWrapper.scale.setScalar(s);
    normWrapper.position.set(-0.658 - -10.082 * s, -(-7.090) * s, -54.8015 * s);
    normWrapper.add(cgScene);
    normWrapper.updateMatrixWorld(true);

    const worldToNorm = new THREE.Matrix4();
    const makeLocalPosGeo = (meshObj: THREE.Mesh) => {
      meshObj.updateMatrixWorld(true);
      const geo = meshObj.geometry as THREE.BufferGeometry;
      const posAttr = geo.attributes.position as THREE.BufferAttribute | undefined;
      if (!posAttr) return;
      const bikePos = new Float32Array(posAttr.count * 3);
      const v = new THREE.Vector3();
      worldToNorm.copy(meshObj.matrixWorld);
      for (let i = 0; i < posAttr.count; i++) {
        v.fromBufferAttribute(posAttr, i).applyMatrix4(worldToNorm);
        bikePos[i * 3] = v.x;
        bikePos[i * 3 + 1] = v.y;
        bikePos[i * 3 + 2] = v.z;
      }
      geo.setAttribute('aBikePos', new THREE.Float32BufferAttribute(bikePos, 3));
    };

    // Split composite CG 160 meshes cleanly in bike meter coordinates
    const splitCgTriangles = (
      meshName: string,
      predicate: (p: THREE.Vector3) => boolean
    ): THREE.Mesh | null => {
      const target = normWrapper.getObjectByName(meshName) as THREE.Mesh | undefined;
      if (!target || !target.isMesh) return null;
      target.updateMatrixWorld(true);
      const geo = target.geometry as THREE.BufferGeometry;
      const posAttr = geo.attributes.position as THREE.BufferAttribute | undefined;
      const indexAttr = geo.index;
      if (!posAttr || !indexAttr) return null;

      const matW = target.matrixWorld;
      const vA = new THREE.Vector3();
      const vB = new THREE.Vector3();
      const vC = new THREE.Vector3();
      const centroid = new THREE.Vector3();
      const keepIndices: number[] = [];
      const splitIndices: number[] = [];

      for (let i = 0; i < indexAttr.count; i += 3) {
        const ia = indexAttr.getX(i);
        const ib = indexAttr.getX(i + 1);
        const ic = indexAttr.getX(i + 2);
        vA.fromBufferAttribute(posAttr, ia).applyMatrix4(matW);
        vB.fromBufferAttribute(posAttr, ib).applyMatrix4(matW);
        vC.fromBufferAttribute(posAttr, ic).applyMatrix4(matW);
        centroid.copy(vA).add(vB).add(vC).multiplyScalar(1 / 3);
        if (predicate(centroid)) {
          splitIndices.push(ia, ib, ic);
        } else {
          keepIndices.push(ia, ib, ic);
        }
      }
      if (splitIndices.length === 0 || keepIndices.length === 0) return null;

      const compactGeoFromIndices = (
        srcGeo: THREE.BufferGeometry,
        triIndices: number[]
      ): THREE.BufferGeometry => {
        const remap = new Int32Array(srcGeo.attributes.position.count);
        remap.fill(-1);
        const uniqueVerts: number[] = [];
        const newIdx = new Uint32Array(triIndices.length);
        for (let i = 0; i < triIndices.length; i++) {
          const oldV = triIndices[i];
          let mapped = remap[oldV];
          if (mapped === -1) {
            mapped = uniqueVerts.length;
            remap[oldV] = mapped;
            uniqueVerts.push(oldV);
          }
          newIdx[i] = mapped;
        }
        const out = new THREE.BufferGeometry();
        const vCount = uniqueVerts.length;
        for (const [attrName, attr] of Object.entries(srcGeo.attributes)) {
          const itemSize = attr.itemSize;
          const srcArr = attr.array as Float32Array;
          const dstArr = new Float32Array(vCount * itemSize);
          for (let v = 0; v < vCount; v++) {
            const sBase = uniqueVerts[v] * itemSize;
            const dBase = v * itemSize;
            for (let k = 0; k < itemSize; k++) {
              dstArr[dBase + k] = srcArr[sBase + k];
            }
          }
          out.setAttribute(attrName, new THREE.BufferAttribute(dstArr, itemSize));
        }
        out.setIndex(new THREE.BufferAttribute(vCount > 65535 ? newIdx : new Uint16Array(newIdx), 1));
        out.computeBoundingSphere();
        return out;
      };

      const splitGeo = compactGeoFromIndices(geo, splitIndices);
      geo.setIndex(keepIndices);
      geo.computeBoundingSphere();
      const splitMesh = new THREE.Mesh(splitGeo, target.material);
      splitMesh.name = `${meshName}_split_${splitIndices.length}`;
      splitMesh.position.copy(target.position);
      splitMesh.quaternion.copy(target.quaternion);
      splitMesh.scale.copy(target.scale);
      target.parent?.add(splitMesh);
      return splitMesh;
    };

    const cgFrontFenderMesh = splitCgTriangles('Object_20', (p) => p.x > 0.36 && p.y < 0.65);
    const cgHeadMaskMesh = splitCgTriangles('Object_20', (p) => p.x > 0.36 && p.y >= 0.65);
    const cgFrontTireTopMesh = splitCgTriangles('Object_15', (p) => p.y < 0.635 && Math.abs(p.z) < 0.055);
    const cgCaliperMesh = splitCgTriangles(
      'Object_10',
      (p) => p.y < 0.44 && p.x < 0.615 && p.z > 0.035
    );
    const cgFrontChromeForkMesh = splitCgTriangles('Object_21', (p) => p.x > 0.25);
    const cgFrontDiscMesh = splitCgTriangles('Object_24', (p) => p.x > 0.0);
    const cgSeatMesh = splitCgTriangles(
      'Object_12',
      (p) => p.x > -0.68 && p.x < -0.02 && p.y > 0.70 && Math.abs(p.z) < 0.165
    );
    const cgRearFenderMesh = splitCgTriangles(
      'Object_12',
      (p) => p.x < -0.66 && p.y > 0.44 && p.y < 0.80
    );
    const cgSteerStemMesh = splitCgTriangles('Object_12', (p) => p.x > 0.28);
    const cgMufflerTipMesh = splitCgTriangles('Object_7', (p) => p.x < -0.35);
    const cgMirrorHousingR = splitCgTriangles('Object_22', (p) => p.z > 0);
    const cgMirrorGlassR = splitCgTriangles('Object_23', (p) => p.z > 0);

    // Precompute aBikePos attribute on every CG 160 mesh for crisp planar/triplanar AI texturing
    normWrapper.traverse((o: any) => {
      if (o.isMesh) {
        o.castShadow = false;
        o.receiveShadow = false;
        makeLocalPosGeo(o);
      }
    });

    // Helper: install bike-space AI texture + Oficina customization shader on CG 160 materials
    const makeCgTriplanarPaintMat = (isFrontFender = false) => {
      const mat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: 0.20,
        metalness: 0.18,
        envMapIntensity: 1.48,
      });
      mat.userData.__baseRough = 0.20;
      mat.userData.__baseMetal = 0.18;
      mat.userData.__baseClearcoat = 0.90;
      mat.customProgramCacheKey = () => (isFrontFender ? 'cg160_fender_ai_v2' : 'cg160_paint_ai_v2');
      mat.onBeforeCompile = (shader) => {
        shader.uniforms.uAiPaintTex = { value: aiTex.paintTex };
        shader.uniforms.uPaintEnabled = this.bikePaintUniforms.uEnabled;
        shader.uniforms.uPaintColor = this.bikePaintUniforms.uColor;
        shader.uniforms.uFenderMode = this.frontFenderUniforms.uMode;
        shader.uniforms.uFenderColor = this.frontFenderUniforms.uColor;
        shader.uniforms.uCarbonMap = this.frontFenderUniforms.uCarbonMap;
        shader.vertexShader = shader.vertexShader
          .replace('#include <common>', '#include <common>\nattribute vec3 aBikePos;\nvarying vec3 vCgPos;')
          .replace('#include <begin_vertex>', '#include <begin_vertex>\nvCgPos = aBikePos;');
        shader.fragmentShader = shader.fragmentShader
          .replace(
            '#include <common>',
            `#include <common>
uniform sampler2D uAiPaintTex;
uniform float uPaintEnabled;
uniform vec3 uPaintColor;
uniform float uFenderMode;
uniform vec3 uFenderColor;
uniform sampler2D uCarbonMap;
varying vec3 vCgPos;`
          )
          .replace(
            '#include <map_fragment>',
            `#include <map_fragment>
vec2 pUv = vec2(vCgPos.x * 2.2 + vCgPos.z * 0.9, vCgPos.y * 2.2);
vec3 rawPaint = texture2D(uAiPaintTex, pUv).rgb;
vec3 aiRed = rawPaint * rawPaint;
vec3 basePaint = aiRed * 1.15;
if (uPaintEnabled > 0.5) {
  float flake = dot(aiRed, vec3(0.299, 0.587, 0.114));
  basePaint = uPaintColor * clamp(flake * 2.25 + 0.30, 0.20, 1.38);
}
${
  isFrontFender
    ? `if (uFenderMode >= 1.5) {
  vec3 rawCarb = texture2D(uCarbonMap, vCgPos.xz * 18.0).rgb;
  basePaint = (rawCarb * rawCarb) * 0.95;
} else if (uFenderMode > 0.5) {
  float flake = dot(aiRed, vec3(0.299, 0.587, 0.114));
  basePaint = uFenderColor * clamp(flake * 2.25 + 0.30, 0.20, 1.38);
}`
    : `// Honda CG 160 Titan sporty silver / carbon / white wing & tail stripes
float tankZone = smoothstep(0.02, 0.08, vCgPos.x) * (1.0 - smoothstep(0.32, 0.38, vCgPos.x)) * smoothstep(0.085, 0.125, abs(vCgPos.z));
float wingDiag = (vCgPos.y - 0.87) - (vCgPos.x - 0.16) * 0.42;
float silverStripe = tankZone * smoothstep(0.024, 0.014, abs(wingDiag - 0.016));
float darkStripe = tankZone * smoothstep(0.020, 0.010, abs(wingDiag + 0.012));
float whitePin = tankZone * smoothstep(0.006, 0.002, abs(wingDiag - 0.036));
float tailZone = (1.0 - smoothstep(-0.56, -0.45, vCgPos.x)) * smoothstep(0.76, 0.80, vCgPos.y) * smoothstep(0.075, 0.11, abs(vCgPos.z));
float tailLine = tailZone * smoothstep(0.016, 0.008, abs((vCgPos.y - 0.83) - (vCgPos.x + 0.72) * 0.18));
basePaint = mix(basePaint, vec3(0.07, 0.08, 0.10), darkStripe * 0.94);
basePaint = mix(basePaint, vec3(0.76, 0.79, 0.84), clamp(silverStripe + tailLine * 0.85, 0.0, 1.0));
basePaint = mix(basePaint, vec3(0.95, 0.96, 0.98), whitePin);`
}
diffuseColor.rgb = basePaint;`
          );
      };
      this.paintMaterials.push(mat);
      return mat;
    };

    const makeCgTriplanarMat = (
      tex: THREE.Texture,
      cacheKey: string,
      opts: { scale: number; brightness: number; roughness: number; metalness: number; envMapIntensity: number },
      tintUniforms?: { uEnabled: { value: number }; uColor: { value: THREE.Color }; uTitanium?: { value: number } },
      dashOverlay?: THREE.Texture
    ) => {
      const mat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: opts.roughness,
        metalness: opts.metalness,
        envMapIntensity: opts.envMapIntensity,
      });
      mat.customProgramCacheKey = () => cacheKey;
      mat.onBeforeCompile = (shader) => {
        shader.uniforms.uAiTex = { value: tex };
        shader.uniforms.uDashTex = { value: dashOverlay ?? tex };
        shader.uniforms.uTintEnabled = tintUniforms?.uEnabled ?? { value: 0 };
        shader.uniforms.uTintColor = tintUniforms?.uColor ?? { value: new THREE.Color(0xffffff) };
        shader.uniforms.uTitanium = tintUniforms?.uTitanium ?? { value: 0 };
        shader.vertexShader = shader.vertexShader
          .replace('#include <common>', '#include <common>\nattribute vec3 aBikePos;\nvarying vec3 vCgPos;\nvarying vec3 vCgNorm;')
          .replace('#include <begin_vertex>', '#include <begin_vertex>\nvCgPos = aBikePos;\nvCgNorm = normal;');
        shader.fragmentShader = shader.fragmentShader
          .replace(
            '#include <common>',
            `#include <common>
uniform sampler2D uAiTex;
uniform sampler2D uDashTex;
uniform float uTintEnabled;
uniform vec3 uTintColor;
uniform float uTitanium;
varying vec3 vCgPos;
varying vec3 vCgNorm;`
          )
          .replace(
            '#include <map_fragment>',
            `#include <map_fragment>
vec3 nAbs = abs(vCgNorm);
vec2 triUv = (nAbs.x > nAbs.y && nAbs.x > nAbs.z)
  ? vCgPos.zy * ${opts.scale.toFixed(2)}
  : (nAbs.y > nAbs.z ? vCgPos.xz * ${opts.scale.toFixed(2)} : vCgPos.xy * ${opts.scale.toFixed(2)});
vec3 rawTex = texture2D(uAiTex, triUv).rgb;
vec3 texCol = rawTex * rawTex;
vec3 col = texCol * ${opts.brightness.toFixed(2)};
if (uTintEnabled > 0.5) {
  float luma = dot(texCol, vec3(0.299, 0.587, 0.114));
  vec3 tintBase = uTintColor;
  if (uTitanium > 0.5) {
    float wave = sin(vCgPos.x * 26.0 + luma * 10.0) * 0.5 + 0.5;
    tintBase = mix(vec3(0.25, 0.42, 0.95), vec3(0.68, 0.30, 0.88), wave);
  }
  col = tintBase * clamp(luma * 2.1 + 0.18, 0.14, 1.38);
}
${
  dashOverlay
    ? `// Project Honda CG 160 Titan Blackout Digital LCD Screen squarely onto instrument cluster face
float inDash = step(0.285, vCgPos.x) * step(vCgPos.x, 0.395) * step(0.992, vCgPos.y) * step(vCgPos.y, 1.032) * step(abs(vCgPos.z), 0.072);
if (inDash > 0.5) {
  vec2 dUv = vec2((vCgPos.z + 0.068) / 0.136, (vCgPos.x - 0.29) / 0.095);
  vec2 cUv = clamp(dUv, 0.04, 0.96);
  vec3 rawLcd = texture2D(uDashTex, cUv).rgb;
  vec3 lcd = rawLcd * rawLcd;
  col = mix(vec3(0.05, 0.06, 0.08), lcd * 1.45, 0.95);
}`
    : ''
}
diffuseColor.rgb = col;`
          );
      };
      return mat;
    };

    const paintBodyMat = makeCgTriplanarPaintMat(false);
    const paintFenderMat = makeCgTriplanarPaintMat(true);
    const engineMat = makeCgTriplanarMat(aiTex.alloyTex, 'cg160_engine_ai_v1', {
      scale: 3.4,
      brightness: 1.05,
      roughness: 0.36,
      metalness: 0.72,
      envMapIntensity: 1.32,
    });
    const dashMat = makeCgTriplanarMat(
      aiTex.seatTex,
      'cg160_dash_ai_v2',
      { scale: 4.8, brightness: 0.40, roughness: 0.54, metalness: 0.12, envMapIntensity: 0.85 }
    );
    const frameBlackMat = makeCgTriplanarMat(aiTex.seatTex, 'cg160_frame_ai_v1', {
      scale: 5.0,
      brightness: 0.44,
      roughness: 0.60,
      metalness: 0.16,
      envMapIntensity: 0.88,
    });
    const rearFenderMat = makeCgTriplanarMat(aiTex.seatTex, 'cg160_fender_r_ai_v1', {
      scale: 5.0,
      brightness: 0.44,
      roughness: 0.58,
      metalness: 0.12,
      envMapIntensity: 0.85,
    });
    rearFenderMat.customProgramCacheKey = () => 'cg160_rear_fender_custom_v1';
    rearFenderMat.onBeforeCompile = (shader) => {
      shader.uniforms.uAiTex = { value: aiTex.seatTex };
      shader.uniforms.uFenderMode = this.rearFenderUniforms.uMode;
      shader.uniforms.uFenderColor = this.rearFenderUniforms.uColor;
      shader.uniforms.uCarbonMap = this.rearFenderUniforms.uCarbonMap;
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nattribute vec3 aBikePos;\nvarying vec3 vCgPos;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvCgPos = aBikePos;');
      shader.fragmentShader = shader.fragmentShader
        .replace(
          '#include <common>',
          `#include <common>
uniform sampler2D uAiTex;
uniform float uFenderMode;
uniform vec3 uFenderColor;
uniform sampler2D uCarbonMap;
varying vec3 vCgPos;`
        )
        .replace(
          '#include <map_fragment>',
          `#include <map_fragment>
vec3 rawC = texture2D(uAiTex, vCgPos.xz * 5.0).rgb;
vec3 texC = rawC * rawC;
vec3 col = texC * 0.44;
if (uFenderMode > 0.5 && uFenderMode < 1.5) {
  col = uFenderColor * clamp(dot(texC, vec3(0.299,0.587,0.114)) * 2.2 + 0.28, 0.20, 1.32);
} else if (uFenderMode >= 1.5) {
  vec3 rawCarb = texture2D(uCarbonMap, vCgPos.xz * 18.0).rgb;
  col = (rawCarb * rawCarb) * 0.95;
}
diffuseColor.rgb = col;`
        );
    };

    const seatMat = makeCgTriplanarMat(
      aiTex.seatTex,
      'cg160_seat_ai_v1',
      { scale: 4.2, brightness: 0.62, roughness: 0.72, metalness: 0.04, envMapIntensity: 0.65 },
      this.seatUniforms
    );
    const tireMat = makeCgTriplanarMat(aiTex.tireTex, 'cg160_tire_ai_v1', {
      scale: 4.5,
      brightness: 0.42,
      roughness: 0.84,
      metalness: 0.04,
      envMapIntensity: 0.55,
    });
    const wheelRimMat = makeCgTriplanarMat(
      aiTex.alloyTex,
      'cg160_wheel_ai_v1',
      { scale: 4.0, brightness: 0.36, roughness: 0.24, metalness: 0.82, envMapIntensity: 1.55 },
      this.wheelHubUniforms
    );
    const exhaustMat = makeCgTriplanarMat(
      aiTex.alloyTex,
      'cg160_exhaust_ai_v1',
      { scale: 3.8, brightness: 0.92, roughness: 0.26, metalness: 0.84, envMapIntensity: 1.55 },
      this.exhaustUniforms
    );
    const chromeMat = makeCgTriplanarMat(aiTex.alloyTex, 'cg160_chrome_ai_v1', {
      scale: 4.0,
      brightness: 1.75,
      roughness: 0.14,
      metalness: 0.92,
      envMapIntensity: 1.75,
    });
    const caliperMat = makeCgTriplanarMat(
      aiTex.alloyTex,
      'cg160_caliper_ai_v1',
      { scale: 4.0, brightness: 0.65, roughness: 0.32, metalness: 0.65, envMapIntensity: 1.25 },
      this.caliperUniforms
    );
    const headlightMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      emissive: 0xf8fafc,
      emissiveIntensity: 1.35,
      roughness: 0.15,
      metalness: 0.2,
    });
    headlightMat.userData.__baseEmissiveIntensity = 1.35;
    this.headlightMaterials.push(headlightMat);

    const taillightMat = new THREE.MeshStandardMaterial({
      color: 0xcc1111,
      emissive: 0xb91c1c,
      emissiveIntensity: 0.85,
      roughness: 0.16,
      metalness: 0.15,
    });
    const blinkerAmberMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xd97706,
      emissiveIntensity: 0.35,
      roughness: 0.20,
      metalness: 0.1,
    });
    const mirrorGlassMat = new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      roughness: 0.04,
      metalness: 0.98,
      envMapIntensity: 2.0,
      side: THREE.DoubleSide,
    });

    const setMat = (meshObj: THREE.Object3D | null | undefined, mat: THREE.Material) => {
      if (meshObj && (meshObj as THREE.Mesh).isMesh) {
        (meshObj as THREE.Mesh).material = mat;
      }
    };

    // Map AI-textured PBR materials onto every CG 160 part
    setMat(normWrapper.getObjectByName('Object_2'), taillightMat);
    setMat(normWrapper.getObjectByName('Object_3'), blinkerAmberMat);
    setMat(normWrapper.getObjectByName('Object_4'), chromeMat);
    setMat(normWrapper.getObjectByName('Object_5'), dashMat);
    setMat(normWrapper.getObjectByName('Object_6'), engineMat);
    setMat(normWrapper.getObjectByName('Object_7'), exhaustMat);
    setMat(cgMufflerTipMesh, exhaustMat);
    setMat(normWrapper.getObjectByName('Object_8'), wheelRimMat);
    setMat(normWrapper.getObjectByName('Object_9'), headlightMat);
    setMat(normWrapper.getObjectByName('Object_10'), frameBlackMat);
    setMat(cgCaliperMesh, caliperMat);
    setMat(normWrapper.getObjectByName('Object_11'), wheelRimMat);
    setMat(normWrapper.getObjectByName('Object_12'), frameBlackMat);
    setMat(cgSeatMesh, seatMat);
    setMat(cgRearFenderMesh, rearFenderMat);
    setMat(cgSteerStemMesh, frameBlackMat);
    setMat(normWrapper.getObjectByName('Object_13'), frameBlackMat);
    setMat(normWrapper.getObjectByName('Object_14'), frameBlackMat);
    setMat(normWrapper.getObjectByName('Object_15'), frameBlackMat);
    setMat(cgFrontTireTopMesh, tireMat);
    setMat(normWrapper.getObjectByName('Object_16'), tireMat);
    setMat(normWrapper.getObjectByName('Object_17'), tireMat);
    setMat(normWrapper.getObjectByName('Object_18'), tireMat);
    setMat(normWrapper.getObjectByName('Object_19'), headlightMat);
    setMat(normWrapper.getObjectByName('Object_20'), paintBodyMat);
    setMat(cgFrontFenderMesh, paintFenderMat);
    setMat(cgHeadMaskMesh, paintBodyMat);
    setMat(normWrapper.getObjectByName('Object_21'), chromeMat);
    setMat(cgFrontChromeForkMesh, chromeMat);
    setMat(normWrapper.getObjectByName('Object_22'), frameBlackMat);
    setMat(cgMirrorHousingR, frameBlackMat);
    setMat(normWrapper.getObjectByName('Object_23'), mirrorGlassMat);
    setMat(cgMirrorGlassR, mirrorGlassMat);
    setMat(normWrapper.getObjectByName('Object_24'), chromeMat);
    setMat(cgFrontDiscMesh, chromeMat);

    // Track Oficina mirror & exhaust toggles
    const mHousingL = normWrapper.getObjectByName('Object_22');
    const mGlassL = normWrapper.getObjectByName('Object_23');
    if (mHousingL) this.mirrorMeshes.push(mHousingL);
    if (mGlassL) this.mirrorMeshes.push(mGlassL);
    if (cgMirrorHousingR) this.mirrorMeshes.push(cgMirrorHousingR);
    if (cgMirrorGlassR) this.mirrorMeshes.push(cgMirrorGlassR);
    if (cgMufflerTipMesh) this.mufflerMeshes.push(cgMufflerTipMesh);

    // Parent every CG 160 part cleanly into BikeRig's dynamic pivots
    const invPivot = new THREE.Matrix4();
    const localMat = new THREE.Matrix4();
    const attachCgObj = (obj: THREE.Object3D | null | undefined, pivot: THREE.Object3D): THREE.Object3D | null => {
      if (!obj) return null;
      obj.updateMatrixWorld(true);
      const worldMat = obj.matrixWorld.clone();
      this.root.updateMatrixWorld(true);
      invPivot.copy(pivot.matrixWorld).invert();
      localMat.multiplyMatrices(invPivot, worldMat);
      pivot.add(obj);
      obj.matrixAutoUpdate = true;
      localMat.decompose(obj.position, obj.quaternion, obj.scale);
      this.cg160Nodes.push(obj);
      return obj;
    };

    const mergeStaticCgGroup = (
      objs: (THREE.Object3D | null | undefined)[],
      pivot: THREE.Object3D,
      mat: THREE.Material,
      groupName: string
    ): void => {
      this.root.updateMatrixWorld(true);
      invPivot.copy(pivot.matrixWorld).invert();
      const rawGeos: THREE.BufferGeometry[] = [];
      for (const obj of objs) {
        if (!obj || !(obj as THREE.Mesh).isMesh) continue;
        const mesh = obj as THREE.Mesh;
        mesh.updateMatrixWorld(true);
        localMat.multiplyMatrices(invPivot, mesh.matrixWorld);
        const src = mesh.geometry as THREE.BufferGeometry;
        const g = src.clone();
        for (const key of Object.keys(g.attributes)) {
          if (key !== 'position' && key !== 'normal' && key !== 'aBikePos') {
            g.deleteAttribute(key);
          }
        }
        g.applyMatrix4(localMat);
        rawGeos.push(g);
        mesh.parent?.remove(mesh);
        src.dispose();
      }
      if (rawGeos.length === 0) return;
      const allIndexed = rawGeos.every((g) => Boolean(g.index));
      const geos = allIndexed
        ? rawGeos
        : rawGeos.map((g) => {
            if (!g.index) return g;
            const ni = g.toNonIndexed();
            g.dispose();
            return ni;
          });
      const merged = geos.length === 1 ? geos[0] : mergeGeometries(geos, false);
      if (geos.length > 1) {
        for (const g of geos) g.dispose();
      }
      if (!merged) return;
      merged.computeBoundingSphere();
      const mergedMesh = new THREE.Mesh(merged, mat);
      mergedMesh.name = groupName;
      mergedMesh.castShadow = false;
      mergedMesh.receiveShadow = false;
      pivot.add(mergedMesh);
      this.cg160Nodes.push(mergedMesh);
    };

    // Steering / Fork (batch shared static materials to reduce draw calls)
    attachCgObj(normWrapper.getObjectByName('Object_5'), this.steeringHeadPivot);
    mergeStaticCgGroup(
      [normWrapper.getObjectByName('Object_9'), normWrapper.getObjectByName('Object_19')],
      this.steeringHeadPivot,
      headlightMat,
      'CG160_Headlight_Merged'
    );
    const hlMerged = this.steeringHeadPivot.getObjectByName('CG160_Headlight_Merged') as
      | THREE.Mesh
      | undefined;
    const hlCenter = new THREE.Vector3(0.06, 0.04, 0);
    if (hlMerged) {
      hlMerged.geometry.computeBoundingBox();
      hlMerged.geometry.boundingBox?.getCenter(hlCenter);
    }
    const worldFwdInSteer = new THREE.Vector3(
      Math.cos(-this.currentRakeRad),
      Math.sin(-this.currentRakeRad),
      0
    ).normalize();
    const worldDownInSteer = new THREE.Vector3(
      -Math.sin(-this.currentRakeRad),
      Math.cos(-this.currentRakeRad),
      0
    ).normalize();

    const hlSpot = new THREE.SpotLight(
      this.headlightTintHex,
      8.0 * this.headlightLevel,
      32,
      THREE.MathUtils.degToRad(34),
      0.68,
      1.35
    );
    hlSpot.castShadow = false;
    hlSpot.position
      .copy(hlCenter)
      .addScaledVector(worldFwdInSteer, 0.05)
      .addScaledVector(worldDownInSteer, 0.01);
    const hlTarget = new THREE.Object3D();
    hlTarget.position
      .copy(hlSpot.position)
      .addScaledVector(worldFwdInSteer, 11.0)
      .addScaledVector(worldDownInSteer, -1.65);
    this.steeringHeadPivot.add(hlTarget);
    hlSpot.target = hlTarget;
    this.steeringHeadPivot.add(hlSpot);
    this.headlightSpotLight = hlSpot;
    this.headlightSpotTarget = hlTarget;
    this.cg160Nodes.push(hlSpot, hlTarget);

    const haloMat = new THREE.SpriteMaterial({
      map: this.textures.particleGlow,
      color: this.headlightTintHex,
      transparent: true,
      opacity: 0.72 * this.headlightLevel,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const haloSprite = new THREE.Sprite(haloMat);
    haloSprite.name = 'CG160_Headlight_Halo';
    haloSprite.position.copy(hlCenter).addScaledVector(worldFwdInSteer, 0.048);
    haloSprite.scale.setScalar(0.46);
    this.steeringHeadPivot.add(haloSprite);
    this.headlightHaloSprite = haloSprite;
    this.cg160Nodes.push(haloSprite);

    const beamLen = 2.4;
    const beamGeo = new THREE.ConeGeometry(0.48, beamLen, 20, 1, true);
    beamGeo.translate(0, -beamLen * 0.5, 0);
    const beamMat = new THREE.MeshBasicMaterial({
      color: this.headlightTintHex,
      transparent: true,
      opacity: 0.055 * this.headlightLevel,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const beamMesh = new THREE.Mesh(beamGeo, beamMat);
    beamMesh.name = 'CG160_Headlight_Beam';
    beamMesh.position.copy(hlCenter).addScaledVector(worldFwdInSteer, 0.045);
    const coneAim = worldFwdInSteer.clone().addScaledVector(worldDownInSteer, -0.14).normalize();
    beamMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, -1, 0), coneAim);
    this.steeringHeadPivot.add(beamMesh);
    this.headlightBeamMesh = beamMesh;
    this.cg160Nodes.push(beamMesh);
    mergeStaticCgGroup(
      [
        normWrapper.getObjectByName('Object_13'),
        normWrapper.getObjectByName('Object_14'),
        normWrapper.getObjectByName('Object_15'),
        cgSteerStemMesh,
      ],
      this.steeringHeadPivot,
      frameBlackMat,
      'CG160_SteerFrame_Merged'
    );
    // Unfold CG 160 mirrors outward onto handlebar mounts facing backward toward rider
    const leftMirrorPivot = new THREE.Group();
    leftMirrorPivot.name = 'CG160_Mirror_Left';
    leftMirrorPivot.position.set(0.246, 1.074, -0.154);
    this.root.add(leftMirrorPivot);
    leftMirrorPivot.updateMatrixWorld(true);
    attachCgObj(mHousingL, leftMirrorPivot);
    attachCgObj(mGlassL, leftMirrorPivot);
    leftMirrorPivot.rotation.set(0, THREE.MathUtils.degToRad(-88), 0);
    attachCgObj(leftMirrorPivot, this.steeringHeadPivot);

    const rightMirrorPivot = new THREE.Group();
    rightMirrorPivot.name = 'CG160_Mirror_Right';
    rightMirrorPivot.position.set(0.268, 1.087, 0.168);
    this.root.add(rightMirrorPivot);
    rightMirrorPivot.updateMatrixWorld(true);
    attachCgObj(cgMirrorHousingR, rightMirrorPivot);
    attachCgObj(cgMirrorGlassR, rightMirrorPivot);
    rightMirrorPivot.rotation.set(0, THREE.MathUtils.degToRad(88), 0);
    attachCgObj(rightMirrorPivot, this.steeringHeadPivot);

    attachCgObj(cgHeadMaskMesh, this.steeringHeadPivot);
    attachCgObj(cgFrontChromeForkMesh, this.steeringHeadPivot);

    // Front Suspension lower sliders + removable Front Fender
    attachCgObj(normWrapper.getObjectByName('Object_10'), this.forkSlidePivot);
    attachCgObj(cgCaliperMesh, this.forkSlidePivot);
    const cgFenderWrap = new THREE.Group();
    this.forkSlidePivot.add(cgFenderWrap);
    this.root.updateMatrixWorld(true);
    attachCgObj(cgFrontFenderMesh, cgFenderWrap);
    this.cgFrontFenderGroup = cgFenderWrap;
    this.cg160Nodes.push(cgFenderWrap);

    // Front Wheel Spin
    attachCgObj(normWrapper.getObjectByName('Object_8'), this.frontWheelSpinPivot);
    mergeStaticCgGroup(
      [normWrapper.getObjectByName('Object_16'), cgFrontTireTopMesh],
      this.frontWheelSpinPivot,
      tireMat,
      'CG160_FrontTire_Merged'
    );
    attachCgObj(cgFrontDiscMesh, this.frontWheelSpinPivot);

    // Rear Wheel Spin
    attachCgObj(normWrapper.getObjectByName('Object_11'), this.rearWheelSpinPivot);
    mergeStaticCgGroup(
      [normWrapper.getObjectByName('Object_17'), normWrapper.getObjectByName('Object_18')],
      this.rearWheelSpinPivot,
      tireMat,
      'CG160_RearTire_Merged'
    );
    attachCgObj(normWrapper.getObjectByName('Object_24'), this.rearWheelSpinPivot);

    // Rear Swingarm & Fender
    attachCgObj(normWrapper.getObjectByName('Object_21'), this.swingarmPivot);
    this.cgRearFenderGroup = attachCgObj(cgRearFenderMesh, this.chassisPivot);

    // Chassis / Frame / Tank / Engine / Exhaust / Seat / Taillight
    attachCgObj(normWrapper.getObjectByName('Object_2'), this.chassisPivot);
    attachCgObj(normWrapper.getObjectByName('Object_3'), this.chassisPivot);
    attachCgObj(normWrapper.getObjectByName('Object_4'), this.chassisPivot);
    attachCgObj(normWrapper.getObjectByName('Object_6'), this.chassisPivot);
    attachCgObj(normWrapper.getObjectByName('Object_7'), this.chassisPivot);
    attachCgObj(cgMufflerTipMesh, this.chassisPivot);
    attachCgObj(normWrapper.getObjectByName('Object_12'), this.chassisPivot);
    attachCgObj(cgSeatMesh, this.chassisPivot);
    attachCgObj(normWrapper.getObjectByName('Object_20'), this.chassisPivot);

    // Mount live functional Honda CG 160 Titan Blackout Digital LCD cluster inside cockpit
    this.createCg160DashboardModule(attachCgObj);

    // Mount bottle holder bracket on the right front corner of the CG 160 ("canto da moto") within natural reach
    const bottleHolder = WaterBottleDevice.createBikeHolderMesh();
    bottleHolder.position.set(0.185, 0.845, 0.174);
    bottleHolder.rotation.set(0.08, 0, -0.10);
    this.bottleStowAnchor.position.set(0, 0.014, 0);
    bottleHolder.add(this.bottleStowAnchor);
    this.chassisPivot.add(bottleHolder);
    this.cg160Nodes.push(bottleHolder);
  }

  private createCg160DashboardModule(
    attachCgObj: (obj: THREE.Object3D | null | undefined, pivot: THREE.Object3D) => THREE.Object3D | null
  ): void {
    const W = 512;
    const H = 264;
    const CW = 256;
    const CH = 128;
    const canvas = document.createElement('canvas');
    canvas.width = CW;
    canvas.height = CH;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(CW / W, 0, 0, CH / H, 0, 0);

    // Pre-render static Blackout LCD background, borders, scales, and labels once
    const bgCanvas = document.createElement('canvas');
    bgCanvas.width = CW;
    bgCanvas.height = CH;
    const bgCtx = bgCanvas.getContext('2d');
    if (bgCtx) {
      bgCtx.setTransform(CW / W, 0, 0, CH / H, 0, 0);
      const bgGrad = bgCtx.createLinearGradient(0, 0, 0, H);
      bgGrad.addColorStop(0, '#050b16');
      bgGrad.addColorStop(0.55, '#091526');
      bgGrad.addColorStop(1, '#040913');
      bgCtx.fillStyle = bgGrad;
      bgCtx.fillRect(0, 0, W, H);

      bgCtx.strokeStyle = 'rgba(56, 189, 248, 0.28)';
      bgCtx.lineWidth = 2;
      bgCtx.strokeRect(8, 8, W - 16, H - 16);

      // Pre-bake cyan gear indicator box frame & MARCHA label
      bgCtx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      bgCtx.fillRect(W - 96, 118, 72, 86);
      bgCtx.strokeStyle = '#38bdf8';
      bgCtx.lineWidth = 2;
      bgCtx.strokeRect(W - 96, 118, 72, 86);
      bgCtx.fillStyle = 'rgba(186, 230, 253, 0.65)';
      bgCtx.font = 'bold 11px sans-serif';
      bgCtx.textBaseline = 'middle';
      bgCtx.textAlign = 'center';
      bgCtx.fillText('MARCHA', W - 60, 130);

      // Brand header (High-Beam icon is drawn dynamically in updateCg160Dashboard)
      bgCtx.fillStyle = 'rgba(226, 232, 240, 0.85)';
      bgCtx.font = 'bold 14px sans-serif';
      bgCtx.textBaseline = 'middle';
      bgCtx.textAlign = 'center';
      bgCtx.fillText('HONDA  TITAN 160', W * 0.5, 25);

      // Static RPM scale marks (0..11)
      const segCount = 24;
      const barX = 24;
      const barW = W - 48;
      const gap = 3;
      const segW = (barW - gap * (segCount - 1)) / segCount;
      bgCtx.font = 'bold 12px monospace';
      for (let k = 0; k <= 11; k++) {
        const kx = barX + (k / 11) * (barW - segW) + segW * 0.5;
        bgCtx.fillStyle = k >= 10 ? '#f87171' : 'rgba(186, 230, 253, 0.8)';
        bgCtx.fillText(String(k), kx, 94);
      }

      // Static Fuel Gauge (E .. F)
      bgCtx.textAlign = 'left';
      bgCtx.fillStyle = 'rgba(186, 230, 253, 0.75)';
      bgCtx.font = 'bold 13px monospace';
      bgCtx.fillText('F', 24, 126);
      bgCtx.fillText('E', 24, 212);
      for (let f = 0; f < 6; f++) {
        const fy = 136 + f * 12;
        bgCtx.fillStyle = f >= 1 ? '#38bdf8' : 'rgba(56, 189, 248, 0.20)';
        bgCtx.fillRect(40, fy, 18, 8);
      }

      bgCtx.fillStyle = '#38bdf8';
      bgCtx.font = 'bold 20px sans-serif';
      bgCtx.fillText('km/h', W * 0.65, 190);

      bgCtx.strokeStyle = 'rgba(56, 189, 248, 0.22)';
      bgCtx.lineWidth = 1.5;
      bgCtx.beginPath();
      bgCtx.moveTo(22, 224);
      bgCtx.lineTo(W - 22, 224);
      bgCtx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.generateMipmaps = false;
    tex.anisotropy = 1;
    tex.minFilter = THREE.LinearFilter;
    tex.magFilter = THREE.LinearFilter;

    this.cgDashCanvas = canvas;
    this.cgDashBgCanvas = bgCanvas;
    this.cgDashCtx = ctx;
    this.cgDashTexture = tex;
    this.cgDashLastDrawMs = -1000;
    this.cgDashLastGear = -1;
    this.cgDashLastSpeed = -1;
    this.cgDashLastSegs = -1;
    this.cgDashLastShift = -1;
    this.cgDashLastOdo = -1;
    this.cgDashLastRpmTenth = -1;
    this.cgDashLastHeadlight = -1;

    const pod = new THREE.Group();
    pod.name = 'CG160_Live_Digital_Cluster';

    const bezelGeo = new THREE.BoxGeometry(0.132, 0.072, 0.012);
    const bezelMat = new THREE.MeshStandardMaterial({
      color: 0x161920,
      roughness: 0.42,
      metalness: 0.25,
      envMapIntensity: 1.0,
    });
    const bezelMesh = new THREE.Mesh(bezelGeo, bezelMat);
    pod.add(bezelMesh);

    const trimGeo = new THREE.BoxGeometry(0.123, 0.064, 0.013);
    const trimMat = new THREE.MeshStandardMaterial({
      color: 0x4b5563,
      roughness: 0.28,
      metalness: 0.78,
      envMapIntensity: 1.35,
    });
    const trimMesh = new THREE.Mesh(trimGeo, trimMat);
    pod.add(trimMesh);

    const screenGeo = new THREE.PlaneGeometry(0.118, 0.058);
    const screenMat = new THREE.MeshBasicMaterial({
      map: tex,
      toneMapped: false,
    });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.position.z = 0.0072;
    pod.add(screenMesh);

    const xAxis = new THREE.Vector3(0, 0, 1);
    const zAxis = new THREE.Vector3(-0.62, 0.785, 0).normalize();
    const yAxis = new THREE.Vector3().crossVectors(zAxis, xAxis).normalize();
    const basis = new THREE.Matrix4().makeBasis(xAxis, yAxis, zAxis);
    pod.position.set(0.346, 1.028, 0);
    pod.quaternion.setFromRotationMatrix(basis);

    this.root.add(pod);
    this.root.updateMatrixWorld(true);
    attachCgObj(pod, this.steeringHeadPivot);
  }

  private updateCg160Dashboard(physics: BikePhysics, dt: number, isFirstPerson = true): void {
    const ctx = this.cgDashCtx;
    const tex = this.cgDashTexture;
    if (!ctx || !tex) return;

    const speedMs = Math.hypot(physics.vel.x, physics.vel.z);
    this.cgOdometerKm += (speedMs * dt) / 1000;

    const now = performance.now();
    const minInterval = isFirstPerson ? 95 : 350;
    if (
      this.cgDashLastDrawMs > 0 &&
      now - this.cgDashLastDrawMs < minInterval &&
      this.cgDashLastGear === physics.gear
    ) {
      return;
    }

    const W = 512;
    const H = 264;
    const rpmNorm = THREE.MathUtils.clamp(physics.rpm / 11000, 0, 1);
    const speedKmh = Math.round(speedMs * 3.6);
    const segCount = 24;
    const filledSegs = Math.round(rpmNorm * segCount);
    const isNeutral = physics.gear === 0;
    const isHighRpm = physics.rpm >= 9500 || physics.revLimiter;
    const flashOn = Math.floor(now / 90) % 2 === 0;
    const shiftLit = isHighRpm && (!physics.revLimiter || flashOn) ? 1 : 0;
    const odoTenth = Math.round(this.cgOdometerKm * 10);
    const rpmTenth = Math.round(physics.rpm / 200);
    const hlBucket = Math.round(this.headlightLevel * 20);

    if (
      this.cgDashLastDrawMs > 0 &&
      speedKmh === this.cgDashLastSpeed &&
      physics.gear === this.cgDashLastGear &&
      filledSegs === this.cgDashLastSegs &&
      shiftLit === this.cgDashLastShift &&
      odoTenth === this.cgDashLastOdo &&
      rpmTenth === this.cgDashLastRpmTenth &&
      hlBucket === this.cgDashLastHeadlight
    ) {
      return;
    }

    this.cgDashLastDrawMs = now;
    this.cgDashLastGear = physics.gear;
    this.cgDashLastSpeed = speedKmh;
    this.cgDashLastSegs = filledSegs;
    this.cgDashLastShift = shiftLit;
    this.cgDashLastOdo = odoTenth;
    this.cgDashLastRpmTenth = rpmTenth;
    this.cgDashLastHeadlight = hlBucket;

    if (this.cgDashBgCanvas) {
      ctx.drawImage(this.cgDashBgCanvas, 0, 0, W, H);
    } else {
      ctx.fillStyle = '#071020';
      ctx.fillRect(0, 0, W, H);
    }

    ctx.textBaseline = 'middle';

    // Neutral LED
    ctx.fillStyle = isNeutral ? '#22c55e' : 'rgba(34, 197, 94, 0.16)';
    ctx.beginPath();
    ctx.arc(30, 26, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = isNeutral ? '#04120a' : '#2f4538';
    ctx.font = 'bold 15px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('N', 30, 27);

    // Live Headlight Indicator on CG 160 LCD (smoothly dims & glows with headlightLevel)
    const hlAlpha = 0.15 + this.headlightLevel * 0.85;
    ctx.fillStyle = `rgba(56, 189, 248, ${hlAlpha.toFixed(3)})`;
    ctx.fillRect(54, 21, 14, 10);
    ctx.strokeStyle = `rgba(125, 211, 252, ${hlAlpha.toFixed(3)})`;
    ctx.lineWidth = 2;
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath();
      ctx.moveTo(71, 26 + i * 4);
      ctx.lineTo(80, 26 + i * 4);
      ctx.stroke();
    }

    // Right Red Shift / Corte Limiter LED
    ctx.fillStyle = shiftLit ? '#ef4444' : 'rgba(239, 68, 68, 0.18)';
    ctx.beginPath();
    ctx.arc(W - 32, 26, 8, 0, Math.PI * 2);
    ctx.fill();
    if (shiftLit) {
      ctx.fillStyle = '#fca5a5';
      ctx.font = 'bold 12px monospace';
      ctx.textAlign = 'right';
      ctx.fillText('CORTE', W - 48, 27);
    }

    // Segmented RPM Tachometer Bar (0..11k)
    const barX = 24;
    const barY = 50;
    const barW = W - 48;
    const gap = 3;
    const segW = (barW - gap * (segCount - 1)) / segCount;

    for (let i = 0; i < segCount; i++) {
      const ratio = (i + 1) / segCount;
      const sx = barX + i * (segW + gap);
      const segH = 18 + Math.min(1, ratio * 1.15) * 14;
      const sy = barY + (32 - segH);
      const active = i < filledSegs;

      if (!active) {
        ctx.fillStyle = ratio > 0.86 ? 'rgba(239, 68, 68, 0.14)' : 'rgba(56, 189, 248, 0.12)';
      } else if (ratio > 0.88) {
        ctx.fillStyle = physics.revLimiter && !flashOn ? '#991b1b' : '#ef4444';
      } else if (ratio > 0.74) {
        ctx.fillStyle = '#f59e0b';
      } else {
        ctx.fillStyle = '#38bdf8';
      }
      ctx.fillRect(sx, sy, segW, segH);
    }

    // Center Huge Digital Speedometer (km/h)
    ctx.fillStyle = '#f0f9ff';
    ctx.font = 'bold 92px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(String(speedKmh).padStart(2, '0'), W * 0.49, 166);

    // Right Gear Indicator Box (N, 1..5)
    if (isNeutral) {
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2;
      ctx.strokeRect(W - 96, 118, 72, 86);
    }

    ctx.fillStyle = isNeutral ? '#22c55e' : isHighRpm ? '#fbbf24' : '#e0f2fe';
    ctx.font = 'bold 54px monospace';
    ctx.fillText(isNeutral ? 'N' : String(physics.gear), W - 60, 174);

    // Bottom Odometer / RPM Strip
    ctx.fillStyle = '#bae6fd';
    ctx.font = 'bold 15px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`TOTAL  ${this.cgOdometerKm.toFixed(1)} km`, 26, 244);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#7dd3fc';
    ctx.fillText(`${(rpmTenth * 0.2).toFixed(1)}k RPM`, W - 26, 244);

    tex.needsUpdate = true;
  }

  /**
   * Wires bike_rider.glb's native ReadyPlayerMe skeleton (in meters, +Z forward, +Y distal limbs)
   * into BikeRig's bone maps, finger curl chains, 1st-person head collapse, and 2D glove shader.
   */
  private setupRiderModel(riderScene: THREE.Group, helmetScene: THREE.Group | null = null): void {
    this.riderRoot.position.set(0, 0, 0);
    this.riderRoot.rotation.set(0, 0, 0);
    this.riderRoot.scale.setScalar(1);
    this.riderRoot.add(riderScene);
    this.riderRoot.updateMatrixWorld(true);

    this.bones.clear();
    this.restQuats.clear();
    this.restPositions.clear();
    this.boneOffsets.clear();
    this.hairChains = [];
    this.hasHairPrevPos = false;
    this.leftFingerBones = [];
    this.rightFingerBones = [];
    this.firstPersonHeadMeshes = [];
    this.helmetHiddenHairMeshes = [];
    this.defaultShoeMeshes = [];
    this.streetSneakerMeshes = [];
    this.helmetMesh = null;

    if (isCustomTravisSkeleton(riderScene)) {
      this.isCustomRider = true;
      const customL: CustomFingerEntry[] = [];
      const customR: CustomFingerEntry[] = [];
      const rigged = wireCustomTravisRider({
        riderScene,
        bones: this.bones,
        restQuats: this.restQuats,
        restPositions: this.restPositions,
        boneOffsets: this.boneOffsets,
        leftFingerBones: customL,
        rightFingerBones: customR,
        firstPersonHeadMeshes: this.firstPersonHeadMeshes,
        helmetHiddenHairMeshes: this.helmetHiddenHairMeshes,
        hairChains: this.hairChains,
        hideTorsoUniform: this.hideTorsoUniform,
        gloveUniforms: this.gloveUniforms,
        outfitUniforms: this.customOutfitUniforms,
        maxAnisotropy: this.maxAnisotropy,
      });
      this.leftFingerBones = customL;
      this.rightFingerBones = customR;
      this.hipsBone = rigged.hipsBone;
      this.spine2Bone = rigged.spine2Bone;
      this.neckBone = rigged.neckBone;
      this.headBone = rigged.headBone;

      this.restResetList = [];
      for (const [name, q] of this.restQuats) {
        const b = this.bones.get(name);
        const rp = this.restPositions.get(name);
        if (b && rp) {
          this.restResetList.push({ bone: b, quat: q, pos: rp });
        }
      }

      if (helmetScene) {
        const headOff = this.headBone ? this.boneOffsets.get(this.headBone) : undefined;
        const hMesh = extractHelmetForCustomRider(helmetScene, this.headBone, headOff);
        if (hMesh) {
          this.helmetMesh = hMesh;
          this.helmetPivot.clear();
          this.helmetPivot.add(hMesh);
          this.helmetPivot.scale.setScalar(0.96);
          if (this.helmetPivot.parent !== this.scene) {
            this.scene.add(this.helmetPivot);
          }
        }
      }

      this.setGloveStyle(this.currentGloveStyle);
      this.setShoeStyle(this.currentShoeStyle);

      this.riderRoot.rotation.y = Math.PI / 2;
      this.riderRoot.scale.setScalar(0.96);
      this.riderRoot.updateMatrixWorld(true);
      this.setFirstPersonMode(this.lastFpMode ?? true, this.lastOnFootMode ?? false, true);
      return;
    }

    this.isCustomRider = false;

    const trackedPrefixes = [
      'Hips',
      'Spine_',
      'Spine1_',
      'Spine2_',
      'Neck_',
      'Head_',
      'LeftShoulder_',
      'LeftArm_',
      'LeftForeArm_',
      'LeftHand_',
      'RightShoulder_',
      'RightArm_',
      'RightForeArm_',
      'RightHand_',
      'LeftUpLeg_',
      'LeftLeg_',
      'LeftFoot_',
      'RightUpLeg_',
      'RightLeg_',
      'RightFoot_',
    ];

    this.leftFingerBones = [];
    this.rightFingerBones = [];

    const resolveSlot = (name: string): 'thumb' | 'index' | 'middle' | 'ring' | 'pinky' | null => {
      if (name.includes('Thumb')) return 'thumb';
      if (name.includes('Index')) return 'index';
      if (name.includes('Middle')) return 'middle';
      if (name.includes('Ring')) return 'ring';
      if (name.includes('Pinky')) return 'pinky';
      return null;
    };

    const allBones: THREE.Bone[] = [];
    riderScene.traverse((obj: any) => {
      if (obj.isBone) {
        const bone = obj as THREE.Bone;
        allBones.push(bone);
        const name = bone.name || '';
        for (const prefix of trackedPrefixes) {
          if (name.startsWith(prefix) && !this.bones.has(prefix)) {
            this.bones.set(prefix, bone);
            this.restQuats.set(prefix, bone.quaternion.clone());
            this.restPositions.set(prefix, bone.position.clone());
          }
        }

        // Collect all 5 finger chains (proximal/intermediate/distal) for real gestures & grips
        const isProximal = /1_/.test(name);
        const isMiddle = /2_/.test(name);
        const isDistal = /3_/.test(name);
        const weight = isProximal ? 0.72 : isMiddle ? 1.05 : isDistal ? 0.85 : 0;
        const slot = resolveSlot(name);
        if (weight > 0 && slot) {
          const isLeft = name.startsWith('LeftHand');
          const isRight = name.startsWith('RightHand');
          if (isLeft || isRight) {
            const straight = new THREE.Quaternion();
            if (slot === 'thumb') {
              const sign = isLeft ? 1 : -1;
              straight.setFromEuler(
                new THREE.Euler(isProximal ? 0.08 : 0.0, 0, sign * (isProximal ? 0.62 : -0.10), 'XYZ')
              );
            } else {
              straight.identity();
            }
            const entry = {
              bone,
              rest: bone.quaternion.clone(),
              straight,
              weight,
              isProximal,
              slot,
            };
            if (isLeft) this.leftFingerBones.push(entry);
            else this.rightFingerBones.push(entry);
          }
        }
      }
    });

    this.hipsBone = this.bones.get('Hips') ?? null;
    this.spine2Bone = this.bones.get('Spine2_') ?? null;
    this.neckBone = this.bones.get('Neck_') ?? null;
    this.headBone = this.bones.get('Head_') ?? null;

    this.restResetList = [];
    for (const [name, q] of this.restQuats) {
      const b = this.bones.get(name);
      const rp = this.restPositions.get(name);
      if (b && rp) {
        this.restResetList.push({ bone: b, quat: q, pos: rp });
      }
    }

    const handBoneIndices = new Set<number>();
    const torsoBoneIndices = new Set<number>();
    const neckHeadBoneIndices = new Set<number>();
    const limbBoneIndices = new Set<number>();
    const posVec = new THREE.Vector3();
    this.firstPersonHeadMeshes = [];
    this.helmetHiddenHairMeshes = [];
    this.defaultShoeMeshes = [];
    this.streetSneakerMeshes = [];
    let skinHeadMesh: THREE.Mesh | null = null;
    riderScene.traverse((obj: any) => {
      if (!obj.isMesh || skinHeadMesh) return;
      const mn = Array.isArray(obj.material) ? obj.material[0]?.name || '' : obj.material?.name || '';
      if (mn.includes('Wolf3D_Skin')) skinHeadMesh = obj as THREE.Mesh;
    });
    const sampledSkinRgb = sampleSkinRgbFromMesh(skinHeadMesh);
    this.gloveUniforms.uSkinBaseColor.value
      .setRGB(sampledSkinRgb[0] / 255, sampledSkinRgb[1] / 255, sampledSkinRgb[2] / 255)
      .convertSRGBToLinear();
    this.gloveUniforms.uBareHandMap.value = createSkinTexture(sampledSkinRgb, this.maxAnisotropy);

    let outfitFootwearMesh: THREE.SkinnedMesh | null = null;

    riderScene.traverse((obj: any) => {
      if (!obj.isMesh) return;
      obj.castShadow = false;
      obj.receiveShadow = false;
      obj.frustumCulled = false;

      const matName = Array.isArray(obj.material)
        ? obj.material[0]?.name || ''
        : obj.material?.name || '';

      if (matName.includes('Wolf3D_Headwear')) {
        if (obj.isSkinnedMesh && obj.skeleton && this.headBone && !this.helmetMesh) {
          obj.updateMatrixWorld(true);
          const headIdx = obj.skeleton.bones.indexOf(this.headBone);
          const bakeMat = new THREE.Matrix4();
          if (headIdx >= 0 && obj.skeleton.boneInverses[headIdx]) {
            bakeMat.multiplyMatrices(obj.skeleton.boneInverses[headIdx], obj.bindMatrix);
          }
          const helmetGeo = (obj.geometry as THREE.BufferGeometry).clone();
          helmetGeo.applyMatrix4(bakeMat);
          helmetGeo.computeBoundingBox();
          helmetGeo.computeBoundingSphere();

          const srcMat = Array.isArray(obj.material) ? obj.material[0] : obj.material;
          const helmetMat = (
            srcMat ? srcMat.clone() : new THREE.MeshStandardMaterial({ color: 0x18181b })
          ) as THREE.MeshStandardMaterial;
          helmetMat.side = THREE.DoubleSide;
          helmetMat.envMapIntensity = 1.05;

          this.helmetMesh = new THREE.Mesh(helmetGeo, helmetMat);
          this.helmetMesh.name = 'Rider_Detachable_Helmet';
          this.helmetMesh.castShadow = false;
          this.helmetMesh.receiveShadow = false;
          this.helmetMesh.frustumCulled = false;
          this.helmetPivot.clear();
          this.helmetPivot.add(this.helmetMesh);
          this.helmetPivot.scale.setScalar(0.96);
          if (this.helmetPivot.parent !== this.scene) {
            this.scene.add(this.helmetPivot);
          }
        }
        obj.visible = false;
        return;
      }

      if (
        matName.includes('Wolf3D_Head') ||
        matName.includes('Wolf3D_Hair') ||
        matName.includes('Wolf3D_Beard') ||
        matName.includes('Wolf3D_Glasses') ||
        matName.includes('Wolf3D_Eye') ||
        matName.includes('Wolf3D_Teeth')
      ) {
        this.firstPersonHeadMeshes.push(obj);
      }

      if (obj.isSkinnedMesh && obj.skeleton) {
        handBoneIndices.clear();
        torsoBoneIndices.clear();
        neckHeadBoneIndices.clear();
        limbBoneIndices.clear();
        obj.skeleton.bones.forEach((b: THREE.Bone, idx: number) => {
          const bn = b.name || '';
          if (bn.startsWith('LeftHand') || bn.startsWith('RightHand')) {
            handBoneIndices.add(idx);
          }
          if (bn.startsWith('Neck') || bn.startsWith('Head') || bn.includes('Eye')) {
            neckHeadBoneIndices.add(idx);
          }
          if (
            bn.startsWith('Spine') ||
            bn.startsWith('Neck') ||
            bn.startsWith('Head') ||
            bn.includes('Eye') ||
            bn.startsWith('LeftShoulder') ||
            bn.startsWith('RightShoulder') ||
            bn.startsWith('Hips')
          ) {
            torsoBoneIndices.add(idx);
          }
          if (
            bn.startsWith('LeftArm') ||
            bn.startsWith('LeftForeArm') ||
            bn.startsWith('LeftHand') ||
            bn.startsWith('RightArm') ||
            bn.startsWith('RightForeArm') ||
            bn.startsWith('RightHand') ||
            bn.startsWith('LeftUpLeg') ||
            bn.startsWith('LeftLeg') ||
            bn.startsWith('LeftFoot') ||
            bn.startsWith('LeftToe') ||
            bn.startsWith('RightUpLeg') ||
            bn.startsWith('RightLeg') ||
            bn.startsWith('RightFoot') ||
            bn.startsWith('RightToe')
          ) {
            limbBoneIndices.add(idx);
          }
        });

        const geo = obj.geometry as THREE.BufferGeometry;
        const posAttr = geo.attributes.position as THREE.BufferAttribute | undefined;
        const normAttr = geo.attributes.normal as THREE.BufferAttribute | undefined;
        const skinIdxAttr = geo.attributes.skinIndex as THREE.BufferAttribute | undefined;
        const skinWtAttr = geo.attributes.skinWeight as THREE.BufferAttribute | undefined;

        if (posAttr && skinIdxAttr && skinWtAttr) {
          const count = posAttr.count;
          const gloveData = new Float32Array(count * 4);
          const bareHandData = new Float32Array(count * 4);
          const torsoMask = new Float32Array(count * 2);
          let hasHandVerts = false;
          let hasTorsoVerts = false;

          for (let i = 0; i < count; i++) {
            let handWeight = 0;
            let tWeight = 0;
            let nhWeight = 0;
            let lWeight = 0;
            for (let k = 0; k < 4; k++) {
              const bIdx = skinIdxAttr.getComponent(i, k);
              const wt = skinWtAttr.getComponent(i, k);
              if (handBoneIndices.has(bIdx)) handWeight += wt;
              if (torsoBoneIndices.has(bIdx)) tWeight += wt;
              if (neckHeadBoneIndices.has(bIdx)) nhWeight += wt;
              if (limbBoneIndices.has(bIdx)) lWeight += wt;
            }
            posVec.fromBufferAttribute(posAttr, i);
            if (tWeight > 0.35 && lWeight < 0.45) {
              torsoMask[i * 2] = 1.0;
              hasTorsoVerts = true;
            }
            // Trim neck, head, and pinched central collar ring for clean 1st-person on-foot view
            if (
              nhWeight > 0.04 ||
              (tWeight > 0.35 && lWeight < 0.45 && posVec.y > 1.425 && Math.abs(posVec.x) < 0.145)
            ) {
              torsoMask[i * 2 + 1] = 1.0;
              hasTorsoVerts = true;
            }
            if (handWeight > 0.25) {
              hasHandVerts = true;
              const ax = Math.abs(posVec.x);
              const gMask = smoothstep(0.25, 0.72, handWeight);
              const gU = (ax - 0.42) * 5.0;
              const gV = (posVec.z - 0.02) * 8.0;
              let gZone = 0.0;
              if (handWeight < 0.65) {
                gZone = 0.35; // Wrist cuff
              } else if (ax > 0.46 && ax < 0.51 && posVec.y < 1.06) {
                gZone = 0.85; // Carbon knuckle bridge
              }
              gloveData[i * 4] = gMask;
              gloveData[i * 4 + 1] = gU;
              gloveData[i * 4 + 2] = gV;
              gloveData[i * 4 + 3] = gZone;

              // Bare hand coordinates for true skin hands when Sem Luva is active
              const nx = normAttr ? normAttr.getX(i) : Math.sign(posVec.x);
              const signX = posVec.x >= 0 ? 1 : -1;
              const alongHand = THREE.MathUtils.clamp((1.065 - posVec.y) / 0.172, 0, 1);
              const isDorsal = smoothstep(-0.22, 0.34, signX * nx);
              const sideU = (posVec.z - 0.02) * 4.5 + 0.5;
              // Keep jacket cuff intact while exposing clean bare hand from wrist distally
              const bareMask = smoothstep(0.50, 0.72, handWeight);
              bareHandData[i * 4] = alongHand;
              bareHandData[i * 4 + 1] = isDorsal;
              bareHandData[i * 4 + 2] = sideU;
              bareHandData[i * 4 + 3] = bareMask;
            }
          }

          if (hasTorsoVerts) {
            geo.setAttribute('aTorsoMask', new THREE.Float32BufferAttribute(torsoMask, 2));
          }

          if (hasHandVerts) {
            geo.setAttribute('aGloveData', new THREE.Float32BufferAttribute(gloveData, 4));
            geo.setAttribute('aBareHandData', new THREE.Float32BufferAttribute(bareHandData, 4));
            const baseMat = Array.isArray(obj.material) ? obj.material[0] : obj.material;
            const cloned = baseMat.clone() as THREE.MeshStandardMaterial;
            cloned.envMapIntensity = 0.85;
            cloned.customProgramCacheKey = () => 'rider_glove_torso_v4';
            cloned.onBeforeCompile = (shader) => {
              shader.uniforms.uGloveEnabled = this.gloveUniforms.uGloveEnabled;
              shader.uniforms.uGlovePrimary = this.gloveUniforms.uGlovePrimary;
              shader.uniforms.uGloveAccent = this.gloveUniforms.uGloveAccent;
              shader.uniforms.uGloveMap = this.gloveUniforms.uGloveMap;
              shader.uniforms.uCarbonMap = this.gloveUniforms.uCarbonMap;
              shader.uniforms.uBareHandMap = this.gloveUniforms.uBareHandMap;
              shader.uniforms.uHideTorso = this.hideTorsoUniform;

              shader.vertexShader = shader.vertexShader
                .replace(
                  '#include <common>',
                  '#include <common>\nattribute vec4 aGloveData;\nattribute vec4 aBareHandData;\nattribute vec2 aTorsoMask;\nvarying vec4 vGloveData;\nvarying vec4 vBareHandData;\nvarying vec2 vTorsoMask;'
                )
                .replace(
                  '#include <begin_vertex>',
                  '#include <begin_vertex>\nvGloveData = aGloveData;\nvBareHandData = aBareHandData;\nvTorsoMask = aTorsoMask;'
                );

              shader.fragmentShader = shader.fragmentShader
                .replace(
                  '#include <common>',
                  `#include <common>
uniform float uGloveEnabled;
uniform float uHideTorso;
uniform vec3 uGlovePrimary;
uniform vec3 uGloveAccent;
uniform sampler2D uGloveMap;
uniform sampler2D uCarbonMap;
uniform sampler2D uBareHandMap;
varying vec4 vGloveData;
varying vec4 vBareHandData;
varying vec2 vTorsoMask;`
                )
                .replace(
                  '#include <map_fragment>',
                  `#include <map_fragment>
if ((uHideTorso > 0.5 && uHideTorso < 1.5 && vTorsoMask.x > 0.5) || (uHideTorso >= 1.5 && vTorsoMask.y > 0.5)) discard;
if (uGloveEnabled > 0.5 && vGloveData.x > 0.01) {
  float gMask = smoothstep(0.05, 0.95, vGloveData.x);
  vec2 gUv = vec2(vGloveData.y * 1.45, vGloveData.z * 0.55 + 0.5);
  vec3 rawG = texture2D(uGloveMap, gUv).rgb;
  vec3 aiTex = rawG * rawG;
  vec3 rawC = texture2D(uCarbonMap, gUv * 2.5).rgb;
  vec3 carbTex = rawC * rawC;

  float isCuff = smoothstep(0.15, 0.45, vGloveData.w) * (1.0 - smoothstep(0.55, 0.75, vGloveData.w));
  float isKnuckle = smoothstep(0.65, 0.92, vGloveData.w);

  vec3 leatherColor = aiTex * uGlovePrimary * 1.68;
  vec3 cuffColor = aiTex * uGloveAccent * 1.50;
  vec3 knuckleColor = mix(carbTex * 0.75, uGloveAccent * 0.45, 0.22);

  vec3 gloveCol = mix(leatherColor, cuffColor, isCuff);
  gloveCol = mix(gloveCol, knuckleColor, isKnuckle);
  diffuseColor.rgb = mix(diffuseColor.rgb, gloveCol, gMask);
} else if (uGloveEnabled <= 0.5 && vBareHandData.w > 0.01) {
  // True bare human hand ("Sem Luva"): replace baked GLB black glove with character skin
  float along = vBareHandData.x;
  float dorsal = vBareHandData.y;
  vec2 bUv = vec2(fract(vBareHandData.z * 0.75 + 0.25), clamp(0.15 + along * 0.75, 0.02, 0.98));
  vec3 skinTexCol = texture2D(uBareHandMap, bUv).rgb;
  vec3 palmShade = mix(skinTexCol * vec3(1.09, 1.01, 0.98), skinTexCol, dorsal);
  float knuckleBand = exp(-pow((along - 0.44) / 0.085, 2.0)) * dorsal;
  palmShade = mix(palmShade, skinTexCol * vec3(1.03, 0.87, 0.82), knuckleBand * 0.48);
  float jointCrease = smoothstep(0.55, 0.98, sin((along - 0.42) * 32.0)) * smoothstep(0.42, 0.65, along);
  palmShade *= (1.0 - jointCrease * 0.065);
  float nailMask = smoothstep(0.84, 0.95, along) * smoothstep(0.55, 0.88, dorsal);
  vec3 nailCol = skinTexCol * vec3(1.16, 1.10, 1.07) + vec3(0.035, 0.026, 0.025);
  vec3 bareHandCol = mix(palmShade, nailCol, nailMask * 0.58);
  diffuseColor.rgb = mix(diffuseColor.rgb, bareHandCol, vBareHandData.w);
}`
                )
                .replace(
                  '#include <normal_fragment_maps>',
                  `vec3 bareGeoNormal = normal;
#include <normal_fragment_maps>
if (uGloveEnabled <= 0.5 && vBareHandData.w > 0.01) {
  normal = normalize(mix(normal, bareGeoNormal, vBareHandData.w * 0.94));
}`
                )
                .replace(
                  '#include <roughnessmap_fragment>',
                  `#include <roughnessmap_fragment>
if (uGloveEnabled > 0.5 && vGloveData.x > 0.01) {
  roughnessFactor = mix(roughnessFactor, 0.44, vGloveData.x);
} else if (uGloveEnabled <= 0.5 && vBareHandData.w > 0.01) {
  roughnessFactor = mix(roughnessFactor, 0.64, vBareHandData.w);
}`
                )
                .replace(
                  '#include <metalnessmap_fragment>',
                  `#include <metalnessmap_fragment>
if (uGloveEnabled <= 0.5 && vBareHandData.w > 0.01) {
  metalnessFactor = mix(metalnessFactor, 0.02, vBareHandData.w);
}`
                );
            };
            obj.material = cloned;
            return;
          }

          if (hasTorsoVerts) {
            const baseMat = Array.isArray(obj.material) ? obj.material[0] : obj.material;
            const cloned = baseMat.clone() as THREE.MeshStandardMaterial;
            cloned.envMapIntensity = 0.85;
            cloned.customProgramCacheKey = () => 'rider_torso_hide_v2';
            cloned.onBeforeCompile = (shader) => {
              shader.uniforms.uHideTorso = this.hideTorsoUniform;
              shader.vertexShader = shader.vertexShader
                .replace('#include <common>', '#include <common>\nattribute vec2 aTorsoMask;\nvarying vec2 vTorsoMask;')
                .replace('#include <begin_vertex>', '#include <begin_vertex>\nvTorsoMask = aTorsoMask;');
              shader.fragmentShader = shader.fragmentShader
                .replace('#include <common>', '#include <common>\nuniform float uHideTorso;\nvarying vec2 vTorsoMask;')
                .replace('#include <map_fragment>', '#include <map_fragment>\nif ((uHideTorso > 0.5 && uHideTorso < 1.5 && vTorsoMask.x > 0.5) || (uHideTorso >= 1.5 && vTorsoMask.y > 0.5)) discard;');
            };
            obj.material = cloned;
            return;
          }
        }
      }

      if (matName.includes('Wolf3D_Outfit_Footwear') || obj.name === 'Object_4') {
        if (!outfitFootwearMesh && obj.isSkinnedMesh) {
          outfitFootwearMesh = obj as THREE.SkinnedMesh;
        }
      }

      const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
      for (const m of mats) {
        if (m) (m as any).envMapIntensity = 0.85;
      }
    });

    if (outfitFootwearMesh) {
      this.defaultShoeMeshes.push(outfitFootwearMesh);
      const sneakers = buildStreetSneakerMesh(outfitFootwearMesh, this.maxAnisotropy);
      const parentObj = (outfitFootwearMesh as THREE.Object3D).parent ?? riderScene;
      parentObj.add(sneakers.mesh);
      this.streetSneakerMeshes.push(sneakers.mesh);
    }

    this.setGloveStyle(this.currentGloveStyle);
    this.setShoeStyle(this.currentShoeStyle);

    // Apply riding orientation (+Z forward -> +X bike forward) & scale ONLY after wiring!
    this.riderRoot.rotation.y = Math.PI / 2;
    this.riderRoot.scale.setScalar(0.96);
    this.riderRoot.updateMatrixWorld(true);
    this.setFirstPersonMode(this.lastFpMode ?? true, this.lastOnFootMode ?? false, true);
  }

  public isHeadlightOn(): boolean {
    return this.headlightOn;
  }

  public getHeadlightLevel(): number {
    return this.headlightLevel;
  }

  public setHeadlightOn(on: boolean, instant = false): void {
    this.headlightOn = on;
    if (instant) {
      this.headlightPhase = on ? 1.0 : 0.0;
      this.headlightLevel = this.headlightPhase;
      this.applyHeadlightVisuals();
    }
  }

  private applyHeadlightVisuals(): void {
    const lvl = this.headlightLevel;
    this.headlightOnColor.setHex(this.headlightTintHex);
    this.headlightBlendColor.copy(this.headlightOffColor).lerp(this.headlightOnColor, lvl);

    for (const m of this.headlightMaterials) {
      if (m.emissive) {
        m.emissive.copy(this.headlightOnColor);
        const maxEm = this.customization.headlightTint === 'white'
          ? (m.userData.__baseEmissiveIntensity ?? 1.35)
          : this.headlightTargetEmissive;
        m.emissiveIntensity = maxEm * lvl;
      }
      m.color.copy(this.headlightBlendColor);
    }
    for (const m of this.headlightGlassMaterials) {
      const targetGlass = this.customization.headlightTint === 'white' ? 0xcccccc : this.headlightTintHex;
      this.headlightOnColor.setHex(targetGlass);
      m.color.copy(this.headlightOffColor).lerp(this.headlightOnColor, lvl);
    }

    if (this.headlightSpotLight) {
      this.headlightSpotLight.visible = lvl > 0.004;
      this.headlightSpotLight.color.setHex(this.headlightTintHex);
      this.headlightSpotLight.intensity = 8.0 * lvl;
    }
    if (this.headlightHaloSprite) {
      const mat = this.headlightHaloSprite.material as THREE.SpriteMaterial;
      this.headlightHaloSprite.visible = lvl > 0.004;
      mat.color.setHex(this.headlightTintHex);
      mat.opacity = 0.72 * lvl;
      const haloScale = 0.24 + 0.24 * lvl;
      this.headlightHaloSprite.scale.setScalar(haloScale);
    }
    if (this.headlightBeamMesh) {
      const mat = this.headlightBeamMesh.material as THREE.MeshBasicMaterial;
      this.headlightBeamMesh.visible = lvl > 0.004;
      mat.color.setHex(this.headlightTintHex);
      mat.opacity = (this.headlightIsFpView ? 0.022 : 0.055) * lvl;
    }
  }

  private updateHeadlightFade(dt: number, isFirstPerson: boolean): void {
    this.headlightIsFpView = isFirstPerson;
    const target = this.headlightOn ? 1.0 : 0.0;
    if (Math.abs(this.headlightPhase - target) > 1e-4) {
      const step = Math.max(0, dt) * 2.65; // ~0.38s smooth fade-in / fade-out
      if (this.headlightPhase < target) {
        this.headlightPhase = Math.min(target, this.headlightPhase + step);
      } else {
        this.headlightPhase = Math.max(target, this.headlightPhase - step);
      }
      this.headlightLevel = smoothstep(0, 1, this.headlightPhase);
      this.applyHeadlightVisuals();
    } else if (this.headlightBeamMesh) {
      const mat = this.headlightBeamMesh.material as THREE.MeshBasicMaterial;
      mat.opacity = (isFirstPerson ? 0.022 : 0.055) * this.headlightLevel;
    }
  }

  public setShoeStyle(style: RiderShoeStyle): void {
    this.currentShoeStyle = style;
    if (this.isCustomRider) {
      syncCustomOutfitUniforms(this.customOutfitUniforms, this.currentShoeStyle);
      return;
    }
    const showNewSneaker = style === 'street_sneaker';
    for (const m of this.defaultShoeMeshes) {
      m.visible = !showNewSneaker;
    }
    for (const m of this.streetSneakerMeshes) {
      m.visible = showNewSneaker;
    }
  }

  public setGloveStyle(style: GloveStyle): void {
    this.currentGloveStyle = style;
    const visible = style !== 'none';
    this.gloveUniforms.uGloveEnabled.value = visible ? 1.0 : 0.0;
    if (!visible) return;

    if (style === 'black') {
      this.gloveUniforms.uGlovePrimary.value.setHex(0x3d424d);
      this.gloveUniforms.uGloveAccent.value.setHex(0x6b7280);
    } else if (style === 'red') {
      this.gloveUniforms.uGlovePrimary.value.setHex(0xdc2626);
      this.gloveUniforms.uGloveAccent.value.setHex(0x2d313a);
    } else if (style === 'white') {
      this.gloveUniforms.uGlovePrimary.value.setHex(0xf3f5f8);
      this.gloveUniforms.uGloveAccent.value.setHex(0xdc2626);
    }
  }

  public setCustomization(custom: BikeCustomization): void {
    this.customization = { ...custom };

    const paintHexMap: Record<BikeCustomization['paintColor'], number> = {
      titan_red: 0xd91e18,
      black: 0x16181e,
      white: 0xf1f4f9,
      blue: 0x1d4ed8,
      green: 0x16a34a,
      yellow: 0xeab308,
      purple: 0x7e22ce,
      nardo_gray: 0x64748b,
    };
    const paintHex = paintHexMap[custom.paintColor];
    this.bikePaintUniforms.uEnabled.value = custom.paintColor === 'titan_red' ? 0.0 : 1.0;
    this.bikePaintUniforms.uColor.value.setHex(paintHex);

    for (const m of this.paintMaterials) {
      if (custom.paintFinish === 'matte') {
        m.roughness = 0.62;
        m.metalness = 0.08;
        if ('clearcoat' in m) (m as any).clearcoat = 0.06;
        m.envMapIntensity = 0.85;
      } else if (custom.paintFinish === 'chrome') {
        m.roughness = 0.08;
        m.metalness = 0.88;
        if ('clearcoat' in m) (m as any).clearcoat = 0.95;
        m.envMapIntensity = 1.75;
      } else {
        m.roughness = m.userData.__baseRough ?? 0.25;
        m.metalness = m.userData.__baseMetal ?? 0.12;
        if ('clearcoat' in m) (m as any).clearcoat = Math.max(m.userData.__baseClearcoat ?? 0.82, 0.86);
        m.envMapIntensity = 1.38;
      }
    }

    const wheelHexMap: Record<BikeCustomization['wheelColor'], number> = {
      original: 0x1f2229,
      gold: 0xd9a11b,
      red: 0xdc2626,
      white: 0xf1f5f9,
      blue: 0x2563eb,
      bronze: 0x92400e,
      chrome: 0xd4dae3,
    };
    this.wheelHubUniforms.uEnabled.value = custom.wheelColor === 'original' ? 0.0 : 1.0;
    this.wheelHubUniforms.uColor.value.setHex(wheelHexMap[custom.wheelColor]);

    // Exhaust styling & muffler removal ("shorty" / Só o Cano)
    const isShorty = custom.exhaustStyle === 'shorty';
    for (const mesh of this.mufflerMeshes) {
      mesh.visible = !isShorty;
    }
    if (custom.exhaustStyle === 'original') {
      this.exhaustUniforms.uEnabled.value = 0.0;
      this.exhaustUniforms.uTitanium.value = 0.0;
    } else if (custom.exhaustStyle === 'titanium') {
      this.exhaustUniforms.uEnabled.value = 1.0;
      this.exhaustUniforms.uTitanium.value = 1.0;
      this.exhaustUniforms.uColor.value.setHex(0x6366f1);
    } else if (custom.exhaustStyle === 'black') {
      this.exhaustUniforms.uEnabled.value = 1.0;
      this.exhaustUniforms.uTitanium.value = 0.0;
      this.exhaustUniforms.uColor.value.setHex(0x1e2028);
    } else if (custom.exhaustStyle === 'gold') {
      this.exhaustUniforms.uEnabled.value = 1.0;
      this.exhaustUniforms.uTitanium.value = 0.0;
      this.exhaustUniforms.uColor.value.setHex(0xd4a024);
    } else {
      // shorty: raw brushed stainless pipe tint
      this.exhaustUniforms.uEnabled.value = 1.0;
      this.exhaustUniforms.uTitanium.value = 0.0;
      this.exhaustUniforms.uColor.value.setHex(0xb4bcc8);
    }

    // Fenders (front & rear)
    if (this.cgFrontFenderGroup) {
      this.cgFrontFenderGroup.visible = custom.frontFender !== 'hidden';
    }
    this.frontFenderUniforms.uMode.value =
      custom.frontFender === 'paint' ? 1.0 : custom.frontFender === 'carbon' ? 2.0 : 0.0;
    this.frontFenderUniforms.uColor.value.setHex(paintHex);

    if (this.cgRearFenderGroup) {
      this.cgRearFenderGroup.visible = custom.rearFender !== 'hidden';
    }
    this.rearFenderUniforms.uMode.value =
      custom.rearFender === 'paint' ? 1.0 : custom.rearFender === 'carbon' ? 2.0 : 0.0;
    this.rearFenderUniforms.uColor.value.setHex(paintHex);

    // Mirrors
    const showMirrors = custom.mirrors === 'stock';
    for (const mesh of this.mirrorMeshes) {
      mesh.visible = showMirrors;
    }

    // Seat
    const seatHexMap: Record<BikeCustomization['seatColor'], number> = {
      black: 0x1b1d22,
      red: 0xb91c1c,
      brown: 0x7c3f1d,
      white: 0xe2e8f0,
    };
    this.seatUniforms.uEnabled.value = custom.seatColor === 'black' ? 0.0 : 1.0;
    this.seatUniforms.uColor.value.setHex(seatHexMap[custom.seatColor]);

    // Headlight DRL / tint
    const headHexMap: Record<BikeCustomization['headlightTint'], number> = {
      white: 0xf8fafc,
      yellow: 0xfacc15,
      blue: 0x38bdf8,
      red: 0xef4444,
    };
    this.headlightTintHex = headHexMap[custom.headlightTint];
    this.headlightTargetEmissive = custom.headlightTint === 'white' ? 1.35 : 2.1;
    this.applyHeadlightVisuals();

    // Brake Calipers
    const caliperHexMap: Record<BikeCustomization['caliperColor'], number> = {
      original: 0x2d313a,
      red: 0xdc2626,
      gold: 0xd9a11b,
      green: 0x22c55e,
      blue: 0x2563eb,
    };
    this.caliperUniforms.uEnabled.value = custom.caliperColor === 'original' ? 0.0 : 1.0;
    this.caliperUniforms.uColor.value.setHex(caliperHexMap[custom.caliperColor]);
  }

  private findBone(name: string): THREE.Bone | undefined {
    return this.bones.get(name);
  }

  public setFirstPersonMode(isFirstPerson: boolean, isOnFoot = false, force = false): void {
    if (!force && this.lastFpMode === isFirstPerson && this.lastOnFootMode === isOnFoot) {
      if (this.helmetAnimating) {
        this.syncHelmetVisibility(isFirstPerson);
      }
      return;
    }
    this.lastFpMode = isFirstPerson;
    this.lastOnFootMode = isOnFoot;
    const s = isFirstPerson ? 0.0001 : 1;
    if (this.neckBone) {
      this.neckBone.scale.setScalar(s);
    }
    if (this.headBone) {
      this.headBone.scale.setScalar(s);
    }
    // 0 = 3rd-person, 1 = 1st-person mounted (hide full torso), 2 = 1st-person on-foot (hide neck/collar cone only)
    this.hideTorsoUniform.value = isFirstPerson ? (isOnFoot ? 2.0 : 1.0) : 0.0;
    for (const m of this.firstPersonHeadMeshes) {
      m.visible = !isFirstPerson;
    }
    const hideHairForHelmet = Boolean(this.helmetMesh) && this.helmetOffPhase < 0.26;
    if (hideHairForHelmet) {
      for (const hm of this.helmetHiddenHairMeshes) {
        hm.visible = false;
      }
    }
    for (const m of this.vestMeshes) {
      m.visible = !isFirstPerson || isOnFoot;
    }
    this.syncHelmetVisibility(isFirstPerson);
  }

  private syncHelmetVisibility(isFirstPerson: boolean): void {
    if (!this.helmetMesh) {
      this.helmetPivot.visible = false;
      return;
    }
    if (this.helmetAnimating) {
      this.helmetPivot.visible = !isFirstPerson || this.helmetOffPhase >= 0.14;
    } else if (this.helmetOn) {
      this.helmetPivot.visible = !isFirstPerson;
    } else {
      this.helmetPivot.visible = true;
    }
  }

  public isHelmetOn(): boolean {
    return this.helmetOn;
  }

  public isHelmetAnimating(): boolean {
    return this.helmetAnimating;
  }

  public setHelmetOn(targetOn: boolean, instant = false): void {
    this.helmetOn = targetOn;
    if (instant) {
      this.helmetOffPhase = targetOn ? 0 : 1;
      this.helmetAnimating = false;
    } else {
      const targetPhase = targetOn ? 0 : 1;
      this.helmetAnimating = Math.abs(this.helmetOffPhase - targetPhase) > 1e-4;
    }
  }

  public attachRiderToBike(onBike: boolean): void {
    if (onBike) {
      if (this.riderRoot.parent !== this.chassisPivot) {
        this.chassisPivot.add(this.riderRoot);
        this.riderRoot.rotation.set(0, Math.PI / 2, 0);
        this.riderRoot.scale.setScalar(0.96);
      }
    } else if (this.riderRoot.parent !== this.scene) {
      this.scene.add(this.riderRoot);
      this.riderRoot.scale.setScalar(0.96);
    }
  }

  public getLeftStandWorldPos(out: THREE.Vector3): THREE.Vector3 {
    this.root.updateMatrixWorld(true);
    out.set(-0.14, 0, -0.58);
    return this.root.localToWorld(out);
  }

  private updateBikeTransforms(physics: BikePhysics, updatePivotMatricesOnly = false): void {
    this.root.position.copy(physics.pos);
    this.root.rotation.set(0, physics.yaw, 0);

    const rearAxleX = -0.658;
    const frontAxleX = 0.658;

    // Pivot on rear tire during Grau (>= 0) and on front tire during RL / Stoppie (< 0)
    // so neither wheel ever sinks into the ground when holding the front brake.
    if (physics.wheeliePitch < 0) {
      this.pitchPivot.position.set(frontAxleX, 0, 0);
      this.chassisPivot.position.x = -frontAxleX;
    } else {
      this.pitchPivot.position.set(rearAxleX, 0, 0);
      this.chassisPivot.position.x = -rearAxleX;
    }

    this.leanPivot.rotation.x = physics.leanAngle + physics.whipAngle;
    this.pitchPivot.rotation.z = physics.wheeliePitch;

    const rearDrop = physics.rearSusp;
    const frontDrop = physics.frontSusp;
    const avgDrop = (rearDrop + frontDrop) * 0.5;
    this.chassisPivot.position.y = -avgDrop * 0.85;
    this.chassisPivot.rotation.z = (rearDrop - frontDrop) * 0.68;

    this.steeringHeadPivot.rotation.y = physics.steerAngle;
    this.forkSlidePivot.position.y = THREE.MathUtils.clamp((frontDrop - 0.032) * 1.15, -0.032, 0.095);
    this.swingarmPivot.rotation.z = (rearDrop - 0.035) * 0.62;

    this.frontWheelSpinPivot.rotation.z = -physics.wheelSpinFront;
    this.rearWheelSpinPivot.rotation.z = -physics.wheelSpinRear;

    const shadowFade = THREE.MathUtils.clamp(1 - Math.abs(physics.wheeliePitch) * 0.32, 0.35, 0.78);
    (this.contactShadowMesh.material as THREE.MeshBasicMaterial).opacity = physics.isAirborne
      ? 0.22
      : shadowFade;
    this.contactShadowMesh.position.x = THREE.MathUtils.clamp(
      -Math.sin(physics.wheeliePitch) * 0.45,
      -0.6,
      0.48
    );

    if (updatePivotMatricesOnly) {
      this.root.updateWorldMatrix(false, false);
      this.leanPivot.updateWorldMatrix(false, false);
      this.pitchPivot.updateWorldMatrix(false, false);
      this.chassisPivot.updateWorldMatrix(false, false);
      this.steeringHeadPivot.updateWorldMatrix(false, false);
      this.leftGripTarget.updateWorldMatrix(false, false);
      this.rightGripTarget.updateWorldMatrix(false, false);
    } else {
      this.root.updateMatrixWorld(true);
    }
  }

  public hasEmoteActive(): boolean {
    return this.smoothEmoteBlend > 0.005;
  }

  public update(
    physics: BikePhysics,
    isFirstPerson: boolean,
    dt = 0.016,
    inputs?: ControlInputs
  ): void {
    this.animTime += dt;
    this.smoothThrottle = THREE.MathUtils.damp(this.smoothThrottle, inputs?.throttle ?? 0, 9, dt);
    this.smoothFrontBrake = THREE.MathUtils.damp(this.smoothFrontBrake, inputs?.frontBrake ?? 0, 11, dt);
    this.smoothRearBrake = THREE.MathUtils.damp(this.smoothRearBrake, inputs?.rearBrake ?? 0, 12, dt);
    this.smoothClutch = THREE.MathUtils.damp(this.smoothClutch, inputs?.clutch ? 1 : 0, 14, dt);
    const reqEmote = inputs?.emote && inputs.emote !== 'none' ? inputs.emote : inputs?.noHand ? 'salve' : 'none';
    if (reqEmote !== 'none') {
      this.activeEmoteType = reqEmote;
    }
    this.smoothEmoteBlend = THREE.MathUtils.damp(
      this.smoothEmoteBlend,
      reqEmote !== 'none' ? 1 : 0,
      9.5,
      dt
    );
    if (this.smoothEmoteBlend < 0.005 && reqEmote === 'none') {
      this.activeEmoteType = 'none';
    }
    this.attachRiderToBike(true);
    this.setFirstPersonMode(isFirstPerson);
    this.updateHeadlightFade(dt, isFirstPerson);
    this.updateBikeTransforms(physics, true);
    this.updateCg160Dashboard(physics, dt, isFirstPerson);
    this.updateRiderPose(physics, isFirstPerson, inputs);

    const speedMps = Math.hypot(physics.vel.x, physics.vel.z);
    const safeDt = Math.max(0.001, Math.min(0.05, dt));
    const accelLong = (speedMps - this.lastClothSpeed) / safeDt;
    this.lastClothSpeed = speedMps;
    this.updateClothPhysics(
      safeDt,
      speedMps,
      accelLong,
      physics.leanAngle,
      physics.vel.y,
      false,
      0,
      physics.wheeliePitch
    );
  }

  private updateClothPhysics(
    dt: number,
    speedMps: number,
    accelLong: number,
    leanAngle: number,
    vertVel: number,
    isOnFoot: boolean,
    walkPhase: number,
    wheeliePitch: number
  ): void {
    const safeDt = Math.max(0.001, Math.min(0.04, dt));
    const windNorm = isOnFoot
      ? THREE.MathUtils.clamp(speedMps / 7.5, 0, 0.72)
      : THREE.MathUtils.clamp(speedMps / 24.0, 0, 1.45);

    this.clothUniforms.uClothTime.value = this.animTime;
    this.clothUniforms.uClothWind.value = THREE.MathUtils.damp(
      this.clothUniforms.uClothWind.value,
      windNorm,
      8.5,
      safeDt
    );

    const targetFlutter = isOnFoot
      ? 0.08 + windNorm * 0.42 + (Math.abs(vertVel) > 0.3 ? 0.25 : 0)
      : 0.06 + Math.pow(windNorm, 0.92) * 0.92;
    this.clothUniforms.uClothFlutter.value = THREE.MathUtils.damp(
      this.clothUniforms.uClothFlutter.value,
      targetFlutter,
      9.0,
      safeDt
    );

    // Compute inertial & gravity target offset in rider bind space (+X left, +Y up, +Z chest front, -Z back)
    const windDragZ = -THREE.MathUtils.clamp(windNorm * 0.020 + accelLong * 0.0016, -0.012, 0.032);
    const wheelieHangZ = -Math.sin(wheeliePitch) * 0.016;
    const strideSwingX = isOnFoot
      ? Math.sin(walkPhase) * THREE.MathUtils.clamp(speedMps / 4.5, 0, 1) * 0.010
      : 0;
    const leanGravityX = -Math.sin(leanAngle) * 0.016 + strideSwingX;
    const verticalBounceY =
      -0.004 -
      THREE.MathUtils.clamp(vertVel * 0.004, -0.012, 0.014) +
      (isOnFoot ? Math.sin(walkPhase * 2) * THREE.MathUtils.clamp(speedMps / 4.5, 0, 1) * 0.005 : 0) +
      windNorm * 0.006;

    this.clothTargetSway.set(
      THREE.MathUtils.clamp(leanGravityX, -0.024, 0.024),
      THREE.MathUtils.clamp(verticalBounceY, -0.020, 0.016),
      THREE.MathUtils.clamp(windDragZ + wheelieHangZ, -0.036, 0.014)
    );

    // Second-order damped spring for natural fabric momentum & follow-through
    const stiffness = 92.0;
    const damping = 13.5;
    const dx = this.clothTargetSway.x - this.clothSwayPos.x;
    const dy = this.clothTargetSway.y - this.clothSwayPos.y;
    const dz = this.clothTargetSway.z - this.clothSwayPos.z;
    this.clothSwayVel.x += (dx * stiffness - this.clothSwayVel.x * damping) * safeDt;
    this.clothSwayVel.y += (dy * stiffness - this.clothSwayVel.y * damping) * safeDt;
    this.clothSwayVel.z += (dz * stiffness - this.clothSwayVel.z * damping) * safeDt;
    this.clothSwayPos.addScaledVector(this.clothSwayVel, safeDt);
    this.clothUniforms.uClothSway.value.copy(this.clothSwayPos);
  }

  /**
   * Procedural Dismount / Mount leg-swing animation (t = 0 mounted CG 160 -> t = 1 standing upright beside left side)
   */
  public updateTransition(
    physics: BikePhysics,
    t: number,
    isFirstPerson: boolean,
    dt = 0.016
  ): void {
    this.animTime += dt;
    this.updateClothPhysics(dt, 0.8, 0, physics.leanAngle * (1 - t), 0, true, t * Math.PI, 0);
    this.attachRiderToBike(true);
    this.setFirstPersonMode(isFirstPerson, t > 0.32);
    this.updateHeadlightFade(dt, isFirstPerson);
    this.updateBikeTransforms(physics);

    const hips = this.findBone('Hips');
    const spine = this.findBone('Spine_');
    const spine2 = this.findBone('Spine2_');
    const neck = this.findBone('Neck_');
    const head = this.findBone('Head_');
    if (!hips) return;

    for (const [name, q] of this.restQuats) {
      const b = this.bones.get(name);
      if (b) {
        b.quaternion.copy(q);
        const rp = this.restPositions.get(name);
        if (rp) b.position.copy(rp);
      }
    }

    const sHands = smoothstep(0.0, 0.38, t);
    const sHip = smoothstep(0.06, 0.88, t);
    const sLegSwing = smoothstep(0.16, 0.82, t);
    const sLegArc = Math.sin(sLegSwing * Math.PI);
    const sUpright = smoothstep(0.14, 0.90, t);
    const sSettle = smoothstep(0.76, 1.0, t);

    // Exact upright standing world position beside bike converted to chassisPivot local space
    this.getLeftStandWorldPos(this._vA);
    this.chassisPivot.worldToLocal(this._vA);

    const backShift = this.fpCamDistance;
    const seatX = isFirstPerson ? -0.22 - Math.max(0, backShift) * 0.22 : -0.215;
    const seatY = isFirstPerson ? 0.815 : 0.822;

    this.riderRoot.position.set(
      THREE.MathUtils.lerp(seatX, this._vA.x, sHip),
      THREE.MathUtils.lerp(seatY, this._vA.y, sHip) + sLegArc * 0.032,
      THREE.MathUtils.lerp(0, this._vA.z, sHip)
    );

    // Counter-compensate kickstand roll so the rider lands 100% upright on the ground at t = 1
    this.chassisPivot.getWorldQuaternion(this._qSteer);
    this._qStandWorld.setFromAxisAngle(this._upVec, physics.yaw + Math.PI / 2);
    this._qGrip.copy(this._qSteer).invert().multiply(this._qStandWorld);
    this.riderRoot.quaternion.slerpQuaternions(this._qMountRoot, this._qGrip, sUpright);

    // Blend hips local position smoothly from (0,0,0) mounted to restPositions('Hips') standing
    const restHips = this.restPositions.get('Hips');
    if (restHips) {
      hips.position.set(
        restHips.x * sHip,
        restHips.y * sHip,
        restHips.z * sHip
      );
    } else {
      hips.position.set(0, 0, 0);
    }

    const mountedPelvisPitch = isFirstPerson ? 0.17 : 0.10;
    const mountedTorsoCurve = isFirstPerson ? 0.22 : 0.14;
    const pelvisPitch = THREE.MathUtils.lerp(mountedPelvisPitch, 0.035, sHip) + sLegArc * 0.06;
    const torsoCurve = THREE.MathUtils.lerp(mountedTorsoCurve, 0.045, sHip);
    this.applyLocalEuler(hips, pelvisPitch, -sLegArc * 0.28, sLegArc * 0.13);
    if (spine) this.applyLocalEuler(spine, torsoCurve * 0.45, sLegArc * 0.08, -sLegArc * 0.06);
    if (spine2) this.applyLocalEuler(spine2, torsoCurve * 0.55, sLegArc * 0.10, -sLegArc * 0.04);
    if (neck) this.applyLocalEuler(neck, -(pelvisPitch + torsoCurve) * 0.46, sLegArc * 0.14, 0);
    if (head) this.applyLocalEuler(head, -(pelvisPitch + torsoCurve) * 0.36, 0, 0);

    const lShoulder = this.findBone('LeftShoulder_');
    const rShoulder = this.findBone('RightShoulder_');
    this.riderRoot.updateMatrixWorld(true);
    if (lShoulder) {
      this.applyRiderSpaceEuler(lShoulder, 0.02, -0.10 * (1 - sHands), -0.14 - 0.03 * sHands);
    }
    if (rShoulder) {
      this.applyRiderSpaceEuler(rShoulder, 0.02, 0.10 * (1 - sHands), 0.14 + 0.03 * sHands);
    }

    const lUpLeg = this.findBone('LeftUpLeg_');
    const lLeg = this.findBone('LeftLeg_');
    const lFoot = this.findBone('LeftFoot_');
    const rUpLeg = this.findBone('RightUpLeg_');
    const rLeg = this.findBone('RightLeg_');
    const rFoot = this.findBone('RightFoot_');

    if (lUpLeg) this.applyLocalEuler(lUpLeg, 0.85 * (1 - sHip), 0, -0.10 * (1 - sHip) - 0.025 * sHip);
    if (lLeg) this.applyLocalEuler(lLeg, -1.10 * (1 - sHip) - 0.06 * sHip, 0, 0);
    if (rUpLeg) this.applyLocalEuler(rUpLeg, 0.85 * (1 - sHip) + sLegArc * 0.48, 0, 0.10 * (1 - sHip) + 0.025 * sHip);
    if (rLeg) this.applyLocalEuler(rLeg, -1.10 * (1 - sHip) - sLegArc * 0.72 - 0.06 * sHip, 0, 0);

    this.root.updateMatrixWorld(true);

    const pegX = -0.060;
    const pegY = 0.306;
    const pegZ = 0.196;

    // Left leg steps cleanly from CG 160 left peg onto flat asphalt beside the bike
    if (lUpLeg && lLeg && lFoot) {
      this._vB.set(pegX, pegY, -pegZ);
      this.chassisPivot.localToWorld(this._vB);
      this._vTarget.set(-0.14, 0.088, -0.49);
      this.root.localToWorld(this._vTarget);
      this._vTarget.lerpVectors(this._vB, this._vTarget, smoothstep(0.05, 0.62, t));
      this._vTarget.y += Math.sin(smoothstep(0.05, 0.56, t) * Math.PI) * 0.06;

      this._vB.set(0.34, 0.56, -0.38);
      this.chassisPivot.localToWorld(this._vB);
      this._vPole.set(0.14, 0.48, -0.50);
      this.root.localToWorld(this._vPole);
      this._vPole.lerpVectors(this._vB, this._vPole, sHip);

      this.solveTwoBoneIK(lUpLeg, lLeg, lFoot, this._vTarget, this._vPole);
      this.alignFootToPeg(lFoot, THREE.MathUtils.lerp(-0.10, -0.02, sHip), -0.02 * (1 - sHip));
    }

    // Right leg lifts off right peg, arcs high over CG 160 tail seat, and plants squarely on ground
    if (rUpLeg && rLeg && rFoot) {
      this._vB.set(pegX, pegY, pegZ);
      this.chassisPivot.localToWorld(this._vB);
      this._vTarget.set(-0.14, 0.088, -0.67);
      this.root.localToWorld(this._vTarget);
      this._vTarget.lerpVectors(this._vB, this._vTarget, sLegSwing);
      // Clear tail seat cleanly without touching fender
      this._vTarget.x -= Math.cos(physics.yaw) * (sLegArc * 0.32);
      this._vTarget.z += Math.sin(physics.yaw) * (sLegArc * 0.32);
      this._vTarget.y += sLegArc * 0.78;

      this._vB.set(0.34, 0.56, 0.38);
      this.chassisPivot.localToWorld(this._vB);
      this._vPole.set(0.14, 0.48, -0.69);
      this.root.localToWorld(this._vPole);
      this._vPole.lerpVectors(this._vB, this._vPole, sLegSwing);
      this._vPole.y += sLegArc * 0.48;

      this.solveTwoBoneIK(rUpLeg, rLeg, rFoot, this._vTarget, this._vPole);
      this.alignFootToPeg(rFoot, THREE.MathUtils.lerp(0.10, 0.02, sLegSwing), -0.02 * (1 - sLegSwing));
    }

    // Arms release CG 160 grips and settle smoothly to relaxed stance at sides
    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const lHand = this.findBone('LeftHand_');
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');
    const rHand = this.findBone('RightHand_');

    const gripWeight = 1 - smoothstep(0.04, 0.44, t);
    if (rArm && rFore && rHand) {
      this.rightGripTarget.getWorldPosition(this._vTarget);
      this.steeringHeadPivot.getWorldQuaternion(this._qSteer);
      this._vOffset.set(-0.016, 0.028, 0.0).applyQuaternion(this._qSteer);
      this._vTarget.addScaledVector(this._vOffset, gripWeight);
      this._vB.set(-0.14, 0.85, -0.34);
      this.root.localToWorld(this._vB);
      this._vTarget.lerp(this._vB, sHands);

      this._vB.set(-0.04, 1.07, 0.34);
      this.chassisPivot.localToWorld(this._vB);
      this._vPole.set(-0.22, 1.02, -0.31);
      this.root.localToWorld(this._vPole);
      this._vPole.lerpVectors(this._vB, this._vPole, sHands);

      this.solveArmIK(rArm, rFore, rHand, this._vTarget, this._vPole, 'right');
      this.alignHandToGrip(rHand, 'right', 0, 0, gripWeight);
      this.twistForearmToHand(rFore, rHand, 0.25 * gripWeight);
      this.poseUniformFingers('right', 0.82 * gripWeight + 0.20 * (1 - gripWeight));
    }

    if (lArm && lFore && lHand) {
      this.leftGripTarget.getWorldPosition(this._vTarget);
      this.steeringHeadPivot.getWorldQuaternion(this._qSteer);
      this._vOffset.set(-0.016, 0.028, 0.0).applyQuaternion(this._qSteer);
      this._vTarget.addScaledVector(this._vOffset, gripWeight);
      this._vB.set(-0.14, 0.85, -0.80);
      this.root.localToWorld(this._vB);
      this._vTarget.lerp(this._vB, sHands);

      this._vB.set(-0.04, 1.07, -0.34);
      this.chassisPivot.localToWorld(this._vB);
      this._vPole.set(-0.22, 1.02, -0.85);
      this.root.localToWorld(this._vPole);
      this._vPole.lerpVectors(this._vB, this._vPole, sHands);

      this.solveArmIK(lArm, lFore, lHand, this._vTarget, this._vPole, 'left');
      this.alignHandToGrip(lHand, 'left', 0, 0, gripWeight);
      this.twistForearmToHand(lFore, lHand, 0.25 * gripWeight);
      this.poseUniformFingers('left', 0.82 * gripWeight + 0.20 * (1 - gripWeight));
    }

    // Blend final 24% smoothly toward exact idle standing joint angles so t=1 -> on_foot is seamless
    if (sSettle > 0.001) {
      const restIdleArm = (bone: THREE.Bone | undefined, restName: string, rx: number, rz: number) => {
        if (!bone) return;
        const rq = this.restQuats.get(restName);
        if (!rq) return;
        this._qGrip.copy(bone.quaternion);
        bone.quaternion.copy(rq);
        this.applyRiderSpaceEuler(bone, rx, 0, rz);
        bone.quaternion.slerpQuaternions(this._qGrip, bone.quaternion, sSettle);
      };
      this.riderRoot.updateMatrixWorld(true);
      const armRestAdduct = this.isCustomRider ? -0.54 : -0.26;
      restIdleArm(lArm, 'LeftArm_', 0.03, armRestAdduct);
      restIdleArm(lFore, 'LeftForeArm_', -0.20, 0);
      restIdleArm(rArm, 'RightArm_', 0.03, -armRestAdduct);
      restIdleArm(rFore, 'RightForeArm_', -0.20, 0);
      const relaxHand = (hand: THREE.Bone | undefined, name: string) => {
        const rq = this.restQuats.get(name);
        if (hand && rq) hand.quaternion.slerp(rq, sSettle);
      };
      relaxHand(lHand, 'LeftHand_');
      relaxHand(rHand, 'RightHand_');
    }

    this.root.updateMatrixWorld(true);

    // Smooth 1st-person eye path from CG 160 helmet view directly to Neck_-anchored standing eye level
    this._vB.set(-0.04 - backShift * 0.48, 1.40 + Math.max(0, backShift) * 0.18 - Math.min(0, backShift) * 0.07, 0);
    if (neck) {
      neck.getWorldPosition(this._vTarget);
      this.riderRoot.worldToLocal(this._vTarget);
      const neckEyeY = this.isCustomRider ? 0.082 : 0.145;
      const neckEyeZ = this.isCustomRider ? 0.098 : 0.082;
      this._vTarget.set(this._vTarget.x * 0.55, this._vTarget.y + neckEyeY, this._vTarget.z + neckEyeZ);
      this.riderRoot.localToWorld(this._vTarget);
      this.chassisPivot.worldToLocal(this._vTarget);
    } else {
      this._vTarget.set(this._vA.x + 0.08, this._vA.y + 1.59, this._vA.z);
    }
    if (t >= 0.90) {
      this.hasFootEyeInit = false;
    }
    this.headCamAnchor.position.lerpVectors(this._vB, this._vTarget, smoothstep(0.04, 0.94, t));
    this.headCamAnchor.updateMatrixWorld(true);
  }

  /**
   * Free-roam On-Foot walking / running / jumping / turn-in-place / Salve animation across the city
   */
  public updateOnFoot(
    physics: BikePhysics,
    worldPos: THREE.Vector3,
    yaw: number,
    speed: number,
    isAirborne: boolean,
    walkPhase: number,
    emote: EmoteId | boolean,
    isFirstPerson: boolean,
    dt = 0.016,
    turnRate = 0,
    vertVel = 0,
    dirSign = 1
  ): void {
    this.animTime += dt;
    const activeEmote: EmoteId =
      typeof emote === 'boolean' ? (emote ? 'salve' : 'none') : emote;
    if (activeEmote !== 'none') {
      this.activeEmoteType = activeEmote;
    }
    this.smoothEmoteBlend = THREE.MathUtils.damp(
      this.smoothEmoteBlend,
      activeEmote !== 'none' ? 1 : 0,
      9.5,
      dt
    );
    if (this.smoothEmoteBlend < 0.005 && activeEmote === 'none') {
      this.activeEmoteType = 'none';
    }

    // Smooth locomotion parameters for fluid starts, stops, turns, jumps & landings
    this.smoothFootSpeed = THREE.MathUtils.damp(this.smoothFootSpeed, speed, 14, dt);
    this.smoothFootTurn = THREE.MathUtils.damp(this.smoothFootTurn, THREE.MathUtils.clamp(turnRate / 2.6, -1, 1), 11, dt);
    this.smoothFootAir = THREE.MathUtils.damp(this.smoothFootAir, isAirborne ? 1 : 0, isAirborne ? 16 : 18, dt);
    this.smoothFootDir = THREE.MathUtils.damp(this.smoothFootDir, dirSign, 11, dt);

    if (this.prevFootAirborne && !isAirborne) {
      this.footLandSquash = 1.0;
    }
    this.prevFootAirborne = isAirborne;
    this.footLandSquash = THREE.MathUtils.damp(this.footLandSquash, 0, 9.5, dt);

    const safeDt = Math.max(0.001, Math.min(0.05, dt));
    const footAccel = (this.smoothFootSpeed - this.lastClothSpeed) / safeDt;
    this.lastClothSpeed = this.smoothFootSpeed;
    this.updateClothPhysics(
      safeDt,
      this.smoothFootSpeed,
      footAccel,
      this.smoothFootTurn * 0.14,
      vertVel,
      true,
      walkPhase,
      0
    );

    this.updateHeadlightFade(dt, isFirstPerson);
    this.updateBikeTransforms(physics);
    this.attachRiderToBike(false);
    this.setFirstPersonMode(isFirstPerson, true);

    this.riderRoot.position.copy(worldPos);
    this.riderRoot.rotation.set(0, yaw + Math.PI / 2, 0);

    const hips = this.findBone('Hips');
    const spine = this.findBone('Spine_');
    const spine2 = this.findBone('Spine2_');
    const neck = this.findBone('Neck_');
    const head = this.findBone('Head_');
    if (!hips) return;

    for (const [name, q] of this.restQuats) {
      const b = this.bones.get(name);
      if (b) {
        b.quaternion.copy(q);
        const rp = this.restPositions.get(name);
        if (rp) b.position.copy(rp);
      }
    }

    const walkBlend = THREE.MathUtils.clamp(this.smoothFootSpeed / 2.2, 0, 1);
    const jogBlend = THREE.MathUtils.clamp((this.smoothFootSpeed - 2.95) / 2.5, 0, 1);
    const groundedBlend = 1 - this.smoothFootAir;
    const idleBlend = (1 - walkBlend) * groundedBlend;
    const isMovingFwd = Math.max(0, this.smoothFootDir);
    const dirScale = 0.72 + 0.28 * isMovingFwd;
    const breath = Math.sin(this.animTime * 2.15) * (0.011 + 0.010 * jogBlend);
    const idleSway = Math.sin(this.animTime * 0.85);
    const idleShift = idleBlend * idleSway * 0.016;
    const turnInPlace = THREE.MathUtils.clamp(Math.abs(this.smoothFootTurn) * (1 - walkBlend), 0, 1) * groundedBlend;
    const turnShuffleWave = Math.sin(this.animTime * 10.8) * turnInPlace;

    // Centered double-frequency COM stride bounce + landing compression + air lift
    const strideBob =
      (-Math.cos(walkPhase * 2) * 0.5 + 0.22) * (0.032 * walkBlend + 0.044 * jogBlend) * groundedBlend;
    const landDrop = this.footLandSquash * 0.095 * groundedBlend;
    const idleSink = idleBlend * (0.008 + Math.abs(idleSway) * 0.004);
    const bob = strideBob - landDrop - idleSink + this.smoothFootAir * 0.025 + Math.abs(turnShuffleWave) * 0.010;

    // Weight shifts smoothly over the planted stance leg (left forward => right planted)
    const hipLatShift =
      (-Math.sin(walkPhase) * 0.026 * walkBlend * (1 - 0.42 * jogBlend) + idleShift * 0.55) * groundedBlend;
    const hipRoll =
      Math.cos(walkPhase) * (0.048 * walkBlend + 0.026 * jogBlend) * groundedBlend +
      this.smoothFootTurn * (0.045 * walkBlend + 0.065 * jogBlend) +
      idleSway * 0.024 * idleBlend;
    const pelvisYaw =
      -Math.sin(walkPhase) * (0.105 * walkBlend + 0.055 * jogBlend) * groundedBlend +
      this.smoothFootTurn * 0.085;
    const forwardLean =
      (0.028 + (walkBlend * 0.052 + jogBlend * 0.145) * isMovingFwd) * groundedBlend +
      this.footLandSquash * 0.11 +
      this.smoothFootAir * 0.06;

    hips.position.y += bob;
    hips.position.x += hipLatShift;
    this.applyLocalEuler(hips, forwardLean, pelvisYaw, hipRoll);
    if (spine) {
      this.applyLocalEuler(
        spine,
        0.020 + (walkBlend * 0.036 + jogBlend * 0.090) * isMovingFwd + this.footLandSquash * 0.08 + breath,
        -pelvisYaw * 0.68 + this.smoothFootTurn * 0.06,
        -hipRoll * 0.62 + this.smoothFootTurn * 0.035 * jogBlend
      );
    }
    if (spine2) {
      this.applyLocalEuler(
        spine2,
        0.016 + (walkBlend * 0.034 + jogBlend * 0.072) * isMovingFwd + breath * 0.9,
        -pelvisYaw * 0.66 + this.smoothFootTurn * 0.09,
        -hipRoll * 0.26
      );
    }
    if (neck) this.applyLocalEuler(neck, -forwardLean * 0.52, pelvisYaw * 0.22 + this.smoothFootTurn * 0.12, 0);
    if (head) {
      this.applyLocalEuler(
        head,
        -forwardLean * 0.42 + Math.sin(this.animTime * 1.25) * 0.012,
        idleSway * 0.035 * idleBlend + this.smoothFootTurn * 0.15,
        0
      );
    }

    const lShoulder = this.findBone('LeftShoulder_');
    const rShoulder = this.findBone('RightShoulder_');
    const shoulderCounterYaw = -pelvisYaw * 0.42;
    this.riderRoot.updateMatrixWorld(true);
    if (lShoulder) this.applyRiderSpaceEuler(lShoulder, 0.02, shoulderCounterYaw, -0.17);
    if (rShoulder) this.applyRiderSpaceEuler(rShoulder, 0.02, shoulderCounterYaw, 0.17);

    // 4-phase human gait: heel-strike -> stance cushion -> powered toe-off -> tucked knee swing + relaxed idle
    const lUpLeg = this.findBone('LeftUpLeg_');
    const lLeg = this.findBone('LeftLeg_');
    const lFoot = this.findBone('LeftFoot_');
    const rUpLeg = this.findBone('RightUpLeg_');
    const rLeg = this.findBone('RightLeg_');
    const rFoot = this.findBone('RightFoot_');

    const computeLegAngles = (phase: number, turnSign: number, idleBias: number) => {
      // Slightly faster knee drive forward, strong push-off extension behind
      const strideHip =
        (Math.sin(phase) + 0.08 * Math.sin(phase * 2 - 0.3)) *
        (0.49 * walkBlend + 0.36 * jogBlend) *
        dirScale +
        0.14 * jogBlend * isMovingFwd;
      const shuffleHip = Math.max(0, turnSign * turnShuffleWave) * 0.22;
      const idleHip = idleBias * idleBlend * 0.055;
      const hipSwing = strideHip + shuffleHip + idleHip + this.footLandSquash * 0.26;

      // Peak swing knee flexion right as leg passes underneath hip, extending cleanly before heel strike
      const swingPhase = Math.max(0, Math.cos(phase - 0.18));
      const swingKnee =
        Math.pow(swingPhase, 1.15) * (0.78 * walkBlend + 0.56 * jogBlend) * dirScale;
      // Soft weight-acceptance knee cushion just after heel contact
      const cushionPhase = Math.max(0, Math.sin(phase - 0.72));
      const stanceKnee = cushionPhase * (0.16 * walkBlend + 0.18 * jogBlend);
      const shuffleKnee = Math.max(0, turnSign * turnShuffleWave) * 0.40;
      const idleKnee = Math.max(0, -idleBias) * idleBlend * 0.075;
      const knee = -(0.045 + swingKnee + stanceKnee + shuffleKnee + idleKnee + this.footLandSquash * 0.48);

      // Dorsiflex toes up at heel strike, roll flat on stance, then plantarflex strongly on toe-off
      const heelStrike = -Math.max(0, Math.sin(phase + 0.38)) * (0.29 * walkBlend + 0.14 * jogBlend) * dirScale;
      const toePush = Math.max(0, -Math.sin(phase - 0.48)) * (0.40 * walkBlend + 0.24 * jogBlend) * dirScale;
      const swingToeLift = -swingPhase * 0.14 * walkBlend;
      const foot = heelStrike + toePush + swingToeLift - knee * 0.12;
      return { hipSwing, knee, foot };
    };

    const idleWeight = idleSway * 0.5 + 0.5;
    const legL = computeLegAngles(walkPhase, 1, 0.4 - idleWeight * 0.8);
    const legR = computeLegAngles(walkPhase + Math.PI, -1, -0.4 + idleWeight * 0.8);
    const airTuck = THREE.MathUtils.clamp(vertVel * 0.08, -0.18, 0.24);

    if (lUpLeg) {
      this.applyLocalEuler(lUpLeg, THREE.MathUtils.lerp(legL.hipSwing, 0.46 + airTuck, this.smoothFootAir), 0, -0.022);
    }
    if (lLeg) {
      this.applyLocalEuler(lLeg, THREE.MathUtils.lerp(legL.knee, -0.68 - airTuck * 0.6, this.smoothFootAir), 0, 0);
    }
    if (lFoot) {
      this.applyLocalEuler(lFoot, THREE.MathUtils.lerp(legL.foot, 0.26, this.smoothFootAir), 0, 0);
    }

    if (rUpLeg) {
      this.applyLocalEuler(rUpLeg, THREE.MathUtils.lerp(legR.hipSwing, 0.24 + airTuck * 0.5, this.smoothFootAir), 0, 0.022);
    }
    if (rLeg) {
      this.applyLocalEuler(rLeg, THREE.MathUtils.lerp(legR.knee, -0.38 - airTuck * 0.4, this.smoothFootAir), 0, 0);
    }
    if (rFoot) {
      this.applyLocalEuler(rFoot, THREE.MathUtils.lerp(legR.foot, 0.20, this.smoothFootAir), 0, 0);
    }

    // Twist-free sagittal arm swing with natural elbow lag & closer athletic adduction
    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');

    const armAmp = (0.39 * walkBlend + 0.38 * jogBlend) * dirScale;
    const armPhase = Math.sin(walkPhase - 0.14);
    const armLag = Math.sin(walkPhase - 0.48);
    const idleArmBreath = idleBlend * Math.sin(this.animTime * 1.1) * 0.018;
    const leftArmPitch = armPhase * armAmp * groundedBlend + idleArmBreath + this.smoothFootAir * 0.24;
    const rightArmPitch = -armPhase * armAmp * groundedBlend - idleArmBreath - this.smoothFootAir * 0.14;
    const fwdLeft = Math.max(0, -armLag);
    const fwdRight = Math.max(0, armLag);
    const elbowFlexL =
      0.20 +
      (0.10 * walkBlend + 0.66 * jogBlend + fwdLeft * (0.30 + 0.26 * jogBlend)) * groundedBlend +
      this.footLandSquash * 0.25 +
      this.smoothFootAir * 0.36;
    const elbowFlexR =
      0.20 +
      (0.10 * walkBlend + 0.66 * jogBlend + fwdRight * (0.30 + 0.26 * jogBlend)) * groundedBlend +
      this.footLandSquash * 0.25 +
      this.smoothFootAir * 0.32;
    const baseAdduct = this.isCustomRider ? -0.54 : -0.26;
    const armAdduct = baseAdduct + walkBlend * 0.02 + jogBlend * 0.02 - this.smoothFootAir * 0.18;

    this.riderRoot.updateMatrixWorld(true);
    if (lArm) {
      this.applyRiderSpaceEuler(lArm, -leftArmPitch + 0.03, 0, armAdduct);
    }
    if (lFore) this.applyRiderSpaceEuler(lFore, -elbowFlexL, 0, 0);
    const fingerCurl = 0.22 + jogBlend * 0.22;
    this.poseUniformFingers('left', fingerCurl);

    if (rArm) {
      this.applyRiderSpaceEuler(rArm, -rightArmPitch + 0.03, 0, -armAdduct);
    }
    if (rFore) this.applyRiderSpaceEuler(rFore, -elbowFlexR, 0, 0);
    this.poseUniformFingers('right', fingerCurl);

    this.riderRoot.updateMatrixWorld(true);

    // Track Neck_ world position dynamically so forward sprint lean & crouch never clip chest/collar in 1st person
    if (neck) {
      neck.getWorldPosition(this._vA);
      this.riderRoot.worldToLocal(this._vA);
      const neckEyeY = this.isCustomRider ? 0.082 : 0.145;
      const neckEyeZ = this.isCustomRider ? 0.098 : 0.082;
      this._vB.set(
        this._vA.x * 0.55,
        this._vA.y + neckEyeY - this.footLandSquash * 0.025,
        this._vA.z + neckEyeZ
      );
    } else {
      this._vB.set(hipLatShift * 0.45, 1.66 + bob, 0.082);
    }
    if (!this.hasFootEyeInit || dt <= 0) {
      this._footEyeLocal.copy(this._vB);
      this.hasFootEyeInit = true;
    } else {
      const alpha = 1 - Math.exp(-26 * dt);
      this._footEyeLocal.lerp(this._vB, alpha);
    }
    this.footCamAnchor.position.copy(this._footEyeLocal);
    this.footCamAnchor.updateMatrixWorld(true);
  }

  private updateRiderPose(
    physics: BikePhysics,
    isFirstPerson: boolean,
    inputs?: ControlInputs
  ): void {
    const hips = this.findBone('Hips');
    const spine = this.findBone('Spine_');
    const spine2 = this.findBone('Spine2_');
    const neck = this.findBone('Neck_');
    const head = this.findBone('Head_');

    if (!hips) return;

    for (let i = 0; i < this.restResetList.length; i++) {
      const item = this.restResetList[i];
      item.bone.quaternion.copy(item.quat);
      item.bone.position.copy(item.pos);
    }

    const speedMs = Math.hypot(physics.vel.x, physics.vel.z);
    const speedNorm = THREE.MathUtils.clamp(speedMs / 35, 0, 1);
    const wheelieNorm = THREE.MathUtils.clamp(physics.wheeliePitch / 1.15, 0, 1);
    const rpmNorm = THREE.MathUtils.clamp(physics.rpm / physics.maxRpm, 0, 1);
    const throttle = this.smoothThrottle;
    const frontBrake = this.smoothFrontBrake;
    const clutch = this.smoothClutch;
    const backShift = this.fpCamDistance;

    // Varied, fluid Brazilian Grau choreography (multi-harmonic waves so Grau never feels stiff)
    const manualMolejo = Math.abs(inputs?.molejo ?? 0);
    const breath = Math.sin(this.animTime * 2.4) * 0.010;
    const engineVib = Math.sin(this.animTime * (20 + rpmNorm * 28)) * 0.0022 * (0.25 + rpmNorm);
    const fluidGroove =
      Math.sin(physics.molejoPhase) * 0.62 +
      Math.sin(physics.molejoPhase * 0.54) * 0.42 +
      Math.cos(physics.molejoPhase * 1.44) * 0.24;
    const molejoCadence =
      fluidGroove *
      ((isFirstPerson ? 0.075 : 0.13) * wheelieNorm +
        (isFirstPerson ? 0.085 : 0.12) * manualMolejo * (1 + wheelieNorm * 0.35));
    const molejoWave = THREE.MathUtils.clamp(
      molejoCadence + physics.riderLateral * ((isFirstPerson ? 0.22 : 0.40) + wheelieNorm * (isFirstPerson ? 0.08 : 0.16)),
      isFirstPerson ? -0.40 : -0.85,
      isFirstPerson ? 0.40 : 0.85
    );

    // Three evolving Grau stunt grooves blended smoothly over time
    const grauPump =
      (Math.sin(physics.molejoPhase * 1.15) * 0.65 + Math.cos(physics.molejoPhase * 2.1) * 0.35) *
      wheelieNorm;
    const grauStandFloat =
      wheelieNorm * (0.28 + 0.72 * (0.5 + 0.5 * Math.sin(this.animTime * 0.68 + physics.molejoPhase * 0.15)));
    const grauShoulderGroove =
      wheelieNorm * Math.sin(physics.molejoPhase * 0.76 + Math.cos(this.animTime * 0.55) * 0.9);
    const rearBrakeVal = this.smoothRearBrake;
    const grauThrottleSurge = (throttle - rearBrakeVal * 0.7) * wheelieNorm;
    const grauChestPump =
      grauPump * 0.09 +
      Math.sin(physics.molejoPhase * 0.64) * wheelieNorm * 0.075 +
      (rearBrakeVal * 0.08 - throttle * 0.06) * wheelieNorm;

    // Lively contextual riding life: street-scan glances when cruising, corner hang-off, & Grau head rhythm
    const cruiseLookYaw =
      (1 - speedNorm * 0.65) * (1 - wheelieNorm) * Math.sin(this.animTime * 0.72) * 0.11;
    const cornerHipShift =
      physics.leanAngle * (isFirstPerson ? 0.014 : 0.070) * (1 - wheelieNorm * 0.35);
    const cornerChestLean =
      physics.leanAngle * (isFirstPerson ? 0.08 : 0.18) * (1 - wheelieNorm * 0.4);
    const grauHeadNod = wheelieNorm * Math.sin(physics.molejoPhase * 1.12) * 0.062;
    const clutchTapAnim =
      clutch * 0.65 +
      (1 - clutch) * Math.max(0, Math.sin(this.animTime * 4.2)) * 0.05 * speedNorm * (1 - wheelieNorm);

    // Natural braking body physics: rider braces against tank deceleration & balances forward during RL Stoppie
    const stoppieNorm = THREE.MathUtils.clamp(-physics.wheeliePitch / 0.72, 0, 1);
    const totalBrake = Math.max(frontBrake, rearBrakeVal * 0.35);
    const brakeBrace = frontBrake * (1 - wheelieNorm) * (isFirstPerson ? 0.055 : 0.085);
    const accelLean = throttle * (isFirstPerson ? 0.14 : 0.22) * (1 - wheelieNorm);
    const tuckAmount = THREE.MathUtils.clamp(
      (physics.riderForeAft < 0 ? -physics.riderForeAft * 0.55 : 0) +
        speedNorm * (isFirstPerson ? 0.11 : 0.20) * (1 - wheelieNorm) +
        accelLean,
      0,
      1
    );

    // Upright Honda CG 160 Titan seat positioning
    const baseHipX = isFirstPerson
      ? -0.22 - Math.max(0, backShift) * 0.22 - wheelieNorm * 0.034 - tuckAmount * 0.015
      : -0.215 - wheelieNorm * 0.034 - tuckAmount * 0.018;
    const baseHipY = isFirstPerson ? 0.815 : 0.822;

    const hipX =
      baseHipX +
      throttle * 0.022 * (1 - wheelieNorm) -
      frontBrake * 0.020 * (1 - wheelieNorm) * (1 - stoppieNorm) +
      stoppieNorm * 0.026 +
      grauPump * 0.018 +
      grauStandFloat * 0.014;
    const hipY =
      baseHipY -
      tuckAmount * 0.020 +
      stoppieNorm * 0.038 -
      brakeBrace * 0.012 -
      wheelieNorm * 0.010 +
      grauStandFloat * (isFirstPerson ? 0.026 : 0.044) -
      Math.abs(molejoWave) * (isFirstPerson ? 0.012 : 0.012) -
      Math.abs(physics.leanAngle) * 0.014 +
      grauPump * 0.014 +
      engineVib;
    const hipMaxZ = isFirstPerson ? 0.052 + wheelieNorm * 0.02 : 0.095 + wheelieNorm * 0.032;
    const hipZ = THREE.MathUtils.clamp(
      molejoWave * ((isFirstPerson ? 0.042 : 0.072) + wheelieNorm * (isFirstPerson ? 0.016 : 0.034)) +
        cornerHipShift,
      -hipMaxZ,
      hipMaxZ
    );

    this.riderRoot.position.set(hipX, hipY, hipZ);
    hips.position.set(0, 0, 0);

    // Rider torso follows side-to-side steering & bike lean smoothly
    const bodyTurnFollow = physics.leanAngle * 0.24 + (inputs?.steer ?? 0) * 0.14;

    // Upright Honda CG 160 street posture
    const pitchBias = -0.10;
    const pelvisPitch =
      (isFirstPerson
        ? 0.22 + pitchBias * 0.5 + tuckAmount * 0.10 - wheelieNorm * 0.11
        : 0.15 + pitchBias * 0.5 + tuckAmount * 0.12 - wheelieNorm * 0.11) -
      brakeBrace * 0.35 +
      stoppieNorm * 0.16 +
      grauChestPump * 0.65;
    this.applyLocalEuler(
      hips,
      pelvisPitch,
      -molejoWave * ((isFirstPerson ? 0.17 : 0.10) + wheelieNorm * 0.09) -
        grauShoulderGroove * 0.08 -
        bodyTurnFollow * 0.42,
      molejoWave * ((isFirstPerson ? 0.15 : 0.085) + wheelieNorm * 0.075) +
        grauShoulderGroove * 0.06 +
        cornerChestLean * 0.45 +
        bodyTurnFollow * 0.26
    );

    const torsoCurve =
      (isFirstPerson
        ? 0.32 + pitchBias + tuckAmount * 0.14 - wheelieNorm * 0.11 + breath
        : 0.24 + pitchBias + tuckAmount * 0.20 - wheelieNorm * 0.13 + breath) -
      brakeBrace * 0.45 +
      stoppieNorm * 0.18 +
      grauChestPump * 0.85;
    const lowerSway =
      molejoWave * ((isFirstPerson ? 0.15 : 0.10) + wheelieNorm * 0.07) +
      grauShoulderGroove * 0.05 +
      cornerChestLean * 0.65 +
      bodyTurnFollow * 0.32;
    const upperCounterSway =
      -molejoWave * ((isFirstPerson ? 0.08 : 0.055) + wheelieNorm * 0.045) -
      grauShoulderGroove * 0.07 +
      cornerChestLean * 0.45 +
      bodyTurnFollow * 0.28;
    const barFollowYaw =
      physics.steerAngle * 0.36 + grauShoulderGroove * 0.10 - bodyTurnFollow * 0.44;

    if (spine) {
      this.applyLocalEuler(
        spine,
        torsoCurve * 0.45,
        -molejoWave * ((isFirstPerson ? 0.09 : 0.055) + wheelieNorm * 0.06) - bodyTurnFollow * 0.38,
        lowerSway
      );
    }
    if (spine2) {
      this.applyLocalEuler(spine2, torsoCurve * 0.55, barFollowYaw, upperCounterSway);
    }

    const totalTorsoPitch = pelvisPitch + torsoCurve;
    const lookHorizon = -totalTorsoPitch * 0.76 - physics.wheeliePitch * 0.35;
    const grauHeadPeek = wheelieNorm * Math.sin(physics.molejoPhase * 0.68) * 0.16;
    if (neck) {
      this.applyLocalEuler(
        neck,
        lookHorizon * 0.55 + grauHeadNod * 0.45,
        -physics.leanAngle * 0.32 - barFollowYaw * 0.45 + grauHeadPeek + cruiseLookYaw * 0.65,
        -molejoWave * (isFirstPerson ? 0.16 : 0.11) - grauShoulderGroove * 0.06 - cornerChestLean * 0.45
      );
    }
    if (head) {
      this.applyLocalEuler(
        head,
        lookHorizon * 0.45 +
          Math.sin(this.animTime * 1.9 + rpmNorm * 3.0) * 0.015 +
          grauPump * 0.04 +
          grauHeadNod * 0.55 +
          frontBrake * (1 - wheelieNorm) * 0.048,
        -physics.leanAngle * 0.24 + grauHeadPeek * 0.4 + cruiseLookYaw * 0.45,
        -physics.leanAngle * 0.12
      );
    }

    const lShoulder = this.findBone('LeftShoulder_');
    const rShoulder = this.findBone('RightShoulder_');
    const reachShift = physics.steerAngle * 0.22;
    this.riderRoot.updateMatrixWorld(true);
    if (lShoulder) {
      this.applyRiderSpaceEuler(
        lShoulder,
        0.02 - wheelieNorm * 0.02 - grauThrottleSurge * 0.02,
        -0.10 - Math.max(0, -reachShift) * 0.22,
        -0.14 + molejoWave * 0.025
      );
    }
    if (rShoulder) {
      this.applyRiderSpaceEuler(
        rShoulder,
        0.02 - wheelieNorm * 0.02 - grauThrottleSurge * 0.02,
        0.10 + Math.max(0, reachShift) * 0.22,
        0.14 + molejoWave * 0.025
      );
    }

    const lUpLeg = this.findBone('LeftUpLeg_');
    const lLeg = this.findBone('LeftLeg_');
    const lFoot = this.findBone('LeftFoot_');
    const rUpLeg = this.findBone('RightUpLeg_');
    const rLeg = this.findBone('RightLeg_');
    const rFoot = this.findBone('RightFoot_');

    // Initial leg bend in bike_rider.glb space (+rx swings thigh forward, -rx bends knee backward)
    if (lUpLeg) this.applyLocalEuler(lUpLeg, 1.1, 0, -0.14);
    if (lLeg) this.applyLocalEuler(lLeg, -1.45, 0, 0);
    if (rUpLeg) this.applyLocalEuler(rUpLeg, 1.1, 0, 0.14);
    if (rLeg) this.applyLocalEuler(rLeg, -1.45, 0, 0);

    this.riderRoot.updateMatrixWorld(true);

    // Position 1st-Person Helmet Cam cleanly over the CG 160 dash & bars
    this.headCamAnchor.position.set(
      THREE.MathUtils.clamp(
        -0.04 -
          backShift * 0.48 +
          Math.abs(physics.leanAngle) * 0.05 -
          wheelieNorm * 0.055 +
          throttle * 0.045 * (1 - wheelieNorm) +
          grauPump * 0.025,
        -0.22,
        0.18
      ),
      THREE.MathUtils.clamp(
        1.40 +
          Math.max(0, backShift) * 0.18 -
          Math.min(0, backShift) * 0.07 -
          Math.abs(physics.leanAngle) * 0.105 +
          wheelieNorm * 0.068 -
          (physics.frontSusp - 0.032) * 0.45 +
          stoppieNorm * 0.035 +
          grauStandFloat * 0.022 -
          throttle * 0.024 * (1 - wheelieNorm) -
          Math.abs(molejoWave) * 0.022 +
          engineVib * 0.3,
        1.16,
        1.58
      ),
      THREE.MathUtils.clamp(
        physics.leanAngle * 0.10 +
          molejoWave * (0.068 + wheelieNorm * 0.032) +
          grauShoulderGroove * 0.020,
        -0.14,
        0.14
      )
    );
    this.headCamAnchor.updateMatrixWorld(true);

    // Varied Grau + Cornering leg/knee choreography: knees grip tank cleanly under front braking
    const leanLeft = Math.max(0, -physics.leanAngle);
    const leanRight = Math.max(0, physics.leanAngle);
    const kneeScale = isFirstPerson ? 1.0 : 0.78;
    const brakeTankGrip = 1 - Math.min(0.32, totalBrake * 0.32);
    const legWaveL = Math.max(0, Math.sin(physics.molejoPhase * 0.88));
    const legWaveR = Math.max(0, Math.cos(physics.molejoPhase * 0.82));
    const grauKneeL =
      wheelieNorm * (0.09 + Math.max(0, -molejoWave) * 0.18 + legWaveL * 0.12) * kneeScale;
    const grauKneeR =
      wheelieNorm * (0.09 + Math.max(0, molejoWave) * 0.18 + legWaveR * 0.12) * kneeScale;
    const kneeOutL =
      (0.18 +
        leanLeft * 0.44 * kneeScale +
        Math.max(0, -molejoWave) * 0.18 * kneeScale +
        grauKneeL) *
      brakeTankGrip;
    const kneeOutR =
      (0.18 +
        leanRight * 0.44 * kneeScale +
        Math.max(0, molejoWave) * 0.18 * kneeScale +
        grauKneeR) *
      brakeTankGrip;

    // Periodic left-foot hover/tap off the peg during deep Grau or Sem Mão
    const deepGrauGate = smoothstep(0.45, 0.85, wheelieNorm);
    const footWave = Math.max(0, Math.sin(this.animTime * 1.35 + physics.molejoPhase * 0.25));
    const lFootHover =
      deepGrauGate *
      (physics.noHandBlend * 0.08 + footWave * 0.065) *
      (isFirstPerson ? 0.55 : 1.0);

    const pegX = -0.060;
    const pegY = 0.306;
    const pegZ = 0.196;

    if (lUpLeg && lLeg && lFoot) {
      this._vTarget.set(
        pegX - lFootHover * 0.45,
        pegY + lFootHover * 1.15 + grauPump * 0.015,
        -pegZ - lFootHover * 0.40
      );
      this.chassisPivot.localToWorld(this._vTarget);
      this._vPole.set(
        0.34 + leanLeft * 0.16 + grauKneeL * 0.22,
        0.56 + leanLeft * 0.05 + grauKneeL * 0.24 + lFootHover * 0.35,
        -0.20 - kneeOutL
      );
      this.chassisPivot.localToWorld(this._vPole);
      this.solveTwoBoneIK(lUpLeg, lLeg, lFoot, this._vTarget, this._vPole);
      this.alignFootToPeg(lFoot, -0.10 - grauKneeL * 0.25 - lFootHover * 1.1, -0.02);
    }
    if (rUpLeg && rLeg && rFoot) {
      // Right foot slides cleanly forward onto the rear brake pedal and presses smoothly without hyper-flexing
      this._vTarget.set(
        pegX - 0.004 + rearBrakeVal * 0.036,
        pegY + 0.006 - rearBrakeVal * 0.010,
        pegZ + 0.002 - rearBrakeVal * 0.010
      );
      this.chassisPivot.localToWorld(this._vTarget);
      this._vPole.set(
        0.34 + leanRight * 0.16 + grauKneeR * 0.22 + rearBrakeVal * 0.020,
        0.56 + leanRight * 0.05 + grauKneeR * 0.24 - rearBrakeVal * 0.014,
        0.20 + kneeOutR - rearBrakeVal * 0.014
      );
      this.chassisPivot.localToWorld(this._vPole);
      this.solveTwoBoneIK(rUpLeg, rLeg, rFoot, this._vTarget, this._vPole);
      this.alignFootToPeg(rFoot, 0.10 + grauKneeR * 0.25 - rearBrakeVal * 0.04, -0.02 - rearBrakeVal * 0.19);
    }

    // Solve Arms onto Handlebar Grips with solid, hinge-aligned athletic posture (zero corkscrew twist)
    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const lHand = this.findBone('LeftHand_');
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');
    const rHand = this.findBone('RightHand_');

    const elbowBaseY = 1.045 + wheelieNorm * 0.014 + stoppieNorm * 0.020;
    // Right arm is configured for active throttle & front brake lever control:
    // Flared elbow for lever leverage, bracing forward when squeezing front brake
    const elbowDropR =
      elbowBaseY +
      0.010 +
      frontBrake * 0.022 -
      throttle * 0.016 -
      leanRight * 0.028 +
      leanLeft * 0.014;
    const elbowDropL =
      elbowBaseY -
      0.008 +
      frontBrake * 0.010 -
      leanLeft * 0.030 +
      leanRight * 0.016;
    const elbowOutR = 0.38 + frontBrake * 0.030 - leanRight * 0.026 + leanLeft * 0.016;
    const elbowOutL = 0.33 + frontBrake * 0.012 - leanLeft * 0.026 + leanRight * 0.016;
    const elbowFwdR = -0.022 + frontBrake * 0.026 - throttle * 0.012 + leanRight * 0.018;
    const elbowFwdL = -0.045 - frontBrake * 0.008 + leanLeft * 0.018;

    // Guarantee both hands stay 100% glued to the handlebar grips across wheelie, molejo, braking & full steer:
    // protract shoulders & pull upper body slightly toward bars whenever reach approaches max arm extension.
    if (lArm && rArm) {
      let maxReachDist = 0;
      if (lShoulder) {
        this.leftGripTarget.getWorldPosition(this._vTarget);
        lArm.getWorldPosition(this._vA);
        const dL = this._vA.distanceTo(this._vTarget);
        const extraL = smoothstep(0.36, 0.50, dL) * 0.50;
        if (extraL > 0.001) {
          this.applyLocalEuler(lShoulder, extraL * 0.25, -extraL, 0);
        }
      }
      if (rShoulder) {
        this.rightGripTarget.getWorldPosition(this._vTarget);
        rArm.getWorldPosition(this._vA);
        const dR = this._vA.distanceTo(this._vTarget);
        const extraR = smoothstep(0.36, 0.50, dR) * 0.50;
        if (extraR > 0.001) {
          this.applyLocalEuler(rShoulder, extraR * 0.25, extraR, 0);
        }
      }
      lArm.updateWorldMatrix(true, false);
      rArm.updateWorldMatrix(true, false);

      this.leftGripTarget.getWorldPosition(this._vTarget);
      lArm.getWorldPosition(this._vA);
      maxReachDist = Math.max(maxReachDist, this._vA.distanceTo(this._vTarget));

      this.rightGripTarget.getWorldPosition(this._vTarget);
      rArm.getWorldPosition(this._vA);
      maxReachDist = Math.max(maxReachDist, this._vA.distanceTo(this._vTarget));

      if (maxReachDist > 0.472) {
        const deficit = maxReachDist - 0.472;
        this.riderRoot.position.x += Math.min(0.12, deficit * 0.92);
        this.riderRoot.position.z *= Math.max(0.20, 1 - deficit * 5.2);
        if (spine2) {
          this.applyLocalEuler(spine2, Math.min(0.26, deficit * 1.55), 0, 0);
        }
        this.riderRoot.updateWorldMatrix(false, false);
        lArm.updateWorldMatrix(true, false);
        rArm.updateWorldMatrix(true, false);
      }
    }

    if (rArm && rFore && rHand) {
      this.rightGripTarget.getWorldPosition(this._vTarget);
      this.steeringHeadPivot.getWorldQuaternion(this._qSteer);
      const brakeLeverPull = THREE.MathUtils.clamp(frontBrake, 0, 1);
      // Place right wrist further back (-X) and lower down (+Y) so hand and fingers align snugly with the front brake lever
      const rGripShiftX = -0.045 - brakeLeverPull * 0.006;
      const rGripShiftY = 0.002 - brakeLeverPull * 0.003;
      this._vOffset.set(rGripShiftX, rGripShiftY, 0.004).applyQuaternion(this._qSteer);
      this._vTarget.add(this._vOffset);

      this._vPole.set(elbowFwdR, elbowDropR, elbowOutR);
      this.chassisPivot.localToWorld(this._vPole);
      this.solveArmIK(rArm, rFore, rHand, this._vTarget, this._vPole, 'right');
      // Pass frontBrake directly to alignHandToGrip so the right hand rotates and pulls into the brake lever
      this.alignHandToGrip(rHand, 'right', throttle, frontBrake, 1);
      this.twistForearmToHand(rFore, rHand, 0.42);

      // Right hand is continuously holding and controlling the front brake lever ("segurando o freio"):
      // Index & middle fingers are hooked snugly around the front brake lever blade;
      // when squeezing the brake, they pull the lever back tightly against the throttle grip;
      // ring & pinky fingers wrap firmly around the throttle grip barrel, and thumb cradles underneath.
      this.poseHandFingers('right', {
        thumb: { curl: 0.58 + brakeLeverPull * 0.08, spread: -0.22 },
        index: { curl: 0.62 + brakeLeverPull * 0.34, spread: 0.01 },
        middle: { curl: 0.65 + brakeLeverPull * 0.30, spread: -0.02 },
        ring: { curl: 0.90 + throttle * 0.06, spread: -0.04 },
        pinky: { curl: 0.92 + throttle * 0.06, spread: -0.06 },
      });
    }

    if (lArm && lFore && lHand) {
      this.leftGripTarget.getWorldPosition(this._vTarget);
      this.steeringHeadPivot.getWorldQuaternion(this._qSteer);
      this._vOffset.set(-0.016, 0.028, 0.0).applyQuaternion(this._qSteer);
      this._vTarget.add(this._vOffset);

      this._vPole.set(elbowFwdL, elbowDropL, -elbowOutL);
      this.chassisPivot.localToWorld(this._vPole);
      this.solveArmIK(lArm, lFore, lHand, this._vTarget, this._vPole, 'left');
      // On CG 160 Titan: left hand holds the handlebar while throwing a signature ✌️ peace sign
      this.alignHandToGrip(lHand, 'left', 0, clutchTapAnim, 1, true);
      this.twistForearmToHand(lFore, lHand, 0.42);

      const clutchFold = clutchTapAnim * 0.36;
      this.poseHandFingers('left', {
        thumb: { curl: 0.56, spread: -0.22 },
        index: { curl: -0.08 + clutchFold, spread: 0.25 },
        middle: { curl: -0.04 + clutchFold, spread: -0.16 },
        ring: { curl: 0.82, spread: 0 },
        pinky: { curl: 0.84, spread: 0 },
      });
    }
  }

  /**
   * Positions and orients the active emote arm(s) + real 5-finger gesture directly in camera/screen
   * space so holding & dragging anywhere on the screen steers the rider's arm in real time.
   */
  public applyInteractiveEmote(
    camera: THREE.Camera,
    isFirstPerson: boolean,
    isOnFoot: boolean,
    dragX: number,
    dragY: number,
    physics: BikePhysics
  ): void {
    const eb = isOnFoot ? this.smoothEmoteBlend : Math.max(physics.noHandBlend, this.smoothEmoteBlend);
    if (eb <= 0.005) return;
    const em: Exclude<EmoteId, 'none'> =
      this.activeEmoteType !== 'none' ? this.activeEmoteType : 'salve';

    camera.updateMatrixWorld(true);
    this._camPos.setFromMatrixPosition(camera.matrixWorld);
    this._camRight.setFromMatrixColumn(camera.matrixWorld, 0).normalize();
    this._camUp.setFromMatrixColumn(camera.matrixWorld, 1).normalize();
    this._camFwd.setFromMatrixColumn(camera.matrixWorld, 2).multiplyScalar(-1).normalize();
    this._camBack.copy(this._camFwd).negate();

    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const lHand = this.findBone('LeftHand_');
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');
    const rHand = this.findBone('RightHand_');

    const t = this.animTime;
    const dx = THREE.MathUtils.clamp(dragX, -1, 1);
    const dy = THREE.MathUtils.clamp(dragY, -1, 1);
    const useRightToo = em === 'celebrate' || em === 'clap' || (em === 'flex' && isOnFoot);

    // Subtle procedural life per gesture
    const salveWaveX = em === 'salve' ? Math.sin(t * 6.5) * 0.025 : 0;
    const salveWaveY = em === 'salve' ? Math.cos(t * 6.5) * 0.015 : 0;
    const shakaRock = em === 'hang_loose' ? Math.sin(t * 6.8) * 0.28 : 0;
    const celebrateBounce = em === 'celebrate' ? Math.sin(t * 7.2) * 0.032 : 0;
    const clapGap = em === 'clap' ? 0.03 + Math.abs(Math.sin(t * 9.0)) * 0.11 : 0;

    // Default ergonomic vertical framing per gesture when drag is near (0,0)
    const baseY =
      em === 'salute'
        ? 0.14
        : em === 'celebrate'
          ? 0.16
          : em === 'clap'
            ? -0.06
            : em === 'middle_finger'
              ? -0.02
              : 0.01;
    const baseX =
      em === 'middle_finger'
        ? -0.09
        : em === 'flex' && !useRightToo
          ? -0.10
          : em === 'salute'
            ? -0.03
            : 0;

    if (lArm && lFore && lHand) {
      lHand.getWorldPosition(this._emPosL);
      lHand.getWorldQuaternion(this._qStartL);

      const leftSpreadX = em === 'celebrate' ? -0.17 : em === 'clap' ? -clapGap : em === 'flex' && useRightToo ? -0.18 : 0;

      if (isFirstPerson) {
        this._vTarget
          .copy(this._camPos)
          .addScaledVector(this._camFwd, em === 'salute' ? 0.30 : em === 'middle_finger' ? 0.39 : 0.37)
          .addScaledVector(this._camRight, baseX + leftSpreadX + dx * 0.29 + salveWaveX)
          .addScaledVector(this._camUp, baseY + dy * 0.22 + salveWaveY + celebrateBounce);

        lArm.getWorldPosition(this._vA);
        this._emPoleL
          .copy(em === 'middle_finger' ? this._vTarget : this._vA)
          .addScaledVector(this._camUp, em === 'middle_finger' ? -0.28 : -0.25)
          .addScaledVector(this._camRight, (em === 'middle_finger' ? -0.03 : -0.18) + dx * 0.14)
          .addScaledVector(this._camFwd, em === 'middle_finger' ? 0.02 : 0.06);
      } else {
        lArm.getWorldPosition(this._vA);
        this._vTarget
          .copy(this._vA)
          .addScaledVector(this._camUp, 0.24 + baseY * 0.6 + dy * 0.36 + salveWaveY + celebrateBounce)
          .addScaledVector(this._camRight, 0.04 + leftSpreadX + dx * 0.40 + salveWaveX)
          .addScaledVector(this._camBack, 0.28);

        this._emPoleL
          .copy(em === 'middle_finger' ? this._vTarget : this._vA)
          .addScaledVector(this._camUp, -0.26)
          .addScaledVector(this._camRight, (em === 'middle_finger' ? -0.04 : -0.20) + dx * 0.12)
          .addScaledVector(this._camFwd, 0.06);
      }

      this._vTarget.lerpVectors(this._emPosL, this._vTarget, eb);
      this.solveArmIK(lArm, lFore, lHand, this._vTarget, this._emPoleL, 'left');

      this.buildEmoteHandBasis('left', em, shakaRock, dx, dy, this._qGrip);
      const lOff = this.isCustomRider ? this.boneOffsets.get(lHand) : undefined;
      if (lOff) this._qGrip.multiply(lOff.qOff);
      this._qWorld.copy(this._qStartL).slerp(this._qGrip, eb);
      lHand.parent!.getWorldQuaternion(this._qParent);
      lHand.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
      lHand.updateWorldMatrix(false, false);
      this.twistForearmToHand(lFore, lHand, (em === 'middle_finger' ? 0.96 : 0.65) * eb, 1.35);

      this.applyEmoteFingerPose('left', em, eb, isOnFoot ? 0.18 : 0.84);
    }

    if (useRightToo && rArm && rFore && rHand) {
      rHand.getWorldPosition(this._emPosR);
      rHand.getWorldQuaternion(this._qStartR);

      const rightSpreadX = em === 'celebrate' ? 0.17 : em === 'clap' ? clapGap : 0.18;

      if (isFirstPerson) {
        this._vTarget
          .copy(this._camPos)
          .addScaledVector(this._camFwd, 0.37)
          .addScaledVector(this._camRight, rightSpreadX + dx * 0.29)
          .addScaledVector(this._camUp, baseY + dy * 0.22 - celebrateBounce);

        rArm.getWorldPosition(this._vA);
        this._emPoleR
          .copy(this._vA)
          .addScaledVector(this._camUp, -0.25)
          .addScaledVector(this._camRight, 0.18 + dx * 0.14)
          .addScaledVector(this._camFwd, 0.06);
      } else {
        rArm.getWorldPosition(this._vA);
        this._vTarget
          .copy(this._vA)
          .addScaledVector(this._camUp, 0.24 + baseY * 0.6 + dy * 0.36 - celebrateBounce)
          .addScaledVector(this._camRight, -0.04 + rightSpreadX + dx * 0.40)
          .addScaledVector(this._camBack, 0.28);

        this._emPoleR
          .copy(this._vA)
          .addScaledVector(this._camUp, -0.22)
          .addScaledVector(this._camRight, 0.20 + dx * 0.12)
          .addScaledVector(this._camFwd, 0.08);
      }

      this._vTarget.lerpVectors(this._emPosR, this._vTarget, eb);
      this.solveArmIK(rArm, rFore, rHand, this._vTarget, this._emPoleR, 'right');

      this.buildEmoteHandBasis('right', em, shakaRock, dx, dy, this._qGrip);
      const rOff = this.isCustomRider ? this.boneOffsets.get(rHand) : undefined;
      if (rOff) this._qGrip.multiply(rOff.qOff);
      this._qWorld.copy(this._qStartR).slerp(this._qGrip, eb);
      rHand.parent!.getWorldQuaternion(this._qParent);
      rHand.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
      rHand.updateWorldMatrix(false, false);
      this.twistForearmToHand(rFore, rHand, 0.55 * eb);

      this.applyEmoteFingerPose('right', em, eb, isOnFoot ? 0.18 : 0.84);
    }
  }

  /**
   * Positions the 3D iPhone 17 Pro in front of the 1st-person camera (or rider chest in 3rd-person)
   * with smooth pull-out animation, walking/breathing motion, tap feedback, and full arm/finger IK grip.
   */
  public applyPhoneHoldPose(
    phoneRoot: THREE.Object3D,
    camera: THREE.Camera,
    isFirstPerson: boolean,
    isOnFoot: boolean,
    phoneBlend: number,
    tapPulse: number,
    walkSpeed: number,
    walkPhase: number
  ): void {
    const visible = phoneBlend > 0.015;
    phoneRoot.visible = visible;
    if (!visible) return;

    const s = smoothstep(0, 1, phoneBlend);
    const side: 'left' | 'right' = isOnFoot ? 'right' : 'left';
    const sideSign = side === 'right' ? 1 : -1;

    const shoulder = this.findBone(side === 'right' ? 'RightShoulder_' : 'LeftShoulder_');
    const arm = this.findBone(side === 'right' ? 'RightArm_' : 'LeftArm_');
    const fore = this.findBone(side === 'right' ? 'RightForeArm_' : 'LeftForeArm_');
    const hand = this.findBone(side === 'right' ? 'RightHand_' : 'LeftHand_');
    const neck = this.findBone('Neck_');
    const head = this.findBone('Head_');

    camera.updateMatrixWorld(true);
    this._camPos.setFromMatrixPosition(camera.matrixWorld);
    this._camRight.setFromMatrixColumn(camera.matrixWorld, 0).normalize();
    this._camUp.setFromMatrixColumn(camera.matrixWorld, 1).normalize();
    this._camFwd.setFromMatrixColumn(camera.matrixWorld, 2).multiplyScalar(-1).normalize();
    this._camBack.copy(this._camFwd).negate();

    const breathY = Math.sin(this.animTime * 2.0) * 0.0020;
    const breathX = Math.cos(this.animTime * 1.4) * 0.0012;
    const walkMag = isOnFoot ? THREE.MathUtils.clamp(walkSpeed / 3.5, 0, 1) : 0;
    const walkBobY = Math.sin(walkPhase * 2) * 0.0040 * walkMag;
    const walkBobX = Math.cos(walkPhase) * 0.0032 * walkMag;
    const riseArc = Math.sin(s * Math.PI) * 0.022;

    if (isFirstPerson) {
      // Smooth pull-up from pocket into natural centered-ergonomic 1st-person viewing pose
      const dropY = (1 - s) * -0.34 + riseArc;
      const fwdDist = THREE.MathUtils.lerp(0.19, isOnFoot ? 0.258 : 0.242, s) + tapPulse * 0.006;
      const latOffset =
        THREE.MathUtils.lerp(sideSign * 0.11, sideSign * 0.012, s) + breathX + walkBobX;
      const vertOffset = -0.018 + dropY + breathY + walkBobY - tapPulse * 0.004;

      this._phPos
        .copy(this._camPos)
        .addScaledVector(this._camFwd, fwdDist)
        .addScaledVector(this._camRight, latOffset)
        .addScaledVector(this._camUp, vertOffset);

      // Subtle natural human wrist tilt toward viewer & slight inward cant
      const pitchBack = 0.15 + (1 - s) * 0.62 - tapPulse * 0.04;
      const yawInward = sideSign * (-0.07 - (1 - s) * 0.40);
      const rollTilt = sideSign * (-0.055 - (1 - s) * 0.22);

      this._phFront
        .copy(this._camBack)
        .multiplyScalar(Math.cos(pitchBack))
        .addScaledVector(this._camUp, Math.sin(pitchBack))
        .addScaledVector(this._camRight, yawInward)
        .normalize();

      this._phUp
        .copy(this._camUp)
        .addScaledVector(this._camRight, rollTilt)
        .addScaledVector(this._phFront, -this._camUp.dot(this._phFront))
        .normalize();

      this._phRight.crossVectors(this._phUp, this._phFront).normalize();
      this._phUp.crossVectors(this._phFront, this._phRight).normalize();
    } else {
      // 3rd-person: rider raises phone in front of chest/head and looks cleanly at the screen
      this.riderRoot.updateMatrixWorld(true);
      this._phRiderFwd.setFromMatrixColumn(this.riderRoot.matrixWorld, 2).normalize();
      this._phRiderRight.setFromMatrixColumn(this.riderRoot.matrixWorld, 0).multiplyScalar(-1).normalize();

      const chest = this.findBone('Spine2_');
      if (chest) {
        chest.getWorldPosition(this._phPos);
      } else {
        this._phPos.setFromMatrixPosition(this.riderRoot.matrixWorld).addScaledVector(this._upVec, 1.24);
      }

      this._phEye
        .copy(this._phPos)
        .addScaledVector(this._upVec, 0.39)
        .addScaledVector(this._phRiderFwd, 0.04);

      const fwdReach = isOnFoot ? 0.32 : 0.33;
      const upLift = isOnFoot ? 0.13 : 0.17;
      this._phPos
        .addScaledVector(this._phRiderFwd, fwdReach * s + 0.12 * (1 - s))
        .addScaledVector(this._upVec, upLift - (1 - s) * 0.28 + breathY + walkBobY)
        .addScaledVector(this._phRiderRight, sideSign * 0.065);

      this._phFront.subVectors(this._phEye, this._phPos).normalize();
      this._phRight.crossVectors(this._upVec, this._phFront).normalize();
      this._phUp.crossVectors(this._phFront, this._phRight).normalize();

      if (neck) this.applyLocalEuler(neck, 0.16 * s, sideSign * -0.06 * s, 0);
      if (head) this.applyLocalEuler(head, 0.18 * s, 0, 0);
      this.riderRoot.updateMatrixWorld(true);
    }

    if (!arm || !fore || !hand || !hand.parent) {
      this._mBasis.makeBasis(this._phRight, this._phUp, this._phFront);
      phoneRoot.position.copy(this._phPos);
      phoneRoot.quaternion.setFromRotationMatrix(this._mBasis);
      phoneRoot.updateMatrixWorld(true);
      return;
    }

    // Symmetrical rider-space shoulder protraction for natural reach on either hand
    if (shoulder) {
      this.applyRiderSpaceEuler(shoulder, 0, sideSign * 0.14 * s, 0);
    }

    const startHandPos = side === 'right' ? this._emPosR : this._emPosL;
    const startHandQuat = side === 'right' ? this._qStartR : this._qStartL;
    const poleVec = side === 'right' ? this._emPoleR : this._emPoleL;

    hand.getWorldPosition(startHandPos);
    hand.getWorldQuaternion(startHandQuat);
    arm.getWorldPosition(this._vA);

    // Place wrist cleanly behind bottom-outer corner so thick palm muscle sits behind the back glass
    // and never overlaps the front display edge from the camera's perspective.
    this._vTarget
      .copy(this._phPos)
      .addScaledVector(this._phUp, -0.092)
      .addScaledVector(this._phRight, sideSign * 0.044)
      .addScaledVector(this._phFront, -0.024);

    // Guarantee hand stays locked to the phone even at steep look/lean angles by clamping reach to arm length
    this._ikToTarget.subVectors(this._vTarget, this._vA);
    const desiredReach = this._ikToTarget.length();
    const maxReach = 0.478;
    if (desiredReach > maxReach && desiredReach > 1e-4) {
      const pullScale = (desiredReach - maxReach) / desiredReach;
      this._phPos.addScaledVector(this._ikToTarget, -pullScale);
      this._vTarget.addScaledVector(this._ikToTarget, -pullScale);
    }

    this._mBasis.makeBasis(this._phRight, this._phUp, this._phFront);
    phoneRoot.position.copy(this._phPos);
    phoneRoot.quaternion.setFromRotationMatrix(this._mBasis);
    phoneRoot.updateMatrixWorld(true);

    this._vTarget.lerpVectors(startHandPos, this._vTarget, s);

    if (isFirstPerson) {
      poleVec
        .copy(this._vA)
        .addScaledVector(this._upVec, -0.28)
        .addScaledVector(this._camRight, sideSign * 0.18)
        .addScaledVector(this._camFwd, 0.06);
    } else {
      poleVec
        .copy(this._vA)
        .addScaledVector(this._upVec, -0.26)
        .addScaledVector(this._phRiderRight, sideSign * 0.22)
        .addScaledVector(this._phRiderFwd, 0.05);
    }

    this.solveArmIK(arm, fore, hand, this._vTarget, poleVec, side);

    // Build orthonormal hand basis keeping +Y_hand (knuckles/fingers) exact in the phone back plane
    // and orthogonalizing +Z_hand (palm normal) against +Y_hand so fingers don't dive behind the phone.
    this._vHY
      .copy(this._phUp)
      .multiplyScalar(0.78)
      .addScaledVector(this._phRight, -sideSign * 0.62)
      .addScaledVector(this._phFront, 0.02)
      .normalize();
    this._vHZ
      .copy(this._phFront)
      .multiplyScalar(0.98)
      .addScaledVector(this._phRight, -sideSign * 0.18)
      .normalize();
    this._vHX.crossVectors(this._vHY, this._vHZ).normalize();
    this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
    this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
    this._qGrip.setFromRotationMatrix(this._mBasis);
    const hOff = this.isCustomRider ? this.boneOffsets.get(hand) : undefined;
    if (hOff) this._qGrip.multiply(hOff.qOff);

    this._qWorld.copy(startHandQuat).slerp(this._qGrip, s);
    hand.parent.getWorldQuaternion(this._qParent);
    hand.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
    hand.updateWorldMatrix(false, false);
    this.twistForearmToHand(fore, hand, s, Math.PI * 0.85);

    // Zero-occlusion grip: thumb hugs outer titanium bezel without covering the display,
    // index supports upper back, and middle/ring/pinky cradle the far outer edge cleanly.
    const baseCurl = isOnFoot ? 0.20 : 0.85;
    this.poseHandFingers(side, {
      thumb: {
        curl: THREE.MathUtils.lerp(0.24, -0.06, s),
        spread: THREE.MathUtils.lerp(0.05, 0.20, s),
      },
      index: { curl: THREE.MathUtils.lerp(baseCurl, 0.06, s), spread: -0.04 * s },
      middle: { curl: THREE.MathUtils.lerp(baseCurl, 0.12, s), spread: -0.01 * s },
      ring: { curl: THREE.MathUtils.lerp(baseCurl, 0.22, s), spread: 0.02 * s },
      pinky: { curl: THREE.MathUtils.lerp(baseCurl, 0.36, s), spread: 0.06 * s },
    });
  }

  private buildEmoteHandBasis(
    side: 'left' | 'right',
    em: EmoteId,
    shakaRock: number,
    dx: number,
    dy: number,
    outQuat: THREE.Quaternion
  ): void {
    // In bike_rider.glb: +Y = fingertips, +Z = palm, +X(left) = pinky / +X(right) = thumb.
    if (em === 'salve') {
      // Palm faces viewer/screen cleanly with Peace/V sign upright, tilted slightly with drag
      this._vHY.copy(this._camUp).addScaledVector(this._camRight, dx * 0.25).normalize();
      this._vHZ.copy(this._camBack).addScaledVector(this._camRight, side === 'left' ? 0.18 : -0.18).normalize();
    } else if (em === 'middle_finger') {
      // 🖕🏻 Middle finger straight upright aligned with camera screen vertical & flat palm facing viewer
      this._vHY.copy(this._camUp).addScaledVector(this._camRight, dx * 0.15).normalize();
      this._vHZ.copy(this._camBack).addScaledVector(this._camUp, 0.04 + dy * 0.08).normalize();
    } else if (em === 'hang_loose') {
      // Shaka tilted diagonally so thumb & pinky form iconic 🤙 silhouette with playful rock
      const tilt = 0.62 + shakaRock;
      this._vHY
        .copy(this._camUp)
        .multiplyScalar(Math.cos(tilt))
        .addScaledVector(this._camRight, Math.sin(tilt))
        .normalize();
      this._vHZ
        .copy(this._camBack)
        .addScaledVector(this._camUp, 0.22 + dy * 0.15)
        .normalize();
    } else if (em === 'salute') {
      // Knife-hand angled inward toward brow/forehead, palm facing down-forward
      this._vHY
        .copy(this._camUp)
        .multiplyScalar(0.55)
        .addScaledVector(this._camRight, side === 'left' ? 0.82 : -0.82)
        .normalize();
      this._vHZ
        .copy(this._camUp)
        .multiplyScalar(-0.75)
        .addScaledVector(this._camBack, 0.55)
        .normalize();
    } else if (em === 'flex') {
      // Bicep curl fist facing inward toward viewer/head
      this._vHY.copy(this._camUp).addScaledVector(this._camBack, 0.25).normalize();
      this._vHZ
        .copy(this._camRight)
        .multiplyScalar(side === 'left' ? 0.65 : -0.65)
        .addScaledVector(this._camBack, 0.72)
        .normalize();
    } else if (em === 'clap') {
      // Palms facing inward toward each other and tilted slightly toward screen
      this._vHY.copy(this._camUp).addScaledVector(this._camFwd, 0.22).normalize();
      this._vHZ
        .copy(this._camRight)
        .multiplyScalar(side === 'left' ? 0.86 : -0.86)
        .addScaledVector(this._camBack, 0.46)
        .normalize();
    } else {
      // celebrate 🙌: palms open forward/toward viewer
      this._vHY.copy(this._camUp).addScaledVector(this._camRight, side === 'left' ? -0.14 : 0.14).normalize();
      this._vHZ.copy(this._camBack).addScaledVector(this._camUp, 0.18).normalize();
    }

    this._vHX.crossVectors(this._vHY, this._vHZ).normalize();
    this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
    this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
    outQuat.setFromRotationMatrix(this._mBasis);
  }

  private applyEmoteFingerPose(
    side: 'left' | 'right',
    em: EmoteId,
    blend: number,
    baseCurl: number
  ): void {
    type FingerTarget = { curl: number; spread: number };
    let target: Record<'thumb' | 'index' | 'middle' | 'ring' | 'pinky', FingerTarget>;

    if (em === 'salve') {
      // ✌️ Peace / V sign (index & middle 100% straight upright, ring/pinky/thumb cleanly curled)
      target = {
        thumb: { curl: 0.74, spread: -0.26 },
        index: { curl: 0.0, spread: 0.24 },
        middle: { curl: 0.0, spread: -0.18 },
        ring: { curl: 1.04, spread: 0 },
        pinky: { curl: 1.04, spread: 0 },
      };
    } else if (em === 'middle_finger') {
      // 🖕🏻 Middle finger 100% arrow-straight upright, index/ring/pinky/thumb tightly tucked without palm clipping
      target = {
        thumb: { curl: 0.76, spread: -0.34 },
        index: { curl: 1.04, spread: 0.02 },
        middle: { curl: 0.0, spread: 0 },
        ring: { curl: 1.04, spread: -0.02 },
        pinky: { curl: 1.04, spread: -0.04 },
      };
    } else if (em === 'hang_loose') {
      // 🤙 Hang Loose / Shaka: thumb & pinky straight & splayed, middle 3 tucked cleanly into palm
      target = {
        thumb: { curl: -0.10, spread: 0.28 },
        index: { curl: 1.04, spread: 0 },
        middle: { curl: 1.04, spread: 0 },
        ring: { curl: 1.04, spread: 0 },
        pinky: { curl: 0.0, spread: -0.38 },
      };
    } else if (em === 'salute') {
      // 🫡 Flat knife-hand salute (all 4 fingers arrow-straight & together)
      target = {
        thumb: { curl: 0.20, spread: -0.22 },
        index: { curl: 0.0, spread: -0.06 },
        middle: { curl: 0.0, spread: -0.02 },
        ring: { curl: 0.0, spread: 0.04 },
        pinky: { curl: 0.0, spread: 0.10 },
      };
    } else if (em === 'flex') {
      // 💪 Tight fist
      target = {
        thumb: { curl: 0.78, spread: -0.32 },
        index: { curl: 1.06, spread: 0 },
        middle: { curl: 1.06, spread: 0 },
        ring: { curl: 1.06, spread: 0 },
        pinky: { curl: 1.06, spread: 0 },
      };
    } else if (em === 'celebrate') {
      // 🙌 Wide splayed celebratory hand (all fingers straight UP)
      target = {
        thumb: { curl: 0.0, spread: 0.22 },
        index: { curl: 0.0, spread: 0.22 },
        middle: { curl: 0.0, spread: 0.06 },
        ring: { curl: 0.0, spread: -0.08 },
        pinky: { curl: 0.0, spread: -0.24 },
      };
    } else {
      // 👏 Flat clapping hand (all fingers straight UP)
      target = {
        thumb: { curl: 0.08, spread: 0.05 },
        index: { curl: 0.0, spread: 0.05 },
        middle: { curl: 0.0, spread: 0 },
        ring: { curl: 0.0, spread: -0.05 },
        pinky: { curl: 0.0, spread: -0.10 },
      };
    }

    this.poseHandFingers(side, {
      thumb: {
        curl: THREE.MathUtils.lerp(0.24, target.thumb.curl, blend),
        spread: THREE.MathUtils.lerp(0.06, target.thumb.spread, blend),
      },
      index: {
        curl: THREE.MathUtils.lerp(baseCurl, target.index.curl, blend),
        spread: target.index.spread * blend,
      },
      middle: {
        curl: THREE.MathUtils.lerp(baseCurl, target.middle.curl, blend),
        spread: target.middle.spread * blend,
      },
      ring: {
        curl: THREE.MathUtils.lerp(baseCurl, target.ring.curl, blend),
        spread: target.ring.spread * blend,
      },
      pinky: {
        curl: THREE.MathUtils.lerp(baseCurl, target.pinky.curl, blend),
        spread: target.pinky.spread * blend,
      },
    });
  }

  private poseUniformFingers(side: 'left' | 'right', curl: number): void {
    this.poseHandFingers(side, {
      thumb: { curl: curl * 0.45, spread: 0.02 },
      index: { curl },
      middle: { curl },
      ring: { curl },
      pinky: { curl },
    });
  }

  private poseHandFingers(
    side: 'left' | 'right',
    pose: Record<'thumb' | 'index' | 'middle' | 'ring' | 'pinky', { curl: number; spread?: number }>
  ): void {
    const cache = side === 'left' ? this.lastFingerPoseL : this.lastFingerPoseR;
    const hasCache = side === 'left' ? this.hasFingerPoseL : this.hasFingerPoseR;
    const tC = pose.thumb.curl;
    const tS = pose.thumb.spread ?? 0;
    const iC = pose.index.curl;
    const iS = pose.index.spread ?? 0;
    const mC = pose.middle.curl;
    const mS = pose.middle.spread ?? 0;
    const rC = pose.ring.curl;
    const rS = pose.ring.spread ?? 0;
    const pC = pose.pinky.curl;
    const pS = pose.pinky.spread ?? 0;

    if (
      hasCache &&
      Math.abs(cache[0] - tC) < 0.0025 &&
      Math.abs(cache[1] - tS) < 0.0025 &&
      Math.abs(cache[2] - iC) < 0.0025 &&
      Math.abs(cache[3] - iS) < 0.0025 &&
      Math.abs(cache[4] - mC) < 0.0025 &&
      Math.abs(cache[5] - mS) < 0.0025 &&
      Math.abs(cache[6] - rC) < 0.0025 &&
      Math.abs(cache[7] - rS) < 0.0025 &&
      Math.abs(cache[8] - pC) < 0.0025 &&
      Math.abs(cache[9] - pS) < 0.0025
    ) {
      return;
    }

    cache[0] = tC;
    cache[1] = tS;
    cache[2] = iC;
    cache[3] = iS;
    cache[4] = mC;
    cache[5] = mS;
    cache[6] = rC;
    cache[7] = rS;
    cache[8] = pC;
    cache[9] = pS;
    if (side === 'left') this.hasFingerPoseL = true;
    else this.hasFingerPoseR = true;

    const list = side === 'left' ? this.leftFingerBones : this.rightFingerBones;
    const sign = side === 'left' ? 1 : -1;
    for (let i = 0; i < list.length; i++) {
      const item = list[i];
      const spec = pose[item.slot];
      const rx = spec.curl * item.weight;
      const rz = item.isProximal ? (spec.spread ?? 0) * sign : 0;
      item.bone.quaternion.copy(item.straight);
      this._euler.set(rx, 0, rz, 'XYZ');
      this._qDelta.setFromEuler(this._euler);
      if (item.qOff && item.qOffInv) {
        this._qDelta.premultiply(item.qOffInv).multiply(item.qOff);
      }
      item.bone.quaternion.multiply(this._qDelta);
    }
  }

  private alignFootToPeg(foot: THREE.Bone, toeOutYaw: number, toePitch = 0): void {
    if (!foot.parent) return;
    foot.parent.updateWorldMatrix(true, false);
    this.chassisPivot.getWorldQuaternion(this._qSteer);
    // bike_rider.glb foot bone has +Y = toes, +Z = top of foot UP, -X = left
    this._vHY.set(Math.cos(toeOutYaw), toePitch, Math.sin(toeOutYaw)).normalize();
    this._vHZ.set(0.06, 0.998, 0).normalize();
    this._vHX.crossVectors(this._vHY, this._vHZ).normalize();
    this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
    this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
    this._qGrip.setFromRotationMatrix(this._mBasis).premultiply(this._qSteer);
    const footOff = this.isCustomRider ? this.boneOffsets.get(foot) : undefined;
    if (footOff) this._qGrip.multiply(footOff.qOff);
    foot.parent.getWorldQuaternion(this._qParent);
    foot.quaternion.copy(this._qParent).invert().multiply(this._qGrip);
    foot.updateWorldMatrix(false, false);
  }

  /**
   * Aligns bike_rider.glb hand bones (+Y = fingers, +Z = palm, -Z = back of hand)
   * directly in steeringHeadPivot's swept-bar frame.
   */
  private alignHandToGrip(
    hand: THREE.Bone,
    side: 'left' | 'right',
    throttle: number,
    brakeOrClutch: number,
    weight: number,
    cgPeaceHold = false
  ): void {
    if (weight <= 0.001 || !hand.parent) return;

    this.steeringHeadPivot.getWorldQuaternion(this._qSteer);

    // Left hand holds the bar while displaying the signature Brazilian ✌️ peace sign over the clutch;
    // Right hand rests on the throttle grip and aims fingers forward-down over the front brake lever blade.
    let fingerAngle: number;
    if (side === 'left') {
      fingerAngle = cgPeaceHold
        ? 0.06 - brakeOrClutch * 0.18 + Math.sin(this.animTime * 2.2) * 0.025
        : 0.04 - brakeOrClutch * 0.16;
    } else {
      // Right hand: firmly holding and wrapping around the front brake lever blade.
      // Squeezes lever down/back during braking and rolls wrist backward on throttle.
      fingerAngle = -0.02 - brakeOrClutch * 0.14 - throttle * 0.08;
    }
    const cosA = Math.cos(fingerAngle);
    const sinA = Math.sin(fingerAngle);

    if (side === 'left') {
      // +Y = fingers forward & slightly outward, -X = thumb inward, +Z = palm down
      this._vHY.set(cosA, sinA, -0.24).normalize();
      this._vHX.set(-0.24, -0.02, -0.97).normalize(); // -thumbDir
      this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
      this._vHX.crossVectors(this._vHY, this._vHZ).normalize();
    } else {
      // Right hand: +Y = fingers aimed straight along the front brake lever blade (+0.20 outward along lever)
      // +X = thumb inward (-Z in bike), +Z = palm down (-Y in bike)
      // Back of hand faces upward/backward toward rider and cockpit camera
      this._vHY.set(cosA, sinA, 0.20).normalize();
      this._vHX.set(0.12, 0.02 - brakeOrClutch * 0.04, -0.99).normalize(); // +thumbDir inward toward bike stem
      this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
      this._vHX.crossVectors(this._vHY, this._vHZ).normalize();
    }

    this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
    this._qGrip.setFromRotationMatrix(this._mBasis).premultiply(this._qSteer);
    const handOff = this.isCustomRider ? this.boneOffsets.get(hand) : undefined;
    if (handOff) this._qGrip.multiply(handOff.qOff);

    hand.parent.updateWorldMatrix(true, false);
    hand.parent.getWorldQuaternion(this._qParent);
    this._qDelta.copy(this._qParent).invert().multiply(this._qGrip);

    if (weight >= 0.999) {
      hand.quaternion.copy(this._qDelta);
    } else {
      hand.quaternion.slerp(this._qDelta, weight);
    }
    hand.updateWorldMatrix(false, false);
  }

  /**
   * Pronates/supinates the forearm bone smoothly toward the wrist's orientation around the
   * elbow-to-wrist axis, eliminating pinched wrist creases while preserving exact hand grip lock.
   */
  private twistForearmToHand(fore: THREE.Bone, hand: THREE.Bone, blend: number, maxTwist = 0.65): void {
    if (blend <= 0.001 || !fore.parent) return;
    fore.updateWorldMatrix(true, false);
    hand.updateWorldMatrix(false, false);

    fore.getWorldPosition(this._vA);
    hand.getWorldPosition(this._vB);
    this._ikDir.subVectors(this._vB, this._vA);
    if (this._ikDir.lengthSq() < 1e-6) return;
    this._ikDir.normalize();

    fore.getWorldQuaternion(this._qWorld);
    hand.getWorldQuaternion(this._qGrip);

    // Back-of-forearm (-Z) vs back-of-hand (-Z) projected orthogonal to forearm axis
    const foreOff = this.isCustomRider ? this.boneOffsets.get(fore) : undefined;
    const handOff = this.isCustomRider ? this.boneOffsets.get(hand) : undefined;
    this._vHX.set(0, 0, -1);
    if (foreOff) this._vHX.applyQuaternion(foreOff.qOffInv);
    this._vHX.applyQuaternion(this._qWorld);
    this._vHX.addScaledVector(this._ikDir, -this._vHX.dot(this._ikDir));

    this._vHY.set(0, 0, -1);
    if (handOff) this._vHY.applyQuaternion(handOff.qOffInv);
    this._vHY.applyQuaternion(this._qGrip);
    this._vHY.addScaledVector(this._ikDir, -this._vHY.dot(this._ikDir));

    if (this._vHX.lengthSq() < 1e-5 || this._vHY.lengthSq() < 1e-5) return;
    this._vHX.normalize();
    this._vHY.normalize();

    this._vHZ.crossVectors(this._vHX, this._vHY);
    const sinTheta = this._vHZ.dot(this._ikDir);
    const cosTheta = THREE.MathUtils.clamp(this._vHX.dot(this._vHY), -1, 1);
    const twistAngle = THREE.MathUtils.clamp(Math.atan2(sinTheta, cosTheta), -maxTwist, maxTwist) * blend;

    this._qDelta.setFromAxisAngle(this._ikDir, twistAngle);
    this._qWorld.premultiply(this._qDelta);
    fore.parent.getWorldQuaternion(this._qParent);
    fore.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
    fore.updateWorldMatrix(false, false);

    // Re-lock hand world orientation so grip alignment remains 100% exact
    fore.getWorldQuaternion(this._qParent);
    hand.quaternion.copy(this._qParent).invert().multiply(this._qGrip);
    hand.updateWorldMatrix(false, false);
  }

  private applyRiderSpaceEuler(bone: THREE.Bone, rx: number, ry: number, rz: number): void {
    if (!bone.parent) return;
    bone.updateWorldMatrix(true, false);
    this.riderRoot.getWorldQuaternion(this._qSteer);
    this._euler.set(rx, ry, rz, 'XYZ');
    this._qDelta.setFromEuler(this._euler);
    // deltaWorld = qRider * qLocalDelta * qRider^-1
    this._qInv.copy(this._qSteer).invert();
    this._qGrip.copy(this._qSteer).multiply(this._qDelta).multiply(this._qInv);
    bone.getWorldQuaternion(this._qWorld);
    this._qWorld.premultiply(this._qGrip);
    bone.parent.getWorldQuaternion(this._qParent);
    bone.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
    bone.updateWorldMatrix(false, false);
  }

  private applyLocalEuler(bone: THREE.Bone, rx: number, ry: number, rz: number): void {
    this._euler.set(rx, ry, rz, 'XYZ');
    this._qDelta.setFromEuler(this._euler);
    if (this.isCustomRider) {
      const off = this.boneOffsets.get(bone);
      if (off) {
        this._qDelta.premultiply(off.qOffInv).multiply(off.qOff);
      }
    }
    bone.quaternion.multiply(this._qDelta);
  }

  private solveArmIK(
    upper: THREE.Bone,
    mid: THREE.Bone,
    end: THREE.Bone,
    targetWorld: THREE.Vector3,
    poleWorld: THREE.Vector3,
    _side: 'left' | 'right'
  ): void {
    this.solveTwoBoneIK(upper, mid, end, targetWorld, poleWorld);
  }

  private solveTwoBoneIK(
    upper: THREE.Bone,
    mid: THREE.Bone,
    end: THREE.Bone,
    targetWorld: THREE.Vector3,
    poleWorld: THREE.Vector3,
    _lockEnd = false
  ): void {
    upper.updateWorldMatrix(true, false);
    mid.updateWorldMatrix(false, false);
    end.updateWorldMatrix(false, false);

    upper.getWorldPosition(this._vA);
    mid.getWorldPosition(this._vB);
    end.getWorldPosition(this._vC);

    const len1 = this._vA.distanceTo(this._vB);
    const len2 = this._vB.distanceTo(this._vC);
    if (len1 < 1e-4 || len2 < 1e-4) return;

    this._ikToTarget.subVectors(targetWorld, this._vA);
    const dist = THREE.MathUtils.clamp(
      this._ikToTarget.length(),
      Math.abs(len1 - len2) + 0.02,
      len1 + len2 - 0.005
    );
    this._ikDir.copy(this._ikToTarget).normalize();

    const cosAngleUpper = THREE.MathUtils.clamp(
      (len1 * len1 + dist * dist - len2 * len2) / (2 * len1 * dist),
      -1,
      1
    );
    const angleUpper = Math.acos(cosAngleUpper);

    this._ikToPole.subVectors(poleWorld, this._vA);
    this._ikToPole.addScaledVector(this._ikDir, -this._ikToPole.dot(this._ikDir));
    if (this._ikToPole.lengthSq() < 1e-6) this._ikToPole.set(0, 1, 0);
    this._ikToPole.normalize();

    this._ikDesiredMid
      .copy(this._vA)
      .addScaledVector(this._ikDir, Math.cos(angleUpper) * len1)
      .addScaledVector(this._ikToPole, Math.sin(angleUpper) * len1);

    this._ikCurDir.subVectors(this._vB, this._vA).normalize();
    this._ikWantDir.subVectors(this._ikDesiredMid, this._vA).normalize();
    this._qDelta.setFromUnitVectors(this._ikCurDir, this._ikWantDir);
    upper.getWorldQuaternion(this._qWorld);
    this._qWorld.premultiply(this._qDelta);
    upper.parent!.getWorldQuaternion(this._qParent);
    upper.quaternion.copy(this._qParent.invert().multiply(this._qWorld));
    upper.updateWorldMatrix(false, false);
    mid.updateWorldMatrix(false, false);
    end.updateWorldMatrix(false, false);

    mid.getWorldPosition(this._vB);
    end.getWorldPosition(this._vC);
    this._ikCurDir.subVectors(this._vC, this._vB).normalize();
    this._ikWantDir.subVectors(targetWorld, this._vB).normalize();
    this._qDelta.setFromUnitVectors(this._ikCurDir, this._ikWantDir);
    mid.getWorldQuaternion(this._qWorld);
    this._qWorld.premultiply(this._qDelta);
    mid.parent!.getWorldQuaternion(this._qParent);
    mid.quaternion.copy(this._qParent.invert().multiply(this._qWorld));
    mid.updateWorldMatrix(false, false);
    end.updateWorldMatrix(false, false);
  }

  /**
   * Positions the detachable helmet (on head, mid-air during put-on/takeoff, hooked on CG 160 lock,
   * or cradled under left arm on foot) and solves two-hand helmet animation IK cleanly.
   */
  public updateHelmet(
    dt: number,
    camera: THREE.Camera,
    isFirstPerson: boolean,
    isOnFoot: boolean,
    transitionT: number,
    hasActiveEmote: boolean,
    phoneBlend: number
  ): void {
    if (!this.helmetMesh || !this.headBone || !this.neckBone || !this.spine2Bone) return;

    const targetPhase = this.helmetOn ? 0 : 1;
    const animDuration = 1.08;
    if (Math.abs(this.helmetOffPhase - targetPhase) > 1e-4) {
      const step = dt / animDuration;
      if (this.helmetOffPhase < targetPhase) {
        this.helmetOffPhase = Math.min(1, this.helmetOffPhase + step);
      } else {
        this.helmetOffPhase = Math.max(0, this.helmetOffPhase - step);
      }
      this.helmetAnimating = Math.abs(this.helmetOffPhase - targetPhase) > 1e-4;
    } else {
      this.helmetOffPhase = targetPhase;
      this.helmetAnimating = false;
    }

    const p = this.helmetOffPhase;

    // Slight natural forward head bow during helmet lift/seat
    if (this.helmetAnimating && !isFirstPerson) {
      const nod = Math.sin(smoothstep(0.02, 0.56, p) * Math.PI) * 0.12;
      if (nod > 0.001) {
        this.applyLocalEuler(this.neckBone, nod * 0.55, 0, 0);
        this.applyLocalEuler(this.headBone, nod * 0.45, 0, 0);
      }
    }

    // Recompute exact unscaled Head_ world transform (immune to 1st-person 0.0001 neck/head scale)
    this.spine2Bone.updateWorldMatrix(true, false);
    this.neckBone.updateWorldMatrix(false, false);
    this.headBone.updateWorldMatrix(false, false);
    this.neckBone.getWorldPosition(this._hlmNeckPos);
    this.spine2Bone.getWorldQuaternion(this._hlmSpine2Quat);
    this._hlmTmpQ.copy(this._hlmSpine2Quat).multiply(this.neckBone.quaternion);
    this._hlmHeadQuat.copy(this._hlmTmpQ).multiply(this.headBone.quaternion);
    if (this.isCustomRider) {
      const headOff = this.boneOffsets.get(this.headBone);
      if (headOff) this._hlmHeadQuat.multiply(headOff.qOffInv);
    }
    this._hlmTmpV.copy(this.headBone.position).multiplyScalar(0.96).applyQuaternion(this._hlmTmpQ);
    this._hlmHeadPos.copy(this._hlmNeckPos).add(this._hlmTmpV);

    this._hlmFwd.setFromMatrixColumn(this.riderRoot.matrixWorld, 2).normalize();
    this._hlmRight.setFromMatrixColumn(this.riderRoot.matrixWorld, 0).multiplyScalar(-1).normalize();

    const hideHairForHelmet = Boolean(this.helmetMesh) && p < 0.26;
    for (const hm of this.helmetHiddenHairMeshes) {
      hm.visible = !isFirstPerson && !hideHairForHelmet;
    }

    if (this.hairChains.length > 0) {
      if (!isFirstPerson && !hideHairForHelmet) {
        this.updateHairPhysics(dt);
      } else {
        this.hasHairPrevPos = false;
      }
    }

    if (p <= 1e-4) {
      this._hlmPos.copy(this._hlmHeadPos);
      this._hlmQuat.copy(this._hlmHeadQuat);
      this.helmetPivot.position.copy(this._hlmPos);
      this.helmetPivot.quaternion.copy(this._hlmQuat);
      this.helmetPivot.updateMatrixWorld(true);
      this.syncHelmetVisibility(isFirstPerson);
      return;
    }

    // 1. Mid-air lift/inspection pose in front of rider (visible cleanly in both 1st and 3rd person)
    camera.updateMatrixWorld(true);
    this._camPos.setFromMatrixPosition(camera.matrixWorld);
    this._camRight.setFromMatrixColumn(camera.matrixWorld, 0).normalize();
    this._camUp.setFromMatrixColumn(camera.matrixWorld, 1).normalize();
    this._camFwd.setFromMatrixColumn(camera.matrixWorld, 2).multiplyScalar(-1).normalize();

    if (isFirstPerson) {
      this._hlmLiftPos
        .copy(this._camPos)
        .addScaledVector(this._camFwd, 0.345)
        .addScaledVector(this._camUp, -0.012)
        .addScaledVector(this._camRight, -0.025);
    } else {
      this._hlmLiftPos
        .copy(this._hlmHeadPos)
        .addScaledVector(this._upVec, 0.21)
        .addScaledVector(this._hlmFwd, 0.28)
        .addScaledVector(this._hlmRight, -0.04);
    }

    this._vHX.copy(this._hlmRight).negate(); // +X helmet = rider's left
    this._mBasis.makeBasis(this._vHX, this._upVec, this._hlmFwd);
    this._hlmLiftQuat.setFromRotationMatrix(this._mBasis);
    this._euler.set(0.28, -0.38, 0.14, 'YXZ');
    this._qDelta.setFromEuler(this._euler);
    this._hlmLiftQuat.multiply(this._qDelta);

    // 2. Stowed pose: bike rear-left helmet lock when mounted, cradled under left arm/hip when on foot
    this._hlmBikeStowPos.set(-0.46, 0.78, -0.245);
    this.chassisPivot.localToWorld(this._hlmBikeStowPos);
    this.chassisPivot.getWorldQuaternion(this._hlmBikeStowQuat);
    this._euler.set(-0.22, -Math.PI * 0.42, 0.34, 'YXZ');
    this._qDelta.setFromEuler(this._euler);
    this._hlmBikeStowQuat.multiply(this._qDelta);

    if (this.hipsBone) {
      this.hipsBone.getWorldPosition(this._hlmFootStowPos);
    } else {
      this._hlmFootStowPos.setFromMatrixPosition(this.riderRoot.matrixWorld).addScaledVector(this._upVec, 0.94);
    }
    if (hasActiveEmote) {
      // Clip neatly against left waist/belt if waving or using two-hand emotes on foot
      this._hlmFootStowPos
        .addScaledVector(this._hlmRight, -0.22)
        .addScaledVector(this._upVec, 0.01)
        .addScaledVector(this._hlmFwd, -0.07);
    } else {
      this._hlmFootStowPos
        .addScaledVector(this._hlmRight, -0.265)
        .addScaledVector(this._upVec, 0.045)
        .addScaledVector(this._hlmFwd, 0.085);
    }
    this._mBasis.makeBasis(this._vHX, this._upVec, this._hlmFwd);
    this._hlmFootStowQuat.setFromRotationMatrix(this._mBasis);
    this._euler.set(0.18, 0.52, -0.44, 'YXZ');
    this._qDelta.setFromEuler(this._euler);
    this._hlmFootStowQuat.multiply(this._qDelta);

    const footFactor = isOnFoot ? 1 : smoothstep(0.18, 0.86, transitionT);
    this._hlmStowPos.lerpVectors(this._hlmBikeStowPos, this._hlmFootStowPos, footFactor);
    this._hlmStowQuat.slerpQuaternions(this._hlmBikeStowQuat, this._hlmFootStowQuat, footFactor);

    // 3. Smooth trajectory along p = [0..1]
    const pLift = smoothstep(0.14, 0.52, p);
    const pStow = smoothstep(0.50, 1.00, p);
    const skullClearY =
      Math.sin(smoothstep(0.08, 0.52, p) * Math.PI) * 0.21 +
      smoothstep(0.04, 0.20, p) * (1 - pLift) * 0.032;

    this._hlmPos.lerpVectors(this._hlmHeadPos, this._hlmLiftPos, pLift);
    this._hlmPos.lerp(this._hlmStowPos, pStow);
    this._hlmPos.y += skullClearY * (1 - pStow);

    this._hlmQuat.slerpQuaternions(this._hlmHeadQuat, this._hlmLiftQuat, pLift);
    this._hlmQuat.slerp(this._hlmStowQuat, pStow);

    this.helmetPivot.position.copy(this._hlmPos);
    this.helmetPivot.quaternion.copy(this._hlmQuat);
    this.helmetPivot.updateMatrixWorld(true);
    this.syncHelmetVisibility(isFirstPerson);

    // Skip hand/arm IK if phone is currently raised in same hand or during helmet transition
    if (phoneBlend > 0.05 && (!isOnFoot || this.helmetAnimating)) return;

    // Extract helmet world axes for hand grip placement (+X helmet = left, +Y = top, +Z = visor)
    this._hlmHRight.set(-1, 0, 0).applyQuaternion(this._hlmQuat).normalize();
    this._hlmHUp.set(0, 1, 0).applyQuaternion(this._hlmQuat).normalize();
    this._hlmHFwd.set(0, 0, 1).applyQuaternion(this._hlmQuat).normalize();

    const reachIn = smoothstep(0.0, 0.20, p);
    const rightWeight = this.helmetAnimating ? reachIn * (1 - smoothstep(0.56, 0.88, p)) : 0;
    const leftWeight = this.helmetAnimating
      ? reachIn * (footFactor > 0.5 || !hasActiveEmote ? (footFactor > 0.5 ? 1 : 1 - smoothstep(0.80, 1.0, p)) : 1 - smoothstep(0.80, 1.0, p))
      : !this.helmetOn && isOnFoot && !hasActiveEmote
        ? 1.0
        : 0;

    // Right hand assists unbuckling / lifting / lowering on the helmet's right rim
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');
    const rHand = this.findBone('RightHand_');
    if (rightWeight > 0.005 && rArm && rFore && rHand && rHand.parent) {
      rHand.getWorldPosition(this._emPosR);
      rHand.getWorldQuaternion(this._qStartR);
      rArm.getWorldPosition(this._vA);

      this._hlmGripR
        .copy(this._hlmPos)
        .addScaledVector(this._hlmHRight, 0.122)
        .addScaledVector(this._hlmHUp, -0.022)
        .addScaledVector(this._hlmHFwd, 0.042);

      this._vTarget.lerpVectors(this._emPosR, this._hlmGripR, rightWeight);
      this._emPoleR
        .copy(this._vA)
        .addScaledVector(this._hlmRight, 0.24)
        .addScaledVector(this._upVec, -0.22)
        .addScaledVector(this._hlmFwd, 0.05);

      this.solveArmIK(rArm, rFore, rHand, this._vTarget, this._emPoleR, 'right');

      // +Y_hand = fingers wrap up/forward, +Z_hand = palm presses inward against right cheek pad
      this._vHY.copy(this._hlmHUp).multiplyScalar(0.76).addScaledVector(this._hlmHFwd, 0.65).normalize();
      this._vHZ.copy(this._hlmHRight).multiplyScalar(-0.94).addScaledVector(this._hlmHUp, 0.28).normalize();
      this._vHX.crossVectors(this._vHY, this._vHZ).normalize();
      this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
      this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
      this._qGrip.setFromRotationMatrix(this._mBasis);
      const rHOff = this.isCustomRider ? this.boneOffsets.get(rHand) : undefined;
      if (rHOff) this._qGrip.multiply(rHOff.qOff);

      this._qWorld.copy(this._qStartR).slerp(this._qGrip, rightWeight);
      rHand.parent.getWorldQuaternion(this._qParent);
      rHand.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
      rHand.updateWorldMatrix(false, false);
      this.twistForearmToHand(rFore, rHand, rightWeight * 0.85, 1.15);

      const curlR = THREE.MathUtils.lerp(isOnFoot ? 0.22 : 1.05, 0.72, rightWeight);
      this.poseUniformFingers('right', curlR);
    }

    // Left hand grabs left rim, guides helmet cleanly, and cradles under left forearm when on foot
    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const lHand = this.findBone('LeftHand_');
    if (leftWeight > 0.005 && lArm && lFore && lHand && lHand.parent) {
      lHand.getWorldPosition(this._emPosL);
      lHand.getWorldQuaternion(this._qStartL);
      lArm.getWorldPosition(this._vA);

      const cradleBlend = smoothstep(0.64, 1.0, p) * footFactor;

      this._hlmGripL
        .copy(this._hlmPos)
        .addScaledVector(this._hlmHRight, -0.122)
        .addScaledVector(this._hlmHUp, -0.022)
        .addScaledVector(this._hlmHFwd, 0.042);

      this._hlmCradleL
        .copy(this._hlmPos)
        .addScaledVector(this._hlmHRight, -0.055)
        .addScaledVector(this._hlmHUp, -0.088)
        .addScaledVector(this._hlmHFwd, 0.082);

      this._hlmGripL.lerp(this._hlmCradleL, cradleBlend);
      this._vTarget.lerpVectors(this._emPosL, this._hlmGripL, leftWeight);

      this._emPoleL
        .copy(this._vA)
        .addScaledVector(this._hlmRight, -0.24)
        .addScaledVector(this._upVec, -0.22)
        .addScaledVector(this._hlmFwd, -0.05 * cradleBlend + 0.05 * (1 - cradleBlend));

      this.solveArmIK(lArm, lFore, lHand, this._vTarget, this._emPoleL, 'left');

      // Blend from side-rim grip orientation into under-chin cradle carry orientation
      this._vHY
        .copy(this._hlmHUp)
        .multiplyScalar(THREE.MathUtils.lerp(0.76, 0.42, cradleBlend))
        .addScaledVector(this._hlmHFwd, THREE.MathUtils.lerp(0.65, 0.56, cradleBlend))
        .addScaledVector(this._hlmHRight, 0.72 * cradleBlend)
        .normalize();
      this._vHZ
        .copy(this._hlmHRight)
        .multiplyScalar(THREE.MathUtils.lerp(0.94, 0.58, cradleBlend))
        .addScaledVector(this._hlmHUp, THREE.MathUtils.lerp(0.28, 0.80, cradleBlend))
        .normalize();
      this._vHX.crossVectors(this._vHY, this._vHZ).normalize();
      this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
      this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
      this._qGrip.setFromRotationMatrix(this._mBasis);
      const lHOff = this.isCustomRider ? this.boneOffsets.get(lHand) : undefined;
      if (lHOff) this._qGrip.multiply(lHOff.qOff);

      this._qWorld.copy(this._qStartL).slerp(this._qGrip, leftWeight);
      lHand.parent.getWorldQuaternion(this._qParent);
      lHand.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
      lHand.updateWorldMatrix(false, false);
      this.twistForearmToHand(lFore, lHand, leftWeight * 0.85, 1.15);

      const curlL = THREE.MathUtils.lerp(isOnFoot ? 0.22 : 0.92, 0.62, leftWeight);
      this.poseUniformFingers('left', curlL);
    }
  }

  /**
   * Animates the 3D water bottle lifecycle:
   * stowed on bike corner -> grab -> unscrew cap (rotate) -> remove cap -> pour/drink (liquid drops) -> recap -> stow back on bike corner.
   */
  public applyWaterBottlePose(
    bottle: WaterBottleDevice,
    camera: THREE.Camera,
    isFirstPerson: boolean,
    isOnFoot: boolean,
    phase: DrinkPhase,
    phaseProgress: number,
    waterLevel: number,
    physics: BikePhysics,
    time: number
  ): void {
    this.bottleStowAnchor.updateWorldMatrix(true, false);
    this.bottleStowAnchor.getWorldPosition(this._wbAnchorPos);
    this.bottleStowAnchor.getWorldQuaternion(this._wbAnchorQuat);

    const bikeSpeed = Math.hypot(physics.vel.x, physics.vel.z);
    const idleSlosh =
      0.0008 + Math.min(0.0045, bikeSpeed * 0.00025 + Math.abs(physics.leanAngle) * 0.003);

    if (phase === 'idle') {
      bottle.root.position.copy(this._wbAnchorPos);
      bottle.root.quaternion.copy(this._wbAnchorQuat);
      bottle.capPivot.position.set(0, bottle.capRestY, 0);
      bottle.capPivot.rotation.set(0, 0, 0);
      bottle.updateLiquid(time, waterLevel, idleSlosh, 0, true);
      return;
    }

    const p = THREE.MathUtils.clamp(phaseProgress, 0, 1);

    camera.updateMatrixWorld(true);
    this._camPos.setFromMatrixPosition(camera.matrixWorld);
    this._camRight.setFromMatrixColumn(camera.matrixWorld, 0).normalize();
    this._camUp.setFromMatrixColumn(camera.matrixWorld, 1).normalize();
    this._camFwd.setFromMatrixColumn(camera.matrixWorld, 2).multiplyScalar(-1).normalize();
    this._camBack.copy(this._camFwd).negate();

    this.riderRoot.updateMatrixWorld(true);
    this._phRiderFwd.setFromMatrixColumn(this.riderRoot.matrixWorld, 2).normalize();
    this._phRiderRight
      .setFromMatrixColumn(this.riderRoot.matrixWorld, 0)
      .multiplyScalar(-1)
      .normalize();

    const chestBone = this.findBone('Spine2_');
    const neckBone = this.findBone('Neck_');
    const headBone = this.findBone('Head_');

    // 1. Compute upright chest/inspection pose, tilted drinking pose, and steady left-hand cap hold pose
    if (isFirstPerson) {
      // Bottle centered slightly below eye line at comfortable 29cm arm reach
      this._wbChestPos
        .copy(this._camPos)
        .addScaledVector(this._camFwd, 0.285)
        .addScaledVector(this._camRight, 0.012)
        .addScaledVector(this._camUp, -0.135);

      this._wbUp.copy(this._camUp).addScaledVector(this._camBack, 0.10).normalize();
      this._wbFwd.copy(this._camBack).normalize();
      this._wbRight.crossVectors(this._wbUp, this._wbFwd).normalize();
      this._wbFwd.crossVectors(this._wbRight, this._wbUp).normalize();
      this._mBasis.makeBasis(this._wbRight, this._wbUp, this._wbFwd);
      this._wbChestQuat.setFromRotationMatrix(this._mBasis);

      // Spout aims toward mouth while base sits ~33cm ahead so whole bottle & hand stay clearly framed (no near-plane clipping)
      this._wbMouthPos
        .copy(this._camPos)
        .addScaledVector(this._camFwd, 0.165)
        .addScaledVector(this._camUp, -0.068)
        .addScaledVector(this._camRight, 0.012);

      this._wbUp
        .copy(this._camBack)
        .multiplyScalar(0.78)
        .addScaledVector(this._camUp, -0.56)
        .addScaledVector(this._camRight, -0.22)
        .normalize();
      this._wbDrinkPos
        .copy(this._wbMouthPos)
        .addScaledVector(this._wbUp, -bottle.bottleHeight);

      this._wbRight
        .copy(this._camRight)
        .addScaledVector(this._camFwd, 0.20)
        .normalize();
      this._wbFwd.crossVectors(this._wbRight, this._wbUp).normalize();
      this._wbRight.crossVectors(this._wbUp, this._wbFwd).normalize();
      this._mBasis.makeBasis(this._wbRight, this._wbUp, this._wbFwd);
      this._wbDrinkQuat.setFromRotationMatrix(this._mBasis);

      // Left hand holds the removed cap relaxed to the left side of view
      this._wbCapHoldPos
        .copy(this._camPos)
        .addScaledVector(this._camFwd, 0.265)
        .addScaledVector(this._camRight, -0.135)
        .addScaledVector(this._camUp, -0.105);
      this._wbCapHoldQuat.copy(this._wbChestQuat);
    } else {
      if (chestBone) {
        chestBone.getWorldPosition(this._wbChestPos);
      } else {
        this._wbChestPos
          .setFromMatrixPosition(this.riderRoot.matrixWorld)
          .addScaledVector(this._upVec, 1.24);
      }
      this._wbChestPos
        .addScaledVector(this._phRiderFwd, 0.285)
        .addScaledVector(this._upVec, 0.055)
        .addScaledVector(this._phRiderRight, 0.020);

      this._wbUp.copy(this._upVec).addScaledVector(this._phRiderFwd, 0.08).normalize();
      this._wbFwd.copy(this._phRiderFwd).negate().normalize();
      this._wbRight.crossVectors(this._wbUp, this._wbFwd).normalize();
      this._wbFwd.crossVectors(this._wbRight, this._wbUp).normalize();
      this._mBasis.makeBasis(this._wbRight, this._wbUp, this._wbFwd);
      this._wbChestQuat.setFromRotationMatrix(this._mBasis);

      if (headBone) {
        headBone.getWorldPosition(this._wbMouthPos);
      } else {
        this._wbMouthPos.copy(this._wbChestPos).addScaledVector(this._upVec, 0.36);
      }
      this._wbMouthPos
        .addScaledVector(this._upVec, 0.065)
        .addScaledVector(this._phRiderFwd, 0.115);

      // Spout stops cleanly right at the lips (0.231m base-to-mouth > 0.215m bottle height)
      this._wbDrinkPos
        .copy(this._wbMouthPos)
        .addScaledVector(this._phRiderFwd, 0.210)
        .addScaledVector(this._upVec, 0.095)
        .addScaledVector(this._phRiderRight, 0.020);

      this._wbUp.subVectors(this._wbMouthPos, this._wbDrinkPos).normalize();
      this._wbRight.copy(this._phRiderRight);
      this._wbFwd.crossVectors(this._wbRight, this._wbUp).normalize();
      this._wbRight.crossVectors(this._wbUp, this._wbFwd).normalize();
      this._mBasis.makeBasis(this._wbRight, this._wbUp, this._wbFwd);
      this._wbDrinkQuat.setFromRotationMatrix(this._mBasis);

      this._wbCapHoldPos
        .copy(this._wbChestPos)
        .addScaledVector(this._phRiderRight, -0.155)
        .addScaledVector(this._upVec, -0.025)
        .addScaledVector(this._phRiderFwd, 0.015);
      this._wbCapHoldQuat.copy(this._wbChestQuat);
    }

    // 2. Evaluate bottle transform, cap state, torso lean assist, and hand blend weights per phase
    let rightWeight = 0;
    let leftWeight = 0;
    let twistAngle = 0;
    let pourIntensity = 0;
    let sloshIntensity = 0.0025;
    let drinkTilt = 0;
    let torsoLeanToHolder = 0;
    let capHoldBlend = 0; // 0 = cap seated/unscrewing on bottle, 1 = held independently by left hand

    if (phase === 'grabbing') {
      const reach = smoothstep(0.0, 0.42, p);
      const lift = smoothstep(0.42, 1.0, p);
      rightWeight = reach;
      leftWeight = smoothstep(0.62, 1.0, p);
      torsoLeanToHolder = reach * (1 - lift);

      this._wbTmpPos.lerpVectors(this._wbAnchorPos, this._wbChestPos, lift);
      this._wbTmpPos.y += Math.sin(lift * Math.PI) * 0.055;
      this._wbTmpPos.addScaledVector(this._phRiderRight, Math.sin(lift * Math.PI) * 0.040);
      this._wbTmpQuat.slerpQuaternions(this._wbAnchorQuat, this._wbChestQuat, lift);
      bottle.capPivot.position.set(0, bottle.capRestY, 0);
      bottle.capPivot.rotation.set(0, 0, 0);
      sloshIntensity = 0.003 + Math.sin(lift * Math.PI) * 0.004;
    } else if (phase === 'unscrewing') {
      rightWeight = 1.0;
      leftWeight = 1.0;
      this._wbTmpPos.copy(this._wbChestPos);
      this._wbTmpQuat.copy(this._wbChestQuat);
      // Character rotates/twists cap 3 turns while threads unscrew upward
      const turnAngle = p * Math.PI * 6;
      bottle.capPivot.rotation.set(0, turnAngle, 0);
      bottle.capPivot.position.set(0, bottle.capRestY + p * 0.014, 0);
      twistAngle = Math.sin(turnAngle) * 0.36;
      sloshIntensity = 0.0024;
    } else if (phase === 'removing_cap') {
      rightWeight = 1.0;
      leftWeight = 1.0;
      this._wbTmpPos.copy(this._wbChestPos);
      this._wbTmpQuat.copy(this._wbChestQuat);
      capHoldBlend = smoothstep(0.0, 1.0, p);
      sloshIntensity = 0.0022;
    } else if (phase === 'drinking') {
      rightWeight = 1.0;
      leftWeight = 1.0;
      capHoldBlend = 1.0;
      const tiltIn = smoothstep(0.0, 0.24, p);
      const tiltOut = 1 - smoothstep(0.84, 1.0, p);
      drinkTilt = tiltIn * tiltOut;

      this._wbTmpPos.lerpVectors(this._wbChestPos, this._wbDrinkPos, drinkTilt);
      this._wbTmpQuat.slerpQuaternions(this._wbChestQuat, this._wbDrinkQuat, drinkTilt);

      pourIntensity = smoothstep(0.16, 0.30, p) * (1 - smoothstep(0.80, 0.92, p));
      sloshIntensity = 0.0045 + pourIntensity * 0.0045;

      // Tilt rider head slightly back while drinking in 3rd-person
      if (!isFirstPerson && drinkTilt > 0.01) {
        if (neckBone) this.applyLocalEuler(neckBone, -0.14 * drinkTilt, 0, 0);
        if (headBone) this.applyLocalEuler(headBone, -0.16 * drinkTilt, 0, 0);
        this.riderRoot.updateMatrixWorld(true);
      }
    } else if (phase === 'recapping') {
      rightWeight = 1.0;
      leftWeight = 1.0;
      this._wbTmpPos.copy(this._wbChestPos);
      this._wbTmpQuat.copy(this._wbChestQuat);
      const placeDown = smoothstep(0.0, 0.52, p);
      const screwShut = smoothstep(0.52, 1.0, p);
      capHoldBlend = 1.0 - placeDown;
      if (placeDown >= 0.99) {
        bottle.capPivot.position.set(0, bottle.capRestY + 0.014 * (1 - screwShut), 0);
        bottle.capPivot.rotation.set(0, (1 - screwShut) * Math.PI * 3, 0);
      }
      twistAngle = screwShut > 0.01 ? -Math.sin(screwShut * Math.PI * 3) * 0.34 : 0;
      sloshIntensity = 0.0022;
    } else if (phase === 'stowing') {
      const lower = smoothstep(0.0, 0.64, p);
      const release = smoothstep(0.64, 1.0, p);
      rightWeight = 1.0 - release;
      leftWeight = 1.0 - smoothstep(0.0, 0.34, p);
      torsoLeanToHolder = lower * (1 - release);

      this._wbTmpPos.lerpVectors(this._wbChestPos, this._wbAnchorPos, lower);
      this._wbTmpPos.y += Math.sin(lower * Math.PI) * 0.055;
      this._wbTmpPos.addScaledVector(this._phRiderRight, Math.sin(lower * Math.PI) * 0.040);
      this._wbTmpQuat.slerpQuaternions(this._wbChestQuat, this._wbAnchorQuat, lower);
      bottle.capPivot.position.set(0, bottle.capRestY, 0);
      bottle.capPivot.rotation.set(0, 0, 0);
      sloshIntensity = 0.0035 * (1 - release);
    }

    // Gentle torso lean toward tank corner when reaching for or placing the bottle
    if (!isFirstPerson && !isOnFoot && chestBone && torsoLeanToHolder > 0.005) {
      this.applyLocalEuler(
        chestBone,
        0.12 * torsoLeanToHolder,
        -0.08 * torsoLeanToHolder,
        -0.07 * torsoLeanToHolder
      );
      this.riderRoot.updateMatrixWorld(true);
    }

    // Update bottle transform first
    bottle.root.position.copy(this._wbTmpPos);
    bottle.root.quaternion.copy(this._wbTmpQuat);
    bottle.root.updateMatrixWorld(true);

    // Position removed cap cleanly in steady chest/camera-left space when detached
    if (capHoldBlend > 0.001) {
      this._wbCapLocalTmp.set(0, bottle.capRestY + 0.014, 0);
      bottle.root.localToWorld(this._wbCapLocalTmp);
      this._wbCapWorldPos.lerpVectors(this._wbCapLocalTmp, this._wbCapHoldPos, capHoldBlend);
      bottle.root.worldToLocal(this._wbCapLocalTmp.copy(this._wbCapWorldPos));
      bottle.capPivot.position.copy(this._wbCapLocalTmp);
      this._qDelta.copy(this._wbTmpQuat).invert().multiply(this._wbCapHoldQuat);
      bottle.capPivot.quaternion.copy(this._qDelta);
      bottle.capPivot.updateMatrixWorld(true);
    } else {
      bottle.capPivot.getWorldPosition(this._wbCapWorldPos);
    }

    bottle.updateLiquid(time, waterLevel, sloshIntensity, pourIntensity, false);

    // Extract live bottle local axes (R x U = +F where F points toward viewer/rider)
    this._wbRight.set(1, 0, 0).applyQuaternion(this._wbTmpQuat).normalize();
    this._wbUp.set(0, 1, 0).applyQuaternion(this._wbTmpQuat).normalize();
    this._wbFwd.set(0, 0, 1).applyQuaternion(this._wbTmpQuat).normalize();

    // 3. Solve Right Hand IK (palm inward against right wall, thumb up along bottle, fingers wrap around)
    const rShoulder = this.findBone('RightShoulder_');
    const rArm = this.findBone('RightArm_');
    const rFore = this.findBone('RightForeArm_');
    const rHand = this.findBone('RightHand_');
    if (rightWeight > 0.005 && rArm && rFore && rHand && rHand.parent) {
      if (rShoulder) {
        this.applyRiderSpaceEuler(rShoulder, 0, (0.14 + 0.14 * torsoLeanToHolder) * rightWeight, 0);
      }
      rHand.getWorldPosition(this._emPosR);
      rHand.getWorldQuaternion(this._qStartR);
      rArm.getWorldPosition(this._vA);

      // Right hand basis:
      // +X (thumb) = +bottleUp
      // +Z (palm)  = inward toward bottle from right-front (-0.92 * R + 0.39 * F)
      // +Y (fingers) = Z x X (wraps smoothly around far side of bottle; wrist sits on near-right -Y!)
      this._vHX.copy(this._wbUp);
      this._vHZ
        .copy(this._wbRight)
        .multiplyScalar(-0.92)
        .addScaledVector(this._wbFwd, 0.39)
        .normalize();
      this._vHY.crossVectors(this._vHZ, this._vHX).normalize();
      this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
      this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
      this._qGrip.setFromRotationMatrix(this._mBasis);
      const rWOff = this.isCustomRider ? this.boneOffsets.get(rHand) : undefined;
      if (rWOff) this._qGrip.multiply(rWOff.qOff);

      // Place wrist offset back from palm center (-0.052 * Y_hand) and outside barrel (-0.044 * Z_hand)
      this._wbGripPos
        .copy(this._wbTmpPos)
        .addScaledVector(this._wbUp, bottle.gripCenterY)
        .addScaledVector(this._vHZ, -0.044)
        .addScaledVector(this._vHY, -0.052);

      // Clamp wrist reach softly to arm length so forearm never pops
      this._ikToTarget.subVectors(this._wbGripPos, this._vA);
      const reachR = this._ikToTarget.length();
      const maxReachR = 0.478;
      if (reachR > maxReachR && reachR > 1e-4) {
        this._wbGripPos.copy(this._vA).addScaledVector(this._ikToTarget, maxReachR / reachR);
      }

      this._vTarget.lerpVectors(this._emPosR, this._wbGripPos, rightWeight);
      if (rightWeight < 0.995) {
        const arcR = Math.sin(rightWeight * Math.PI);
        this._vTarget.y += arcR * 0.040;
        this._vTarget.addScaledVector(this._phRiderRight, arcR * 0.045);
      }

      this._emPoleR
        .copy(this._vA)
        .addScaledVector(this._upVec, -0.26)
        .addScaledVector(isFirstPerson ? this._camRight : this._phRiderRight, 0.25)
        .addScaledVector(isFirstPerson ? this._camFwd : this._phRiderFwd, 0.05);

      this.solveArmIK(rArm, rFore, rHand, this._vTarget, this._emPoleR, 'right');

      this._qWorld.copy(this._qStartR).slerp(this._qGrip, rightWeight);
      rHand.parent.getWorldQuaternion(this._qParent);
      rHand.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
      rHand.updateWorldMatrix(false, false);
      this.twistForearmToHand(rFore, rHand, rightWeight * 0.85, 1.25);

      const baseRightCurl = isOnFoot ? 0.22 : 0.80;
      const barrelCurl = THREE.MathUtils.lerp(baseRightCurl, 0.58, rightWeight);
      this.poseHandFingers('right', {
        thumb: { curl: THREE.MathUtils.lerp(0.32, 0.42, rightWeight), spread: -0.18 },
        index: { curl: barrelCurl },
        middle: { curl: barrelCurl },
        ring: { curl: barrelCurl },
        pinky: { curl: barrelCurl },
      });
    }

    // 4. Solve Left Hand IK (palm inward against left side of cap, thumb up, fingers pinch/twist cap)
    const lShoulder = this.findBone('LeftShoulder_');
    const lArm = this.findBone('LeftArm_');
    const lFore = this.findBone('LeftForeArm_');
    const lHand = this.findBone('LeftHand_');
    if (leftWeight > 0.005 && lArm && lFore && lHand && lHand.parent) {
      if (lShoulder) {
        this.applyRiderSpaceEuler(lShoulder, 0, -0.14 * leftWeight, 0);
      }
      lHand.getWorldPosition(this._emPosL);
      lHand.getWorldQuaternion(this._qStartL);
      lArm.getWorldPosition(this._vA);

      // Left hand basis (in bike_rider.glb, -X is thumb side, so +X = pinky = -capUp):
      // +Z (palm)    = inward toward cap from left-front (+0.92 * R + 0.39 * F), twisted around capUp
      // +X (pinky)   = -capUp (so thumb points UP along cap!)
      // +Y (fingers) = Z x X (wraps around far side of cap; wrist sits on near-left -Y!)
      const capUp = capHoldBlend > 0.5 ? this._upVec : this._wbUp;
      const capRight = capHoldBlend > 0.5 ? (isFirstPerson ? this._camRight : this._phRiderRight) : this._wbRight;
      if (capHoldBlend > 0.5) {
        if (isFirstPerson) {
          this._vB.copy(this._camBack);
        } else {
          this._vB.copy(this._phRiderFwd).negate();
        }
      } else {
        this._vB.copy(this._wbFwd);
      }

      this._vHX.copy(capUp).negate();
      this._vHZ
        .copy(capRight)
        .multiplyScalar(0.92)
        .addScaledVector(this._vB, 0.39)
        .normalize();
      if (Math.abs(twistAngle) > 0.001) {
        this._qDelta.setFromAxisAngle(capUp, twistAngle);
        this._vHZ.applyQuaternion(this._qDelta).normalize();
      }
      this._vHY.crossVectors(this._vHZ, this._vHX).normalize();
      this._vHZ.crossVectors(this._vHX, this._vHY).normalize();
      this._mBasis.makeBasis(this._vHX, this._vHY, this._vHZ);
      this._qGrip.setFromRotationMatrix(this._mBasis);
      const lWOff = this.isCustomRider ? this.boneOffsets.get(lHand) : undefined;
      if (lWOff) this._qGrip.multiply(lWOff.qOff);

      // Place wrist back from cap center (-0.056 * Y_hand) and outside cap surface (-0.032 * Z_hand)
      this._wbCapLocalTmp
        .copy(this._wbCapWorldPos)
        .addScaledVector(this._vHZ, -0.032)
        .addScaledVector(this._vHY, -0.056);

      this._ikToTarget.subVectors(this._wbCapLocalTmp, this._vA);
      const reachL = this._ikToTarget.length();
      const maxReachL = 0.478;
      if (reachL > maxReachL && reachL > 1e-4) {
        this._wbCapLocalTmp.copy(this._vA).addScaledVector(this._ikToTarget, maxReachL / reachL);
      }

      this._vTarget.lerpVectors(this._emPosL, this._wbCapLocalTmp, leftWeight);
      if (leftWeight < 0.995) {
        const arcL = Math.sin(leftWeight * Math.PI);
        this._vTarget.y += arcL * 0.040;
        this._vTarget.addScaledVector(this._phRiderRight, -arcL * 0.045);
      }

      this._emPoleL
        .copy(this._vA)
        .addScaledVector(this._upVec, -0.25)
        .addScaledVector(isFirstPerson ? this._camRight : this._phRiderRight, -0.25)
        .addScaledVector(isFirstPerson ? this._camFwd : this._phRiderFwd, 0.06);

      this.solveArmIK(lArm, lFore, lHand, this._vTarget, this._emPoleL, 'left');

      this._qWorld.copy(this._qStartL).slerp(this._qGrip, leftWeight);
      lHand.parent.getWorldQuaternion(this._qParent);
      lHand.quaternion.copy(this._qParent).invert().multiply(this._qWorld);
      lHand.updateWorldMatrix(false, false);
      this.twistForearmToHand(lFore, lHand, leftWeight * 0.85, 1.25);

      const baseLeftCurl = isOnFoot ? 0.22 : 0.95;
      const pinchCurl = THREE.MathUtils.lerp(baseLeftCurl, 0.74, leftWeight);
      this.poseHandFingers('left', {
        thumb: { curl: THREE.MathUtils.lerp(0.28, 0.54, leftWeight), spread: -0.20 },
        index: { curl: pinchCurl, spread: 0.04 },
        middle: { curl: pinchCurl + 0.06 * leftWeight, spread: 0.0 },
        ring: { curl: THREE.MathUtils.lerp(baseLeftCurl, 0.94, leftWeight) },
        pinky: { curl: THREE.MathUtils.lerp(baseLeftCurl, 0.98, leftWeight) },
      });
    }
  }

  private updateHairPhysics(dt: number): void {
    if (this.hairChains.length === 0) return;

    if (!this.hasHairPrevPos || dt <= 1e-5 || dt > 0.25) {
      this._hairPrevHeadPos.copy(this._hlmHeadPos);
      this._hairPrevHeadVel.set(0, 0, 0);
      this.hasHairPrevPos = true;
      return;
    }

    const invDt = 1 / dt;
    this._hairHeadVel.subVectors(this._hlmHeadPos, this._hairPrevHeadPos).multiplyScalar(invDt);
    // Clamp instantaneous teleport/camera snap velocities
    if (this._hairHeadVel.lengthSq() > 2500) {
      this._hairHeadVel.setLength(50);
    }
    this._hairHeadAccel.subVectors(this._hairHeadVel, this._hairPrevHeadVel).multiplyScalar(invDt);
    this._hairHeadAccel.x = THREE.MathUtils.clamp(this._hairHeadAccel.x, -28, 28);
    this._hairHeadAccel.y = THREE.MathUtils.clamp(this._hairHeadAccel.y, -28, 28);
    this._hairHeadAccel.z = THREE.MathUtils.clamp(this._hairHeadAccel.z, -28, 28);

    this._hairPrevHeadPos.copy(this._hlmHeadPos);
    this._hairPrevHeadVel.lerp(this._hairHeadVel, Math.min(1, dt * 18));

    const fwdSigned = this._hairHeadVel.dot(this._hlmFwd);
    const fwdSpeed = Math.max(0, fwdSigned);
    const revSpeed = Math.min(0, fwdSigned);
    const latVel = this._hairHeadVel.dot(this._hlmRight);
    const latAccel = this._hairHeadAccel.dot(this._hlmRight);

    // Wheelie / head pitch gravity component: chin up (+Y on head forward) drapes braids back
    this._hairHeadFwd.set(0, 0, 1).applyQuaternion(this._hlmHeadQuat);
    const headPitchGrav = THREE.MathUtils.clamp(this._hairHeadFwd.y, -0.8, 0.85) * 0.44;

    const windDrag = THREE.MathUtils.clamp(0.0038 * fwdSpeed * fwdSpeed, 0, 0.78);
    const windRatio = THREE.MathUtils.clamp(fwdSpeed / 10, 0, 1);
    const latWindRatio = THREE.MathUtils.clamp(fwdSpeed / 14, 0, 1);
    const bumpPitch = -this._hairHeadAccel.y * 0.016;
    const revSwing = revSpeed * 0.038;
    const subDt = Math.min(dt, 0.033);

    for (let i = 0; i < this.hairChains.length; i++) {
      const chain = this.hairChains[i];
      const flutter =
        Math.sin(this.animTime * (9.0 + fwdSpeed * 0.45) + chain.phaseOffset) *
        0.058 *
        windRatio;
      const idleSway = Math.sin(this.animTime * 1.9 + chain.phaseOffset) * 0.018;

      const targetPitch = THREE.MathUtils.clamp(
        windDrag + headPitchGrav + flutter + bumpPitch + revSwing + idleSway,
        chain.isFront ? -0.18 : -0.12,
        0.88
      );
      const targetRoll = THREE.MathUtils.clamp(
        latVel * 0.032 +
          latAccel * 0.013 +
          Math.cos(this.animTime * 4.6 + chain.phaseOffset) * 0.028 * latWindRatio,
        -0.46,
        0.46
      );

      chain.pitchVel += (chain.stiffness * (targetPitch - chain.pitch) - chain.damping * chain.pitchVel) * subDt;
      chain.pitch = THREE.MathUtils.clamp(chain.pitch + chain.pitchVel * subDt, -0.26, 0.94);

      chain.rollVel += (chain.stiffness * 0.92 * (targetRoll - chain.roll) - chain.damping * chain.rollVel) * subDt;
      chain.roll = THREE.MathUtils.clamp(chain.roll + chain.rollVel * subDt, -0.52, 0.52);

      for (let s = 0; s < chain.segments.length; s++) {
        const seg = chain.segments[s];
        this._hairPitchQ.setFromAxisAngle(seg.pitchAxisLocal, chain.pitch * seg.segWeight);
        this._hairRollQ.setFromAxisAngle(seg.rollAxisLocal, chain.roll * seg.segWeight);
        seg.bone.quaternion
          .copy(seg.restLocal)
          .multiply(this._hairPitchQ)
          .multiply(this._hairRollQ);
      }
    }
  }

  public setReflectionsEnabled(enabled: boolean): void {
    const mult = enabled ? 1.0 : 0.35;
    const applyEnv = (obj: any) => {
      if (obj.isMesh && obj.material) {
        const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
        for (const m of mats) {
          if (m && 'envMapIntensity' in m) {
            if (m.userData.__baseEnvMapIntensity === undefined) {
              m.userData.__baseEnvMapIntensity = m.envMapIntensity ?? 1.0;
            }
            m.envMapIntensity = m.userData.__baseEnvMapIntensity * mult;
          }
        }
      }
    };
    this.root.traverse(applyEnv);
    this.riderRoot.traverse(applyEnv);
    this.helmetPivot.traverse(applyEnv);
  }
}
