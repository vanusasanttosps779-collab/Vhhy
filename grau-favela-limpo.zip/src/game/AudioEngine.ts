import { ExhaustSoundMode, TelemetryState } from './types';

export const USA_RACING_EXHAUST_URL =
  'https://cdn.rapidfile.cc/By4pNCbRoi/ESCAPAMENTO%20ESPORTIVO%20(U.S.A%20RACING)%20%20NA%20TITAN%20160%20-%20O%20RONCO%20FICOU%20SENSACIONAL___(144P).mp4';

interface SeamlessSliceSpec {
  startSec: number;
  endSec: number;
  fadeSec: number;
}

function buildSeamlessLoopBuffer(
  ctx: AudioContext,
  decoded: AudioBuffer,
  spec: SeamlessSliceSpec
): AudioBuffer | null {
  const sr = decoded.sampleRate;
  const channels = Math.min(2, decoded.numberOfChannels);
  const totalLen = decoded.length;

  const startIdx = Math.max(0, Math.floor(spec.startSec * sr));
  const targetEndIdx = Math.min(totalLen - 1, Math.floor(spec.endSec * sr));
  const fadeSamples = Math.max(256, Math.floor(spec.fadeSec * sr));
  if (targetEndIdx - startIdx <= fadeSamples * 2 + 512) return null;

  // Phase-align the overlap window so the loop seam stays in-phase without cancellation or clicks
  const src0 = decoded.getChannelData(0);
  const searchRadius = Math.min(Math.floor(sr / 26), Math.floor((targetEndIdx - startIdx - fadeSamples * 2) * 0.45));
  const probeLen = Math.min(fadeSamples, Math.floor(sr * 0.08));
  let bestEndIdx = targetEndIdx;
  let bestScore = -Infinity;

  for (let off = -searchRadius; off <= searchRadius; off += 4) {
    const candEnd = targetEndIdx + off;
    if (candEnd >= totalLen || candEnd - fadeSamples <= startIdx + fadeSamples + 256) continue;
    const tailStart = candEnd - fadeSamples;
    let dot = 0;
    let normA = 0;
    let normB = 0;
    for (let j = 0; j < probeLen; j += 4) {
      const a = src0[startIdx + j];
      const b = src0[tailStart + j];
      dot += a * b;
      normA += a * a;
      normB += b * b;
    }
    const score = dot / (Math.sqrt(normA * normB) + 1e-6);
    if (score > bestScore) {
      bestScore = score;
      bestEndIdx = candEnd;
    }
  }

  const outLen = bestEndIdx - startIdx - fadeSamples;
  if (outLen <= fadeSamples) return null;

  const outBuf = ctx.createBuffer(channels, outLen, sr);
  const tailOffset = bestEndIdx - fadeSamples;

  for (let ch = 0; ch < channels; ch++) {
    const src = decoded.getChannelData(ch);
    const dst = outBuf.getChannelData(ch);

    for (let i = 0; i < fadeSamples; i++) {
      const t = i / fadeSamples;
      const fadeIn = Math.sin(t * Math.PI * 0.5);
      const fadeOut = Math.cos(t * Math.PI * 0.5);
      dst[i] = src[tailOffset + i] * fadeOut + src[startIdx + i] * fadeIn;
    }

    for (let i = fadeSamples; i < outLen; i++) {
      dst[i] = src[startIdx + i];
    }
  }

  return outBuf;
}

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;

  // Fallback / Original procedural CG 160 exhaust synth
  private synthBusGain: GainNode | null = null;
  private oscPrimary: OscillatorNode | null = null;
  private oscSub: OscillatorNode | null = null;
  private oscHarm: OscillatorNode | null = null;
  private exhaustFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;

  // Real sampled U.S.A Racing Titan 160 exhaust audio (loaded from CDN MP4)
  private usaBusGain: GainNode | null = null;
  private usaFilter: BiquadFilterNode | null = null;
  private usaLowSource: AudioBufferSourceNode | null = null;
  private usaHighSource: AudioBufferSourceNode | null = null;
  private usaLowGain: GainNode | null = null;
  private usaHighGain: GainNode | null = null;
  private usaLowBuffer: AudioBuffer | null = null;
  private usaHighBuffer: AudioBuffer | null = null;
  private usaLoading = false;
  private usaReady = false;
  private usaFailed = false;

  private windGain: GainNode | null = null;
  private scrapeGain: GainNode | null = null;
  private muted = false;
  private started = false;
  private disposed = false;
  private soundMode: ExhaustSoundMode = 'usa_racing';

  public start(): void {
    if (this.disposed) return;
    if (this.started) {
      if (this.ctx && this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      if (this.soundMode === 'usa_racing' && !this.usaReady && !this.usaLoading && !this.usaFailed) {
        void this.loadUsaRacingAudio();
      }
      return;
    }

    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    try {
      const ctx = new AudioCtx();
      this.ctx = ctx;

      const master = ctx.createGain();
      master.gain.value = this.muted ? 0 : 0.32;
      master.connect(ctx.destination);
      this.masterGain = master;

      // 1. Procedural Synth Bus (used immediately while MP4 loads, or when 'original' is selected)
      const synthBus = ctx.createGain();
      synthBus.gain.value = 1;
      synthBus.connect(master);
      this.synthBusGain = synthBus;

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 320;
      filter.Q.value = 3.2;

      const engGain = ctx.createGain();
      engGain.gain.value = 0.25;
      filter.connect(engGain);
      engGain.connect(synthBus);

      this.exhaustFilter = filter;
      this.engineGain = engGain;

      const osc1 = ctx.createOscillator();
      osc1.type = 'sawtooth';
      osc1.frequency.value = 48;
      osc1.connect(filter);
      osc1.start();

      const osc2 = ctx.createOscillator();
      osc2.type = 'triangle';
      osc2.frequency.value = 24;
      osc2.connect(filter);
      osc2.start();

      const osc3 = ctx.createOscillator();
      osc3.type = 'sawtooth';
      osc3.frequency.value = 72;
      osc3.detune.value = 14;
      const g3 = ctx.createGain();
      g3.gain.value = 0.35;
      osc3.connect(g3);
      g3.connect(filter);
      osc3.start();

      this.oscPrimary = osc1;
      this.oscSub = osc2;
      this.oscHarm = osc3;

      // 2. U.S.A Racing Titan 160 Real Exhaust Bus (dual-band RPM loop)
      const usaBus = ctx.createGain();
      usaBus.gain.value = 0;
      usaBus.connect(master);
      this.usaBusGain = usaBus;

      const usaFilt = ctx.createBiquadFilter();
      usaFilt.type = 'lowpass';
      usaFilt.frequency.value = 2400;
      usaFilt.Q.value = 1.25;
      usaFilt.connect(usaBus);
      this.usaFilter = usaFilt;

      const uLowGain = ctx.createGain();
      uLowGain.gain.value = 0.85;
      uLowGain.connect(usaFilt);
      this.usaLowGain = uLowGain;

      const uHighGain = ctx.createGain();
      uHighGain.gain.value = 0;
      uHighGain.connect(usaFilt);
      this.usaHighGain = uHighGain;

      // 3. Procedural filtered white noise for wind & scrape sparks
      const noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const data = noiseBuf.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const windSrc = ctx.createBufferSource();
      windSrc.buffer = noiseBuf;
      windSrc.loop = true;
      const windFilt = ctx.createBiquadFilter();
      windFilt.type = 'bandpass';
      windFilt.frequency.value = 460;
      windFilt.Q.value = 0.7;
      const wGain = ctx.createGain();
      wGain.gain.value = 0;
      windSrc.connect(windFilt);
      windFilt.connect(wGain);
      wGain.connect(master);
      windSrc.start();
      this.windGain = wGain;

      const scrapeSrc = ctx.createBufferSource();
      scrapeSrc.buffer = noiseBuf;
      scrapeSrc.loop = true;
      const scrapeFilt = ctx.createBiquadFilter();
      scrapeFilt.type = 'highpass';
      scrapeFilt.frequency.value = 2400;
      const sGain = ctx.createGain();
      sGain.gain.value = 0;
      scrapeSrc.connect(scrapeFilt);
      scrapeFilt.connect(sGain);
      sGain.connect(master);
      scrapeSrc.start();
      this.scrapeGain = sGain;

      this.started = true;

      if (this.soundMode === 'usa_racing') {
        void this.loadUsaRacingAudio();
      }
    } catch {
      // Audio blocked or unsupported
    }
  }

  private async loadUsaRacingAudio(): Promise<void> {
    if (this.usaLoading || this.usaReady || this.usaFailed || !this.ctx || this.disposed) return;
    this.usaLoading = true;
    try {
      const res = await fetch(USA_RACING_EXHAUST_URL, { mode: 'cors' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const arr = await res.arrayBuffer();
      if (this.disposed || !this.ctx) return;

      const decoded = await this.ctx.decodeAudioData(arr);
      if (this.disposed || !this.ctx) return;

      // Extract clean low-mid thump (~4,400 RPM) and high-RPM roar (~8,500 RPM) from the Titan 160 MP4
      const lowBuf = buildSeamlessLoopBuffer(this.ctx, decoded, {
        startSec: 1.55,
        endSec: 2.35,
        fadeSec: 0.09,
      });
      const highBuf = buildSeamlessLoopBuffer(this.ctx, decoded, {
        startSec: 11.65,
        endSec: 12.85,
        fadeSec: 0.11,
      });

      if (!lowBuf || !highBuf) throw new Error('Failed to slice exhaust buffers');

      this.usaLowBuffer = lowBuf;
      this.usaHighBuffer = highBuf;

      if (this.usaLowGain && this.usaHighGain) {
        const lowSrc = this.ctx.createBufferSource();
        lowSrc.buffer = lowBuf;
        lowSrc.loop = true;
        lowSrc.playbackRate.value = 0.48;
        lowSrc.connect(this.usaLowGain);
        lowSrc.start();

        const highSrc = this.ctx.createBufferSource();
        highSrc.buffer = highBuf;
        highSrc.loop = true;
        highSrc.playbackRate.value = 0.72;
        highSrc.connect(this.usaHighGain);
        highSrc.start();

        this.usaLowSource = lowSrc;
        this.usaHighSource = highSrc;
        this.usaReady = true;
        this.applyBusMix();
      }
    } catch {
      this.usaFailed = true;
      // Keep procedural synth running cleanly if network/decode fails
    } finally {
      this.usaLoading = false;
    }
  }

  private applyBusMix(): void {
    if (!this.ctx || !this.synthBusGain || !this.usaBusGain) return;
    const now = this.ctx.currentTime;
    const useUsa = this.soundMode === 'usa_racing' && this.usaReady;
    this.synthBusGain.gain.setTargetAtTime(useUsa ? 0 : 1, now, 0.08);
    this.usaBusGain.gain.setTargetAtTime(useUsa ? 1 : 0, now, 0.08);
  }

  public setSoundMode(mode: ExhaustSoundMode): void {
    this.soundMode = mode;
    if (mode === 'usa_racing') {
      this.usaFailed = false;
      if (this.started && !this.usaReady && !this.usaLoading) {
        void this.loadUsaRacingAudio();
      }
    }
    this.applyBusMix();
  }

  public getSoundMode(): ExhaustSoundMode {
    return this.soundMode;
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(muted ? 0 : 0.32, this.ctx.currentTime, 0.04);
    }
  }

  public update(telemetry: TelemetryState, throttle: number): void {
    if (!this.started || !this.ctx) return;
    const now = this.ctx.currentTime;
    const rpmNorm = Math.max(0, Math.min(1.15, telemetry.rpm / Math.max(1, telemetry.maxRpm)));
    const limiterChop = telemetry.revLimiter && Math.sin(now * 68) > 0 ? 0.16 : 1.0;

    if (this.soundMode === 'usa_racing' && this.usaReady && this.usaLowSource && this.usaHighSource) {
      // Map bike RPM (1450..11000) across the low (~4400 RPM) and high (~8500 RPM) U.S.A Racing loops
      const lowRate = Math.max(0.36, Math.min(1.55, telemetry.rpm / 4100));
      const highRate = Math.max(0.42, Math.min(1.42, telemetry.rpm / 8350));

      this.usaLowSource.playbackRate.setTargetAtTime(lowRate, now, 0.03);
      this.usaHighSource.playbackRate.setTargetAtTime(highRate, now, 0.03);

      // Equal-power crossfade between deep idle thump and high-RPM sporty roar
      const blend = Math.max(0, Math.min(1, (telemetry.rpm - 3600) / 3600));
      const lowMix = Math.cos(blend * Math.PI * 0.5);
      const highMix = Math.sin(blend * Math.PI * 0.5);

      const baseDrive = telemetry.crashed
        ? 0.06
        : (0.48 + throttle * 0.48 + rpmNorm * 0.34) * limiterChop;

      this.usaLowGain?.gain.setTargetAtTime(lowMix * baseDrive * 1.15, now, 0.03);
      this.usaHighGain?.gain.setTargetAtTime(highMix * baseDrive * 1.25, now, 0.03);

      if (this.usaFilter) {
        const cutoff = telemetry.crashed
          ? 420
          : 950 + rpmNorm * 4200 + throttle * 3400;
        this.usaFilter.frequency.setTargetAtTime(cutoff, now, 0.035);
        this.usaFilter.Q.setTargetAtTime(0.9 + throttle * 1.1, now, 0.04);
      }
    } else if (this.oscPrimary && this.oscSub && this.oscHarm) {
      // Firing frequency: Honda CG 160 Titan single-cylinder thump
      const baseHz = Math.max(20, (telemetry.rpm / 60) * 0.96);
      this.oscPrimary.frequency.setTargetAtTime(baseHz, now, 0.025);
      this.oscSub.frequency.setTargetAtTime(baseHz * 0.5, now, 0.025);
      this.oscHarm.frequency.setTargetAtTime(baseHz * 2.0, now, 0.025);

      if (this.exhaustFilter && this.engineGain) {
        const cutoff = 260 + rpmNorm * 1450 + throttle * 520;
        this.exhaustFilter.frequency.setTargetAtTime(cutoff, now, 0.03);
        const vol = (0.16 + throttle * 0.22 + rpmNorm * 0.15) * limiterChop;
        this.engineGain.gain.setTargetAtTime(telemetry.crashed ? 0.02 : vol, now, 0.02);
      }
    }

    if (this.windGain) {
      const windVol = Math.min(0.26, Math.pow(telemetry.speedKmh / 180, 1.6) * 0.24);
      this.windGain.gain.setTargetAtTime(windVol, now, 0.06);
    }

    if (this.scrapeGain) {
      const scrapeVol = telemetry.isScrape && telemetry.speedKmh > 10 ? 0.24 : 0;
      this.scrapeGain.gain.setTargetAtTime(scrapeVol, now, 0.03);
    }
  }

  public playBottleGrab(): void {
    if (!this.started || !this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(190, now);
    osc.frequency.exponentialRampToValueAtTime(95, now + 0.09);
    gain.gain.setValueAtTime(0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.12);
  }

  public playCapTwist(isCrack = false): void {
    if (!this.started || !this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const filt = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(isCrack ? 1150 : 780, now);
    osc.frequency.exponentialRampToValueAtTime(isCrack ? 520 : 390, now + 0.045);
    filt.type = 'bandpass';
    filt.frequency.value = isCrack ? 1600 : 1200;
    filt.Q.value = 2.4;
    gain.gain.setValueAtTime(isCrack ? 0.18 : 0.09, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.055);
    osc.connect(filt);
    filt.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.06);
  }

  public playWaterDrinkGulp(): void {
    if (!this.started || !this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(240 + Math.random() * 50, now);
    osc.frequency.exponentialRampToValueAtTime(420 + Math.random() * 60, now + 0.09);
    osc.frequency.exponentialRampToValueAtTime(175, now + 0.16);
    gain.gain.setValueAtTime(0.01, now);
    gain.gain.linearRampToValueAtTime(0.16, now + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.18);
  }

  public playBottleStow(): void {
    if (!this.started || !this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(145, now);
    osc.frequency.exponentialRampToValueAtTime(75, now + 0.12);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  public dispose(): void {
    this.disposed = true;
    try {
      this.oscPrimary?.stop();
      this.oscSub?.stop();
      this.oscHarm?.stop();
      this.usaLowSource?.stop();
      this.usaHighSource?.stop();
      void this.ctx?.close();
    } catch {
      // ignore
    }
    this.usaLowBuffer = null;
    this.usaHighBuffer = null;
  }
}
